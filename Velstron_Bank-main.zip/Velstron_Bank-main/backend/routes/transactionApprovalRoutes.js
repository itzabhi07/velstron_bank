const express = require('express');
const router = express.Router();
const txnController = require('../controllers/transactionApprovalController');

router.get('/pending', txnController.getPendingTransactions);
router.get('/approved', txnController.getApprovedTransactions);
router.put('/:id/approve', txnController.approveTransaction);
router.put('/:id/reject', txnController.rejectTransaction);

module.exports = router;