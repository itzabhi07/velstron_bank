const express = require('express');
const router = express.Router();
const { getFundFlows } = require('../controllers/fundsControllers');
const authMiddleware = require('../middleware/authMiddleware'); // Agar auth lagana hai

// Protected route - add authMiddleware if required
router.get('/fundflows', authMiddleware, getFundFlows);

module.exports = router;