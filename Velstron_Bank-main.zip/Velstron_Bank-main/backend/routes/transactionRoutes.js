const express = require('express');
const router = express.Router();
const { approveTransaction } = require('../controllers/transactionApprovalController');

// POST Route to approve transaction
router.post('/approve', approveTransaction);

module.exports = router;