// backend/routes/executiveManagementRoutes.js
const express = require('express');
const router = express.Router();
const execController = require('../controllers/executiveManagementController');

router.get('/executives', execController.getExecutives);
router.post('/executives', execController.addExecutive);
router.put('/executives/:id', execController.updateExecutive);
router.delete('/executives/:id', execController.deleteExecutive);

module.exports = router;