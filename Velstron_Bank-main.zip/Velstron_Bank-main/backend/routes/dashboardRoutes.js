const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/authMiddleware');
const {
  getFundSummary,
  fundTransfer,
  setHotAccountHolding,
  createTransactionRequest,
  getAccountDetails
} = require('../controllers/dashboardController');

router.get('/fund-summary', authMiddleware, getFundSummary);
router.post('/fund-transfer', authMiddleware, fundTransfer);
router.post('/set-hot-holding', authMiddleware, setHotAccountHolding); // Set % holding
router.post('/transaction-request', authMiddleware, createTransactionRequest); // Deposit / Withdrawal
router.get('/account-details', authMiddleware, getAccountDetails); // VELSTRON ID & Account Numbers

module.exports = router;