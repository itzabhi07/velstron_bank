// backend/routes/analyticsRoutes.js

const express = require('express');
const router = express.Router();

// Correct imports - path depends on your folder structure
const authMiddleware = require('../middleware/authMiddleware');
const analyticsController = require('../controllers/analyticsControllers');

// Use middleware and controller function as handlers
router.get('/analytics', authMiddleware, analyticsController.getAnalyticsData);

module.exports = router;