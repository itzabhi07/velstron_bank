const express = require('express');
const router = express.Router();

// Admin controller functions
const {
  getAllUsers,
  approveExecutiveReview,
  getsecuritySettings,
  updatesecuritySettings,
  updateuser,
  getsystemSettings,
  updatesystemSettings,
} = require('../controllers/adminControllers');

// Limit controller functions
const {
  setLimit,
  getLimits
} = require('../controllers/limitControllers');

// Alert controller functions
const {
  getAlerts,
  markReviewed
} = require('../controllers/alertControllers');

// ✅ Admin routes
router.get('/users', getAllUsers);
router.put('/users/:id', updateuser);
router.put('/executive-review/:id/approve', approveExecutiveReview);

// ✅ Limit routes
router.post('/limits', setLimit);
router.get('/limits', getLimits);

// ✅ Alert routes
router.get('/alerts', getAlerts);
router.put('/alerts/:id/review', markReviewed);

// ✅ Security settings
router.get('/security-settings', getsecuritySettings);
router.put('/security-settings', updatesecuritySettings);

// ✅ System settings
router.get('/system-settings', getsystemSettings);
router.put('/system-settings', updatesystemSettings);

module.exports = router;