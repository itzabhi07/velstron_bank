// Generate unique Velstron ID like VLS_U12345
function generateVelstronId(userCount) {
  const prefix = "VLS_U";
  const idNumber = (userCount + 1).toString().padStart(5, "0");
  return prefix + idNumber;
}

// Generate random account number XXXX-XXXX-XXXX-1234 format
function generateAccountNumber() {
  function randomFourDigits() {
    return Math.floor(1000 + Math.random() * 9000);
  }
  return `XXXX-XXXX-XXXX-${randomFourDigits()}`;
}

module.exports = { generateVelstronId, generateAccountNumber };
