const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const mobileNumberRegex = /^\+?[1-9]\d{1,14}$/;

function validateSignupPayload(body) {
    const {
        account_type,
        first_name,
        last_name,
        date_of_birth,
        nationality,
        gender,
        email,
        company_email,
        mobile_number,
        alternate_mobile_number,
        whatsapp_number,
        country_of_residence,
        state,
        city,
        zip,
        address,
        type_of_residency,
        occupation,
        highest_education_qualification,
        purpose_of_account_opening,
        preferred_communication_method,
        source_of_funds,
        additional_details,
        live_selfie_filename,
        original_passport_filename,
        business_proof_filename,
        FATCA_or_CRS_Declaration,
        signature_filename,
        consent,
        business_type,
        company_legal_name,
        business_activity,
        country_of_incorporation,
        state_of_incorporation,
        city_of_incorporation,
        company_website,
        corporate_tax_id,
        company_contact_number,
        authorized_signatory_full_name,
        signatory_designation,
        signatory_email,
        signatory_phone_number,
        authority_type,
        relationship_to_company,
        certificate_of_incorporation_filename,
        tax_license_filename,
        board_resolution_filename,
        shareholder_list_filename,
    } = body;

    // Required email
    if (!email || !emailRegex.test(email.toLowerCase().trim())) {
        return { status: 400, message: "Invalid email format" };
    }

    if (company_email && !emailRegex.test(company_email.toLowerCase().trim())) {
        return { status: 400, message: "Invalid company email format" };
    }

    // Required basic fields
    const requiredFields = [first_name, last_name, date_of_birth, nationality, country_of_residence, state, city, zip, address];
    if (requiredFields.some(field => !field)) {
        return { status: 400, message: "Missing required personal fields" };
    }

    if (!account_type || !['uhni', 'corporate'].includes(account_type)) {
        return { status: 400, message: "Invalid account type" };
    }

    // Corporate-specific required fields
    if (account_type === 'corporate') {
        const corporateRequired = [
            { key: company_legal_name, msg: "Company legal name" },
            { key: business_activity, msg: "Business activity" },
            { key: country_of_incorporation, msg: "Country of incorporation" },
            { key: state_of_incorporation, msg: "State of incorporation" },
            { key: city_of_incorporation, msg: "City of incorporation" },
            { key: company_website, msg: "Company website" },
            { key: corporate_tax_id, msg: "Corporate tax ID" },
            { key: company_contact_number, msg: "Company contact number" },
            { key: authorized_signatory_full_name, msg: "Authorized signatory full name" },
            { key: signatory_designation, msg: "Signatory designation" },
            { key: signatory_email, msg: "Signatory email" },
            { key: signatory_phone_number, msg: "Signatory phone number" },
            { key: authority_type, msg: "Authority type" },
            { key: relationship_to_company, msg: "Relationship to company" },
            { key: certificate_of_incorporation_filename, msg: "Certificate of incorporation file" },
            { key: tax_license_filename, msg: "Tax license file" },
            { key: board_resolution_filename, msg: "Board resolution file" },
            { key: shareholder_list_filename, msg: "Shareholder list file" },
        ];

        for (const field of corporateRequired) {
            if (!field.key) return { status: 400, message: `${field.msg} is required for corporate accounts` };
        }
    }

    // Phone validations
    const numbersToCheck = [
        { val: mobile_number, label: "Mobile number" },
        { val: alternate_mobile_number, label: "Alternate mobile number" },
        { val: whatsapp_number, label: "WhatsApp number" },
        { val: company_contact_number, label: "Company contact number" },
        { val: signatory_phone_number, label: "Signatory phone number" },
    ];
    for (const { val, label } of numbersToCheck) {
        if (val && !mobileNumberRegex.test(val)) {
            return { status: 400, message: `Invalid ${label} format` };
        }
    }

    // Enum validations
    const enums = [
        { val: account_type, list: ['uhni', 'corporate'], name: "Account type" },
        { val: gender, list: ['male', 'female', 'other'] },
        { val: type_of_residency, list: ['permanent', 'temporary', 'nri', 'pio'], name: "Type of residency" },
        { val: occupation, list: ['business_owner', 'salaried', 'investor', 'other', 'retired'], name: "Occupation" },
        { val: highest_education_qualification, list: ['high_school', 'bachelors', 'masters', 'phd', 'other'], name: "Education qualification" },
        { val: purpose_of_account_opening, list: ['asset_holding', 'offshore_reserve', 'investment_management', 'legacy_planning', 'other'], name: "Purpose of account opening" },
        { val: preferred_communication_method, list: ['email', 'phone', 'whatsapp', 'no-preference'], name: "Preferred communication method" },
        { val: source_of_funds, list: ['salary', 'business_income', 'investments', 'inheritance', 'other'], name: "Source of funds" },
        { val: business_type, list: ['private_ltd', 'public_ltd', 'llp', 'trust', 'family_office', 'partnership'], name: "Business type" },
    ];
    for (const { val, list, name } of enums) {
        if (val && !list.includes(val)) return { status: 400, message: `Invalid ${name}` };
    }

    // File format checks
    const imgFiles = [live_selfie_filename, original_passport_filename, business_proof_filename, signature_filename];
    if (imgFiles.some(f => f && !/\.(jpg|png|pdf|jpeg)$/.test(f))) {
        return { status: 400, message: "Invalid file format" };
    }

    if (!FATCA_or_CRS_Declaration) {
        return { status: 400, message: "FATCA/CRS declaraion is required" };
    }

    if (additional_details && additional_details.length > 500) {
        return { status: 400, message: "Additional details too long" };
    }

    if (consent !== true) {
        return { status: 400, message: "Consent is required" };
    }

    return null;
}

module.exports = validateSignupPayload;
