const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.MAIL_USER,
    pass: process.env.MAIL_PASS
  }
});

exports.sendVerificationCode = async (email, code) => {
  await transporter.sendMail({
    from: '"Velstron Bank" <no-reply@velstron.com>',
    to: email,
    subject: "Your Login Verification Code",
    html: `<p>Your verification code is <b>${code}</b>. It is valid for 10 minutes.</p>`
  });
};

exports.sendAccountApprovalMail = (user, password, velstronId, hotaccount, coldaccount) => {
  const mailOptions = {
    from: process.env.MAIL_USER,
    to: user.email,
    subject: 'KYC Approved',
    text: `Hello ${user.name},

Congratulations! Your account has been successfully approved by the admin.
You can now log in to your Velstron Bank account and get started.

Velstron ID: ${velstronId}
Reference Number: ${user.referenceNumber}
Status: APPROVED
Hot Account: ${hotaccount}
Cold Account: ${coldaccount}
Password: ${password}

Thank you,
Velstron Bank`
  };

  return transporter.sendMail(mailOptions);
};