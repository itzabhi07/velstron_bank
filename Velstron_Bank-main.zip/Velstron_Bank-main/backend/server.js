// Entry point: server.js
/*const express = require('express');
const dotenv = require('dotenv');
const mongoose = require('mongoose');
const cors = require('cors');
const authRoutes = require('./routes/authRoutes');
const adminRoutes = require('./routes/adminRoutes');
const pdfRoutes = require('./routes/pdfRoutes');
const userRoutes = require('./routes/userRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');

const app = express();
dotenv.config();

mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('✅ MongoDB connected'))
.catch((err) => console.error('❌ MongoDB connection error:', err));

app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
  res.send('Velstron Bank API running');
});

// Route middleware
app.use('/api/auth', authRoutes);       // Register, login, verify
app.use('/api/user', userRoutes);       // Profile, KYC submission, etc.
app.use('/api/admin', adminRoutes);     // Admin dashboard APIs
app.use('/api/pdf', pdfRoutes);         // PDF generation
app.use('/api/dashboard', dashboardRoutes); // Fund summary & account dashboard APIs

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
*/

const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cors = require('cors');

dotenv.config();

const authRoutes = require('./routes/authRoutes');
const analyticsRoutes = require('./routes/analyticsRoutes');
const fundsRoutes = require('./routes/fundsRoutes');  // Added fundsRoutes here
const adminRoutes = require('./routes/adminRoutes');   // Corrected casing in require path to lowercase 'r'
const executiveManagementRoutes = require('./routes/executiveManagementRoutes'); // New route
const transactionApprovalRoutes = require('./routes/transactionApprovalRoutes'); // Added transaction approval routes
const transactionRoutes = require('./routes/transactionRoutes');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api', analyticsRoutes);
app.use('/api', fundsRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/transactions', transactionRoutes);  // Add this line to use the transaction routes

// Mount executive management routes under /api/admin/executiveManagement
app.use('/api/admin/executiveManagement', executiveManagementRoutes);

// Mount transaction approval routes under /api/executive/transactions
app.use('/api/executive/transactions', transactionApprovalRoutes);

mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('MongoDB connected');
  app.listen(process.env.PORT || 5000, () => {
    console.log(`Server running on port ${process.env.PORT || 5000}`);
  });
}).catch(err => console.error(err));// server.js
require("dotenv").config(); // load env variables at the top

const connectDB = require("./config/db"); // import the connectDB function

const PORT = process.env.PORT || 5000;

// Connect to MongoDB before starting the server
connectDB()
  .then(() => {
    // Middlewares, routes etc. go here
    app.use(express.json());

    // Example route
    app.get("/", (req, res) => {
      res.send("API is running...");
    });

    // Start server
    app.listen(PORT, () => {
      console.log`(Server running on port ${PORT})`;
    });
  })
  .catch((err) => {
    console.error("Failed to connect to DB, server not started", err);
  });