const mongoose = require('mongoose');

const systemSettingSchema = new mongoose.Schema({
  supportedCurrencies: [{ type: String }],
  supportedCountries: [{ type: String }],
  emailTemplates: {
    kyc: { type: String, default: "" },
    activation: { type: String, default: "" },
    reminder: { type: String, default: "" }
  }
});

const SystemSetting = mongoose.model('SystemSetting', systemSettingSchema);

module.exports = SystemSetting;