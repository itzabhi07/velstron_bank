// backend/models/Executive.js
const mongoose = require('mongoose');

const ExecutiveSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  position: { type: String, required: true },
  department: { type: String },
  region: { type: String },
  countries: [String],
  status: { type: String, enum: ['Active', 'On Leave', 'Inactive'], default: 'Active' },
  lastActive: { type: Date, default: Date.now }
}, { timestamps: true });

module.exports = mongoose.model('Executive', ExecutiveSchema);