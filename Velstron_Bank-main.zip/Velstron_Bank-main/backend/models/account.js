const mongoose = require('mongoose');

const accountSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  hotAccountBalance: { type: Number, default: 0 },
  coldAccountBalance: { type: Number, default: 0 },
  velstronId: { type: String, required: true, unique: true },
  hotAccountNumber: { type: String, required: true, unique: true },
  coldAccountNumber: { type: String, required: true, unique: true }
}, { timestamps: true });

module.exports = mongoose.model('UserAccount', accountSchema);