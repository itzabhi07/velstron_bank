const mongoose = require('mongoose');

const limitSchema = new mongoose.Schema({
  type: { type: String, required: true }, // e.g., "daily", "perUser"
  value: { type: Number, required: true },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Limit', limitSchema);