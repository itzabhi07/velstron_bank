const mongoose = require('mongoose');

const permissionSchema = new mongoose.Schema({
  createUsers: { type: Boolean, default: false },
  deleteUsers: { type: Boolean, default: false },
  manageRoles: { type: Boolean, default: false },
  viewReports: { type: Boolean, default: false },
  systemSettings: { type: Boolean, default: false },
  kycApproval: { type: Boolean, default: false },
  accountCreation: { type: Boolean, default: false },
  auditLogs: { type: Boolean, default: false },
});

const securitySettingSchema = new mongoose.Schema({
  role: { type: String, required: true, unique: true },  // e.g. 'admin', 'executive'
  permissions: permissionSchema,
});

const SecuritySetting = mongoose.model('SecuritySetting', securitySettingSchema);

module.exports = SecuritySetting;