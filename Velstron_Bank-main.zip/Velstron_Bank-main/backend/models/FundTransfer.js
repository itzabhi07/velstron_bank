const mongoose = require('mongoose');

const fundTransferSchema = new mongoose.Schema({
  fromAccount: { type: String, required: true },  // 'hot' or 'cold'
  toAccount: { type: String, required: true },
  amount: { type: Number, required: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  timestamp: { type: Date, default: Date.now }
});

module.exports = mongoose.model('FundTransfer', fundTransferSchema);