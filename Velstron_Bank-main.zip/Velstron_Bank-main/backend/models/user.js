const mongoose = require('mongoose');

const contactNumberRegex = /^\+?[1-9]\d{1,14}$/;
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const userSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true,
    unique: true,
    trim: true,
  },
  account_type: {
    type: String,
    enum: ['uhni', 'corporate'],
    required: true,
  },
  name: {
    type: String,
    required: false,
    trim: true,
  },
  gender: { type: String, enum: ['male', 'female', 'other'] },
  date_of_birth: { type: Date },
  nationality: { type: String },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true,
    match: emailRegex,
  },
  mobile_number: {
    type: String,
    match: contactNumberRegex,
  },
  alternate_mobile_number: {
    type: String,
    match: contactNumberRegex,
  },
  whatsapp_number: {
    type: String,
    match: contactNumberRegex,
  },
  country_of_residence: String,
  state: String,
  city: String,
  zip: String,
  address: String,
  type_of_residency: {
    type: String,
    enum: ['permanent', 'temporary', 'nri', 'pio'],
  },
  occupation: {
    type: String,
    enum: ['business_owner', 'salaried', 'investor', 'other', 'retired'],
  },
  highest_education_qualification: {
    type: String,
    enum: ['high_school', 'bachelors', 'masters', 'phd', 'other'],
  },
  purpose_of_account_opening: {
    type: String,
    enum: ['asset_holding', 'offshore_reserve', 'investment_management', 'legacy_planning', 'other'],
  },
  preferred_communication_method: {
    type: String,
    enum: ['email', 'phone', 'whatsapp', 'no-preference'],
  },
  source_of_funds: {
    type: String,
    enum: ['salary', 'business_income', 'investments', 'inheritance', 'other'],
  },
  additional_details: {
    type: String,
    maxlength: 500,
  },
  live_selfie_filename: String,
  original_passport_filename: String,
  business_proof_filename: String,
  FATCA_or_CRS_Declaration: String,
  signature_filename: String,
  consent: {
    type: Boolean,
    required: true,
  },

  // Corporate-specific fields
  company: {
    company_legal_name: String,
    business_type: {
      type: String,
      enum: ['private_ltd', 'public_ltd', 'llp', 'trust', 'family_office', 'partnership'],
    },
    business_activity: String,
    country_of_incorporation: String,
    state_of_incorporation: String,
    city_of_incorporation: String,
    company_website: String,
    company_email: {
      type: String,
      lowercase: true,
      trim: true,
      match: emailRegex,
    },
    corporate_tax_id: String,
    company_contact_number: {
      type: String,
      match: contactNumberRegex,
    },
    authorized_signatory_full_name: String,
    signatory_designation: String,
    signatory_email: {
      type: String,
      match: emailRegex,
    },
    signatory_phone_number: {
      type: String,
      match: contactNumberRegex,
    },
    authority_type: String,
    relationship_to_company: String,
    certificate_of_incorporation_filename: String,
    tax_license_filename: String,
    board_resolution_filename: String,
    shareholder_list_filename: String,
  },

  totalInvestment: {
    type: Number,
    required: true,
    default: 0,
  },
  activeSince: {
    type: Date,
    required: true,
    default: Date.now,
  },
  isActive: {
    type: Boolean,
    default: true,
  },
  role: {
    type: String,
    enum: ['user', 'admin'],
    default: 'user',
  },
  passwordHash: {
    type: String,
    required: true,
  },

  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  }
});

// Auto-update `updatedAt`
userSchema.pre('save', function (next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('User', userSchema);
