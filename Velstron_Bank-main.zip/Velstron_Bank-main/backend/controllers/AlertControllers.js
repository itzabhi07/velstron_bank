const Alert = require('../models/alert');

// Get all alerts
exports.getAlerts = async (req, res) => {
  try {
    const alerts = await Alert.find().populate('userId');
    res.status(200).json(alerts);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

// Mark alert as reviewed
exports.markReviewed = async (req, res) => {
  try {
    const { id } = req.params;
    const alert = await Alert.findByIdAndUpdate(id, { reviewed: true }, { new: true });
    res.status(200).json({ message: 'Alert marked as reviewed', alert });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};