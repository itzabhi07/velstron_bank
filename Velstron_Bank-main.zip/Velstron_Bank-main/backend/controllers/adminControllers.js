// Import models once, in proper case
const User = require('../models/user');
const ExecutiveReview = require('../models/executiveReview');
const FundTransfer = require('../models/fundTransfer');
const SecuritySetting = require('../models/securitySettings');
const SystemSetting = require('../models/systemSettings');

// Import utils
const { generateVelstronId, generateAccountNumber } = require('../utils/generateIds');
const { sendAccountApprovalMail } = require('../utils/mailer');

// Get all users except the password field
const getAllUsers = async (req, res) => {
  try {
    // Fetch all users, excluding the password field
    const users = await User.find({}, '-password');
    res.json(users);
  } catch (error) {
    console.error("Error fetching users:", error);
    res.status(500).json({ message: 'Server error fetching users' });
  }
};

// Approve an executive review by ID
const approveExecutiveReview = async (req, res) => {
  const reviewId = req.params.id;

  try {
    const review = await ExecutiveReview.findById(reviewId);
    if (!review) {
      return res.status(404).json({ message: 'Review not found' });
    }

    review.status = 'Approved';  // Update the review status
    await review.save();

    res.json({ message: 'Review approved successfully', review });
  } catch (error) {
    console.error("Error approving review:", error);
    res.status(500).json({ message: 'Server error approving review' });
  }
};

const createUserWithGeneratedIds = async (req, res) => {
  try {
    const userCount = await User.countDocuments();

    // Generate unique Velstron ID based on user count
    const velstronId = generateVelstronId(userCount);

    // Generate hot and cold account numbers
    const hotAccountNumber = generateAccountNumber();
    const coldAccountNumber = generateAccountNumber();

    // Create a new user with request data + generated IDs
    const newUser = new User({
      ...req.body, // name, email, password, etc.
      velstronId,
      accounts: {
        hot: { balance: 0, number: hotAccountNumber },
        cold: { balance: 0, number: coldAccountNumber },
      },
    });

    await newUser.save();

    res.status(201).json({ message: 'User created', user: newUser });
  } catch (error) {
    console.error('Error creating user:', error);
    res.status(500).json({ message: 'Server error creating user' });
  }
};

const getFundsFlow = async (req, res) => {
  try {
    const transfers = await FundTransfer.find()
      .populate('user', 'name velstronId') // Also fetch user's name and Velstron ID
      .sort({ timestamp: -1 })             // Show latest transfers first
      .limit(100);                         // Limit to latest 100 records

    res.json(transfers);
  } catch (error) {
    console.error('Error fetching funds flow:', error);
    res.status(500).json({ message: 'Server error fetching funds flow' });
  }
};

const approveUser = async (req, res) => {
  const { userId } = req.params;

  try {
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    user.status = 'Approved';
    await user.save();

    // Generate some data here — functions for these should be defined
    const velstronId = generateVelstronId(await User.countDocuments()); // Better to generate fresh ID
    const hotaccount = generateAccountNumber();
    const coldaccount = generateAccountNumber();
    const password = generatePassword(); // Ensure this function is defined in utils

    // Send email to user regarding approval
    await sendAccountApprovalMail(user, password, velstronId, hotaccount, coldaccount);

    res.json({ message: 'User approved and email sent' });
  } catch (error) {
    console.error('Error approving user:', error);
    res.status(500).json({ message: 'Error approving user', error });
  }
};

const getsecuritySettings = async (req, res) => {
  try {
    const settings = await SecuritySetting.find({});
    res.status(200).json(settings);
  } catch (error) {
    console.error('Error fetching security settings:', error);
    res.status(500).json({ message: 'Server error fetching security settings' });
  }
};

// Get all users (optional filters can be added in the future)
const getusers = async (req, res) => {
  try {
    const users = await User.find({});
    res.status(200).json(users);
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ message: 'Error fetching users' });
  }
};

// Update user info by user ID
const updateuser = async (req, res) => {
  const userId = req.params.id;
  const updateData = req.body;

  try {
    const updatedUser = await User.findByIdAndUpdate(userId, updateData, { new: true });
    if (!updatedUser) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.status(200).json(updatedUser);
  } catch (error) {
    console.error('Error updating user:', error);
    res.status(500).json({ message: 'Error updating user' });
  }
};

// Placeholder for updateSecuritySettings
const updatesecuritySettings = async (req, res) => {
  try {
    // TODO: Implement logic to update security settings
    const { settings } = req.body; // Example: expecting settings in request body
    // const updatedSettings = await SecuritySetting.findOneAndUpdate({}, settings, { new: true, upsert: true });
    // res.status(200).json(updatedSettings);
    res.json({ message: 'updateSecuritySettings not implemented yet' });
  } catch (error) {
    console.error('Error updating security settings:', error);
    res.status(500).json({ message: 'Server error updating security settings' });
  }
};

// Get system settings (assuming there's only one document)
const getsystemSettings = async (req, res) => {
  try {
    const settings = await SystemSetting.findOne({});
    if (!settings) {
      return res.status(404).json({ message: 'System settings not found' });
    }
    res.status(200).json(settings);
  } catch (error) {
    console.error('Error fetching system settings:', error);
    res.status(500).json({ message: 'Server error fetching system settings' });
  }
};

// Update system settings
const updatesystemSettings = async (req, res) => {
  const updateData = req.body;

  try {
    const updatedSettings = await SystemSetting.findOneAndUpdate(
      {},
      updateData,
      { new: true, upsert: true }
    );
    res.status(200).json(updatedSettings);
  } catch (error) {
    console.error('Error updating system settings:', error);
    res.status(500).json({ message: 'Server error updating system settings' });
  }
};

module.exports = {
  getAllUsers,
  approveExecutiveReview,
  createUserWithGeneratedIds,
  getFundsFlow,
  approveUser,
  getsecuritySettings,
  getusers,
  updateuser,
  updatesecuritySettings,
  getsystemSettings,
  updatesystemSettings,
};