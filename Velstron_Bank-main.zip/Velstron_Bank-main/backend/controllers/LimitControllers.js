const Limit = require('../models/limit');

// Add new transaction limit
exports.setLimit = async (req, res) => {
  try {
    const { type, value } = req.body;
    const limit = new Limit({ type, value });
    await limit.save();
    res.status(201).json({ message: 'Limit set successfully', limit });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

// Get all transaction limits
exports.getLimits = async (req, res) => {
  try {
    const limits = await Limit.find();
    res.status(200).json(limits);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};