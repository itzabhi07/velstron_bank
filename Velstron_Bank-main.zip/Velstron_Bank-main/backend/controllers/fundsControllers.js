const Transaction = require('../models/transaction');

async function getFundFlows(req, res) {
  try {
    // Filters from query parameters
    const {
      startDate,
      endDate,
      user,
      country,
      currency,
      transactionType,
    } = req.query;

    // Build MongoDB query object dynamically
    const query = {};

    if (startDate || endDate) {
      query.date = {};
      if (startDate) query.date.$gte = new Date(startDate);
      if (endDate) query.date.$lte = new Date(endDate);
    }

    if (user) {
      // Case-insensitive partial match
      query.user = { $regex: new RegExp(user, 'i') };
    }

    if (country) {
      query.country = country;
    }

    if (currency) {
      query.currency = currency;
    }

    if (transactionType) {
      query.type = transactionType;
    }

    // Fetch transactions from DB based on filters, sorted by date desc
    const transactions = await Transaction.find(query).sort({ date: -1 }).lean();

    res.json({
      totalTransactions: transactions.length,
      fundFlowData: transactions,
    });
  } catch (error) {
    console.error('Error fetching fund flow data:', error);
    res.status(500).json({ message: 'Failed to fetch fund flow data.' });
  }
}

module.exports = { getFundFlows };