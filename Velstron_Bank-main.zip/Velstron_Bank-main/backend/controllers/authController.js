// controllers/authController.js
const User = require('../models/user');
const { generateCode } = require('../utils/generateCode');
const { sendVerificationCode } = require('../utils/mailer');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const validateSignupPayload = require('../utils/validateSignupPayload');



exports.signup = async (req, res) => {
  try {
    const {
      account_type,
      first_name,
      middle_name,
      last_name,
      gender,
      date_of_birth,
      nationality,
      email,
      mobile_number,
      alternate_mobile_number,
      whatsapp_number,
      country_of_residence,
      state,
      city,
      zip,
      address,
      type_of_residency,
      occupation,
      highest_education_qualification,
      purpose_of_account_opening,
      preferred_communication_method,
      source_of_funds,
      additional_details,
      live_selfie_filename,
      original_passport_filename,
      business_proof_filename,
      FATCA_or_CRS_Declaration,
      signature_filename,
      consent,
      company_legal_name,
      business_type,
      business_activity,
      country_of_incorporation,
      state_of_incorporation,
      city_of_incorporation,
      company_website,
      company_email,
      corporate_tax_id,
      company_contact_number,
      authorized_signatory_full_name,
      signatory_designation,
      signatory_email,
      signatory_phone_number,
      authority_type,
      relationship_to_company,
      certificate_of_incorporation_filename,
      tax_license_filename,
      board_resolution_filename,
      shareholder_list_filename,
    } = req.body;

    // Validate required fields

    const error = validateSignupPayload(req.body);
    if (error) return res.status(error.status).json({ message: error.message });

    // Check if user already exists

    const existing = await User.findOne({ email });
    if (existing) return res.status(409).json({ message: "Email already registered" });


    const randomPassword = crypto.randomBytes(32).toString('hex');
    const passwordHash = await bcrypt.hash(randomPassword, 10);

    const user = new User({
      userId: uuidv4(),
      account_type,
      name: `${first_name} ${middle_name ? middle_name + ' ' : ''}${last_name}`,
      gender,
      date_of_birth,
      nationality,
      email,
      mobile_number,
      alternate_mobile_number,
      whatsapp_number,
      country_of_residence,
      state,
      city,
      zip,
      address,
      type_of_residency,
      occupation,
      highest_education_qualification,
      purpose_of_account_opening,
      preferred_communication_method,
      source_of_funds,
      additional_details,
      live_selfie_filename,
      original_passport_filename,
      business_proof_filename,
      FATCA_or_CRS_Declaration,
      signature_filename,
      consent,
      passwordHash,
      company: account_type === 'corporate' ? {
        company_legal_name,
        business_type,
        business_activity,
        country_of_incorporation,
        state_of_incorporation,
        city_of_incorporation,
        company_website,
        company_email,
        corporate_tax_id,
        company_contact_number,
        authorized_signatory_full_name,
        signatory_designation,
        signatory_email,
        signatory_phone_number,
        authority_type,
        relationship_to_company,
        certificate_of_incorporation_filename,
        tax_license_filename,
        board_resolution_filename,
        shareholder_list_filename,
      } : undefined
    });

    console.log("User object created:", user);

    const userCreated = await user.save();

    console.log("User saved to database:", userCreated);

    if (!userCreated) return res.status(500).json({ message: "Failed to create user" });

    res.status(201).json({ message: "Signup successful" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.initiateLogin = async (req, res) => {
  const { role, email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: "Email not found. Please sign up first." });


    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) return res.status(401).json({ message: "Invalid password" });

    const code = generateCode();
    const expires = new Date(Date.now() + 10 * 60 * 1000);

    user.verificationCode = code;
    user.codeExpires = expires;
    await user.save();

    await sendVerificationCode(email, code);

    res.status(200).json({ message: "Verification code sent" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.verifyCode = async (req, res) => {
  const { email, code } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user || user.verificationCode !== code || user.codeExpires < new Date()) {
      return res.status(400).json({ message: "Invalid or expired code" });
    }

    user.verificationCode = undefined;
    user.codeExpires = undefined;
    await user.save();

    res.status(200).json({ message: "Verified. Redirecting to dashboard." });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
