// backend/controllers/analyticsController.js

exports.getAnalyticsData = function (req, res) {
  // Example: send some dummy data
  res.json({ data: "Sample analytics data" });
};