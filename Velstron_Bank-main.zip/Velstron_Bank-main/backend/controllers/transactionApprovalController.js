const Transaction = require('../models/transaction');

// Get all pending transactions
exports.getPendingTransactions = async (req, res) => {
  try {
    const transactions = await Transaction.find({ status: 'Pending' });
    res.json(transactions);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};

// Get all approved transactions
exports.getApprovedTransactions = async (req, res) => {
  try {
    const transactions = await Transaction.find({ status: 'Approved' });
    res.json(transactions);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};

// Approve a transaction
exports.approveTransaction = async (req, res) => {
  try {
    const { id } = req.params;
    const { approvalComments } = req.body;

    const transaction = await Transaction.findByIdAndUpdate(
      id,
      { status: 'Approved', approvalComments },
      { new: true }
    );

    if (!transaction) {
      return res.status(404).json({ message: 'Transaction not found' });
    }
    res.json(transaction);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};

// Reject a transaction
exports.rejectTransaction = async (req, res) => {
  try {
    const { id } = req.params;
    const { rejectReason } = req.body;

    const transaction = await Transaction.findByIdAndUpdate(
      id,
      { status: 'Rejected', rejectReason },
      { new: true }
    );

    if (!transaction) {
      return res.status(404).json({ message: 'Transaction not found' });
    }
    res.json(transaction);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};