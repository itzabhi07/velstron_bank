const UserAccount = require('../models/account');
const TransactionRequest = require('../models/transactionRequest');

const fundTransfer = async (req, res) => {
  try {
    const userId = req.user._id; // Get user ID from authentication middleware
    const { amount, direction } = req.body; // Get transfer amount and direction from request

    // Check if amount is valid (not empty or <= 0)
    if (!amount || amount <= 0) {
      return res.status(400).json({ error: 'Invalid transfer amount' });
    }

    // Find user's account details in database
    const account = await UserAccount.findOne({ userId });
    if (!account) {
      // If no account found, send error response
      return res.status(404).json({ error: 'Account not found' });
    }

    if (direction === 'coldToHot') {
      // If transfer is from Cold to Hot account

      // Calculate minimum and maximum allowed transfer limits (5% to 20% of cold balance)
      const minLimit = account.coldAccountBalance * 0.05;
      const maxLimit = account.coldAccountBalance * 0.20;

      // Check if amount is within allowed limits
      if (amount < minLimit || amount > maxLimit) {
        return res.status(400).json({ 
          error: "Transfer amount must be between ${minLimit.toFixed(2)} and ${maxLimit.toFixed(2)"}
        );
      }

      // Check if cold account has enough balance to transfer
      if (account.coldAccountBalance < amount) {
        return res.status(400).json({ error: 'Insufficient cold account balance' });
      }

      // Perform transfer: deduct from cold account and add to hot account
      account.coldAccountBalance -= amount;
      account.hotAccountBalance += amount;

    } else if (direction === 'hotToCold') {
      // If transfer is from Hot to Cold account

      // Check if hot account has enough balance
      if (account.hotAccountBalance < amount) {
        return res.status(400).json({ error: 'Insufficient hot account balance' });
      }

      // Perform transfer: deduct from hot account and add to cold account
      account.hotAccountBalance -= amount;
      account.coldAccountBalance += amount;

    } else {
      // If transfer direction is invalid, return error
      return res.status(400).json({ error: 'Invalid transfer direction' });
    }

    // Save updated account balances to database
    await account.save();

    // Send success response with updated balances
    return res.json({
      message: 'Transfer successful',
      hotAccountBalance: account.hotAccountBalance,
      coldAccountBalance: account.coldAccountBalance
    });

  } catch (error) {
    // Catch any server errors and log them, then send generic error response
    console.error('Error during fund transfer:', error);
    return res.status(500).json({ error: 'Server error' });
  }
};

// Set desired % of Cold funds to be kept in Hot account
const setHotAccountHolding = async (req, res) => {
  try {
    const userId = req.user._id;
    const { percentage } = req.body;

    // Validate %
    if (percentage < 5 || percentage > 20) {
      return res.status(400).json({ error: 'Percentage must be between 5% and 20%' });
    }

    const account = await UserAccount.findOne({ userId });
    if (!account) return res.status(404).json({ error: 'Account not found' });

    // Calculate and update balances
    const targetHotBalance = (percentage / 100) * (account.hotAccountBalance + account.coldAccountBalance);
    const diff = targetHotBalance - account.hotAccountBalance;

    if (diff > 0 && account.coldAccountBalance >= diff) {
      account.hotAccountBalance += diff;
      account.coldAccountBalance -= diff;
    } else if (diff < 0 && account.hotAccountBalance >= Math.abs(diff)) {
      account.hotAccountBalance += diff;
      account.coldAccountBalance -= diff;
    } else {
      return res.status(400).json({ error: 'Insufficient balance to adjust holding' });
    }

    await account.save();

    res.json({ message: 'Hot account holding updated', hotAccountBalance: account.hotAccountBalance });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// User creates deposit or withdrawal request
const createTransactionRequest = async (req, res) => {
  try {
    const userId = req.user._id;
    const { type, amount } = req.body;

    if (!['deposit', 'withdrawal'].includes(type)) {
      return res.status(400).json({ error: 'Invalid transaction type' });
    }

    if (!amount || amount <= 0) {
      return res.status(400).json({ error: 'Invalid amount' });
    }

    const request = new TransactionRequest({ userId, type, amount });
    await request.save();

    res.json({ message: 'Transaction request submitted', request });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Returns VELSTRON ID & Account Numbers for the logged-in user
const getAccountDetails = async (req, res) => {
  try {
    const userId = req.user._id;
    const account = await UserAccount.findOne({ userId });

    if (!account) return res.status(404).json({ error: 'Account not found' });

    res.json({
      velstronId: account.velstronId,
      hotAccountNumber: account.hotAccountNumber,
      coldAccountNumber: account.coldAccountNumber
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Placeholder for getFundSummary
const getFundSummary = async (req, res) => {
  try {
    // TODO: Implement logic to get fund summary
    res.json({ message: 'getFundSummary not implemented yet' });
  } catch (error) {
    console.error('Error in getFundSummary:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

module.exports = {
  getFundSummary, // Added export
  fundTransfer,
  setHotAccountHolding,
  createTransactionRequest,
  getAccountDetails
};