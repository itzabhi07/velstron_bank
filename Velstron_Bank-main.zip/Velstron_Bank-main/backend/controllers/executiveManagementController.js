// backend/controllers/executiveManagementController.js
const Executive = require('../models/executive');

// Get all executives
exports.getExecutives = async (req, res) => {
  try {
    const executives = await Executive.find();
    res.json(executives);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};

// Add new executive
exports.addExecutive = async (req, res) => {
  try {
    const newExec = new Executive(req.body);
    const savedExec = await newExec.save();
    res.status(201).json(savedExec);
  } catch (error) {
    res.status(400).json({ message: 'Bad request', error: error.message });
  }
};

// Update executive by ID
exports.updateExecutive = async (req, res) => {
  try {
    const updatedExec = await Executive.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!updatedExec) return res.status(404).json({ message: 'Executive not found' });
    res.json(updatedExec);
  } catch (error) {
    res.status(400).json({ message: 'Bad request', error: error.message });
  }
};

// Delete executive by ID
exports.deleteExecutive = async (req, res) => {
  try {
    const deletedExec = await Executive.findByIdAndDelete(req.params.id);
    if (!deletedExec) return res.status(404).json({ message: 'Executive not found' });
    res.json({ message: 'Executive deleted' });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};