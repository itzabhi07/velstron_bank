const User = require('../models/user');           // Example user model
const Account = require('../models/account');     // Example account model
const Transaction = require('../models/transaction'); // Example transaction model

// Mock function to simulate async DB call for demo, replace with real queries
async function getAnalyticsData(req, res) {
  try {
    // Total AUM Global: Sum of AUM from accounts collection
    const totalAUMGlobal = await Account.aggregate([
      { $group: { _id: null, totalAUM: { $sum: "$aum" } } }
    ]);

    // Total AUM By Country: group by country, sum aum
    const totalAUMByCountry = await Account.aggregate([
      { $group: { _id: "$country", totalAUM: { $sum: "$aum" } } },
      { $project: { country: "$_id", aum: "$totalAUM", _id: 0 } }
    ]);

    // Monthly Net Flow (last 6 months): sum netFlow by month
    const monthlyNetFlow = await Transaction.aggregate([
      { 
        $match: {
          date: { $gte: new Date(new Date().setMonth(new Date().getMonth() - 6)) }
        }
      },
      { 
        $group: {
          _id: { $dateToString: { format: "%b", date: "$date" } },
          netFlow: { $sum: "$amount" }
        }
      },
      { $project: { month: "$_id", netFlow: 1, _id: 0 } },
      { $sort: { month: 1 } }
    ]);

    // User Level MIS: basic info about users
    const userLevelMIS = await User.find({}, { _id: 1, totalInvestment: 1, activeSince: 1 }).lean();

    // Allocation Trends (hot/cold percentages) - example static or calculated
    const hotAllocation = 70;  // For example, calculate from some logic
    const coldAllocation = 30;

    // Country-wise Performance (returns rate) - example static or calculated
    const countryWisePerformance = totalAUMByCountry.map(c => ({
      country: c.country,
      performance: Math.random() * 0.1 // Mock performance, replace with actual
    }));

    // Top Accounts by AUM
    const topAccountsByAUM = await Account.find({}, { accountId: 1, aum: 1 }).sort({ aum: -1 }).limit(5).lean();

    res.json({
      totalAUMGlobal: totalAUMGlobal[0]?.totalAUM || 0,
      totalAUMByCountry,
      monthlyNetFlow,
      userLevelMIS,
      allocationTrends: { hot: hotAllocation, cold: coldAllocation },
      countryWisePerformance,
      topAccountsByAUM,
    });

  } catch (error) {
    console.error("Error fetching analytics data:", error);
    res.status(500).json({ message: "Failed to fetch analytics data." });
  }
}

module.exports = { getAnalyticsData };