// backend/middleware/authMiddleware.js

module.exports = function authMiddleware(req, res, next) {
  // Example: Simple check
  if (req.headers.authorization) {
    next();
  } else {
    res.status(401).json({ message: "Unauthorized" });
  }
};