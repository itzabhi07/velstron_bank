import axios from 'axios';

// Fetch analytics data
export const fetchAnalyticsData = async () => {
  try {
    const response = await axios.get('/api/analytics');  // Hitting the backend analytics route
    return response.data;  // Return analytics data
  } catch (error) {
    console.error('Error fetching analytics data:', error);
  }
};