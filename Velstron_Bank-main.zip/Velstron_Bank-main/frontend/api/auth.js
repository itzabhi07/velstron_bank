import axios from 'axios';

// API call for user signup
export const signup = async (userData) => {
  try {
    const response = await axios.post('/api/signup', userData);  // Hitting the backend signup route
    return response.data;  // Return response after successful signup
  } catch (error) {
    console.error('Error during signup:', error);
  }
};

// API call for user login
export const login = async (loginData) => {
  try {
    const response = await axios.post('/api/login', loginData);  // Hitting the backend login route
    return response.data;  // Return login response
  } catch (error) {
    console.error('Error during login:', error);
  }
};

// API call for verifying code (for two-factor authentication)
export const verifyCode = async (verificationData) => {
  try {
    const response = await axios.post('/api/verify-code', verificationData);  // Hitting the verify-code route
    return response.data;  // Return verification response
  } catch (error) {
    console.error('Error during code verification:', error);
  }
};