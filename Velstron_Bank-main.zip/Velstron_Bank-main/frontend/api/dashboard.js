import axios from 'axios';

// Fetch fund summary data
export const getFundSummary = async () => {
  try {
    const response = await axios.get('/api/dashboard/fund-summary');
    return response.data;  // Return fund summary data
  } catch (error) {
    console.error('Error fetching fund summary:', error);
  }
};

// Create fund transfer request
export const fundTransfer = async (transferData) => {
  try {
    const response = await axios.post('/api/dashboard/fund-transfer', transferData);
    return response.data;  // Return transfer status
  } catch (error) {
    console.error('Error transferring funds:', error);
  }
};

// Set hot account holding percentage
export const setHotAccountHolding = async (holdingData) => {
  try {
    const response = await axios.post('/api/dashboard/set-hot-holding', holdingData);
    return response.data;  // Return holding status
  } catch (error) {
    console.error('Error setting hot holding:', error);
  }
};

// Create transaction request (deposit/withdrawal)
export const createTransactionRequest = async (transactionData) => {
  try {
    const response = await axios.post('/api/dashboard/transaction-request', transactionData);
    return response.data;  // Return transaction status
  } catch (error) {
    console.error('Error creating transaction request:', error);
  }
};

// Fetch account details
export const getAccountDetails = async () => {
  try {
    const response = await axios.get('/api/dashboard/account-details');
    return response.data;  // Return account details
  } catch (error) {
    console.error('Error fetching account details:', error);
  }
};