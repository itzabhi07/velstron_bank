import axios from 'axios';

// Fetch fund flow data
export const getFundFlows = async () => {
  try {
    const response = await axios.get('/api/fundflows');  // Hitting the backend fundflows route
    return response.data;  // Return fund flow data
  } catch (error) {
    console.error('Error fetching fund flows:', error);
  }
};