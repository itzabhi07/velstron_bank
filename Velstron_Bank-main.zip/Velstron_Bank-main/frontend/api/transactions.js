import axios from 'axios';

// Fetch pending transactions
export const getPendingTransactions = async () => {
  try {
    const response = await axios.get('/api/transactions/pending');
    return response.data;  // Return pending transactions
  } catch (error) {
    console.error('Error fetching pending transactions:', error);
  }
};

// Fetch approved transactions
export const getApprovedTransactions = async () => {
  try {
    const response = await axios.get('/api/transactions/approved');
    return response.data;  // Return approved transactions
  } catch (error) {
    console.error('Error fetching approved transactions:', error);
  }
};

// Approve a transaction
export const approveTransaction = async (id) => {
  try {
    const response = await axios.put(`/api/transactions/${id}/approve`);
    return response.data;  // Return updated transaction data after approval
  } catch (error) {
    console.error('Error approving transaction:', error);
  }
};

// Reject a transaction
export const rejectTransaction = async (id) => {
  try {
    const response = await axios.put(`/api/transactions/${id}/reject`);
    return response.data;  // Return updated transaction data after rejection
  } catch (error) {
    console.error('Error rejecting transaction:', error);
  }
};