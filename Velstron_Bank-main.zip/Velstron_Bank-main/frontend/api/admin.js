import axios from 'axios';

// Get all users
export const fetchAllUsers = async () => {
  try {
    const response = await axios.get('/api/admin/users');
    return response.data;  // Return users list
  } catch (error) {
    console.error('Error fetching users:', error);
  }
};

// Approve executive review for a user
export const approveExecutiveReview = async (userId) => {
  try {
    const response = await axios.put(/api/admin/executive-review/${userId}/approve);
    return response.data;  // Return updated user data
  } catch (error) {
    console.error('Error approving executive review:', error);
  }
};

// Get security settings
export const fetchSecuritySettings = async () => {
  try {
    const response = await axios.get('/api/admin/security-settings');
    return response.data;  // Return security settings data
  } catch (error) {
    console.error('Error fetching security settings:', error);
  }
};

// Update security settings
export const updateSecuritySettings = async (settingsData) => {
  try {
    const response = await axios.put('/api/admin/security-settings', settingsData);
    return response.data;  // Return updated security settings data
  } catch (error) {
    console.error('Error updating security settings:', error);
  }
};

// Get system settings
export const fetchSystemSettings = async () => {
  try {
    const response = await axios.get('/api/admin/system-settings');
    return response.data;  // Return system settings data
  } catch (error) {
    console.error('Error fetching system settings:', error);
  }
};

// Update system settings
export const updateSystemSettings = async (settingsData) => {
  try {
    const response = await axios.put('/api/admin/system-settings', settingsData);
    return response.data;  // Return updated system settings data
  } catch (error) {
    console.error('Error updating system settings:', error);
  }
};