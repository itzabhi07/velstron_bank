import axios from 'axios';

// Fetch all executives
export const getExecutives = async () => {
  try {
    const response = await axios.get('/api/executives');
    return response.data;  // Return list of executives
  } catch (error) {
    console.error('Error fetching executives:', error);
  }
};

// Add a new executive
export const addExecutive = async (executiveData) => {
  try {
    const response = await axios.post('/api/executives', executiveData);
    return response.data;  // Return the added executive
  } catch (error) {
    console.error('Error adding executive:', error);
  }
};

// Update an executive
export const updateExecutive = async (id, updatedData) => {
  try {
    const response = await axios.put(`/api/executives/${id}, updatedData`);
    return response.data;  // Return the updated executive
  } catch (error) {
    console.error('Error updating executive:', error);
  }
};

// Delete an executive
export const deleteExecutive = async (id) => {
  try {
    const response = await axios.delete(`/api/executives/${id}`);
    return response.data;  // Return delete status
  } catch (error) {
    console.error('Error deleting executive:', error);
  }
};s