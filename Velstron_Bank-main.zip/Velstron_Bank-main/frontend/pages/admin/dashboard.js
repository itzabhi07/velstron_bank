import React from 'react';
import UserList from '../../components/UserList';
import Alerts from '../../components/Alerts';
import SecuritySettings from '../../components/SecuritySettings';
import AnalyticsData from '../../components/AnalyticsData';

const Dashboard = () => {
  return (
    <div>
      <h1>Admin Dashboard</h1>
      <UserList />
      <Alerts />
      <SecuritySettings />
       <AnalyticsData />
    </div>
  );
};

export default Dashboard;