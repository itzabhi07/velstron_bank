import React from 'react';
import VerifyCode from '../../components/VerifyCode';  // Importing VerifyCode component

const VerifyCodePage = () => {
  return (
    <div>
      <VerifyCode />
    </div>
  );
};

export default VerifyCodePage;