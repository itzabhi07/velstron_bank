import React from 'react';
import Signup from '../../components/Signup';  // Importing Signup component

const SignupPage = () => {
  return (
    <div>
      <Signup />
    </div>
  );
};

export default SignupPage;