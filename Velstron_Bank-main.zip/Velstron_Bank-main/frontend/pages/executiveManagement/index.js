import React from 'react';
import ExecutiveList from '../../components/ExecutiveList';  // Importing ExecutiveList component
import AddExecutive from '../../components/AddExecutive';  // Importing AddExecutive component

const ExecutiveManagement = () => {
  return (
    <div>
      <h1>Executive Management</h1>
      <AddExecutive />
      <ExecutiveList />
    </div>
  );
};

export default ExecutiveManagement;