import React from 'react';
import FundFlow from '../../components/FundFlow';  // Import FundFlow component

const FundFlowsPage = () => {
  return (
    <div>
      <h1>Fund Flow Overview</h1>
      <FundFlow />
    </div>
  );
};

export default FundFlowsPage;