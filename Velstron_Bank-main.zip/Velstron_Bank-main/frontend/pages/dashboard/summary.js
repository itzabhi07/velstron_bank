import React from 'react';
import FundSummary from '../../components/FundSummary';  // Import FundSummary component
import FundTransfer from '../../components/FundTransfer';  // Import FundTransfer component

const Dashboard = () => {
  return (
    <div>
      <h1>Dashboard</h1>
      <FundSummary />
      <FundTransfer />
      {/* Add more components like SetHotAccountHolding, TransactionRequest, AccountDetails */}
    </div>
  );
};

export default Dashboard;