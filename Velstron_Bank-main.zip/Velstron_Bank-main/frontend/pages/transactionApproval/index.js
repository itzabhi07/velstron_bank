import React from 'react';
import PendingTransactions from '../../components/PendingTransactions';  // Import PendingTransactions component
import ApprovedTransactions from '../../components/ApprovedTransactions';  // Import ApprovedTransactions component

const TransactionApprovalPage = () => {
  return (
    <div>
      <h1>Transaction Approval</h1>
      <PendingTransactions />  {/* Display Pending Transactions */}
      <ApprovedTransactions />  {/* Display Approved Transactions */}
    </div>
  );
};

export default TransactionApprovalPage;