import React from 'react';
import CreateUser from '../../components/CreateUser';
import UserList from '../../components/UserList';

const UsersPage = () => {
  return (
    <div>
      <h1>User Management</h1>
      <CreateUser />
      <UserList />
    </div>
  );
};

export default UsersPage;