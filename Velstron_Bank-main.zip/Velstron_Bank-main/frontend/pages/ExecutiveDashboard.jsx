// frontend/src/pages/ExecutiveDashboard.jsx
import React from 'react';
import TransactionApprovalButton from '../components/TransactionApprovalButton';

const ExecutiveDashboard = () => {
    const transactionId = 'some-transaction-id';  // Transaction ID passed dynamically

    return (
        <div>
            <h1>Executive Dashboard</h1>
            <TransactionApprovalButton transactionId={transactionId} />
        </div>
    );
};

export default ExecutiveDashboard;