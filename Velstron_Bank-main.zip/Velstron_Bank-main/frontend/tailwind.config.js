/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: '#0d62a6', // Blue for boxes
        secondary: '#ffdd00', // Yellow for emphasis
        background: '#ffffff', // White background
        text: '#000000', // Black text
        card: '#ffffff', // White card background
        input: '#f3f4f6', // Light grey for input fields
        border: '#d1d5db', // Light grey for borders
        ring: '#0d62a6', // Blue ring color for focus
        muted: '#6b7280', // Grey for muted text
        'muted-foreground': '#6b7280', // Grey for muted foreground text
        accent: '#e5e7eb', // Light grey accent
        'accent-foreground': '#374151', // Dark grey accent foreground
        popover: '#ffffff', // White popover background
        'popover-foreground': '#000000', // Black popover foreground text
        card: '#ffffff',
        'card-foreground': '#000000',
      },
    },
  },
  plugins: [require('tailwindcss-animate')],
}