"use client";
import Image from "next/image";
import Link from "next/link";
import { useState, useEffect } from "react";
import { FaUserCircle, FaShieldAlt, FaBuilding } from "react-icons/fa";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
export default function Home() {
  const [highlights, setHighlights] = useState([]);

  useEffect(() => {
    setTimeout(() => {
      setHighlights([
        {
          title: "₹50K+ Crores AUM",
          description: "Assets under management across UHNW clients.",
        },
        {
          title: "99.99% Security Uptime",
          description: "Banking with confidence and reliability.",
        },
        {
          title: "Global Coverage",
          description: "Serving clients across 40+ countries.",
        },
      ]);
    }, 1000);
  }, []);

  return (
    <main className="min-h-screen bg-gray-50 text-gray-900">
      {/* Top Bar */}
      <div className="bg-blue-900 text-white py-2 text-sm">
        <div className="container mx-auto px-6 flex justify-end space-x-4">
          <Link href="/help" className="hover:underline">
            Help
          </Link>
          <Link href="/contactus" className="hover:underline">
            Contact Us
          </Link>
        </div>
      </div>

      {/* Navigation Bar */}
      <nav className="bg-white shadow-md py-4 px-6 sticky top-0 z-10">
        <div className="container mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center">
            <Image
              src="/images/logo_crop.jpg"
              alt="Velstron Bank Logo"
              width={180}
              height={50}
              className="mr-4 rounded-md shadow-sm"
            />
            <span className="font-extrabold text-xl text-blue-900 tracking-tight hidden sm:block">
              Velstron Bank
            </span>
          </Link>
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-3">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    className="flex items-center text-blue-700 hover:text-blue-900"
                  >
                    <FaUserCircle className="mr-1 w-4 h-4" /> Login
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56 bg-white border border-gray-200 shadow-lg">
                  <DropdownMenuItem asChild>
                    <a
                      href="/login/adminLogin"
                      className="flex items-center w-full px-4 py-2 hover:bg-blue-50"
                    >
                      <FaShieldAlt className="mr-2 w-4 h-4" />
                      Admin Login
                    </a>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <a
                      href="/login/adminLogin"
                      className="flex items-center w-full px-4 py-2 hover:bg-blue-50"
                    >
                      <FaBuilding className="mr-2 w-4 h-4" />
                      Executive Login
                    </a>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <a
                      href="/login/userLogin"
                      className="flex items-center w-full px-4 py-2 hover:bg-blue-50"
                    >
                      <FaUserCircle className="mr-2 w-4 h-4" />
                      User Login
                    </a>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <a
                href="/signup"
                className="bg-blue-900 text-white rounded-full px-4 py-2 hover:bg-blue-800 font-medium transition-colors duration-300"
              >
                Sign Up
              </a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-blue-100 py-24 px-6 relative overflow-hidden">
        <div className="container mx-auto text-center md:text-left md:flex md:items-center">
          <div className="md:w-1/2 md:pr-10">
            <h1 className="text-4xl md:text-5xl font-extrabold text-blue-900 tracking-tight leading-tight mb-6">
              Secure and Private Banking for Your Unique Needs
            </h1>
            <p className="text-lg md:text-xl text-gray-700 leading-relaxed mb-8">
              Experience a new standard in wealth management. Tailored solutions
              for Ultra High Net Worth Individuals and Corporations.
            </p>
            <Link
              href="/explore-services"
              className="inline-block px-8 py-3 bg-blue-900 text-white rounded-full hover:bg-blue-800 transition-colors duration-300 font-semibold shadow-lg"
            >
              Explore Our Services
            </Link>
          </div>
          <div className="md:w-1/2 mt-12 md:mt-0">
            <h2 className="text-2xl font-bold text-blue-800 mb-4">
              Our Highlights
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {highlights.length > 0 ? (
                highlights.map((item, index) => (
                  <div
                    key={index}
                    className="bg-white p-4 rounded-lg shadow-md"
                  >
                    <h3 className="text-lg font-semibold text-blue-900">
                      {item.title}
                    </h3>
                    <p className="text-sm text-gray-700">{item.description}</p>
                  </div>
                ))
              ) : (
                <p className="text-blue-700">Loading highlights...</p>
              )}
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 h-full w-1/2 bg-blue-200 opacity-20 -skew-x-12 transform origin-top-right"></div>
      </section>

      {/* Footer */}
      <footer className="bg-blue-900 text-white py-12 px-6">
        <div className="container mx-auto grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-8">
          <div>
            <h4 className="text-lg font-semibold mb-4">About Velstron Bank</h4>
            <p className="text-gray-300 text-sm leading-relaxed">
              Building lasting relationships through trust and expertise in
              wealth management.
            </p>
            <div className="mt-4">
              <Link
                href="/about-us"
                className="text-blue-300 hover:underline text-sm"
              >
                More About Us
              </Link>
            </div>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4">Our Services</h4>
            <ul className="text-gray-300 text-sm space-y-2">
              <li>
                <Link href="/private-banking" className="hover:underline">
                  Private Banking
                </Link>
              </li>
              <li>
                <Link href="/corporate-solutions" className="hover:underline">
                  Corporate Solutions
                </Link>
              </li>
              <li>
                <Link href="/wealth-management" className="hover:underline">
                  Wealth Management
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4">Help & Support</h4>
            <ul className="text-gray-300 text-sm space-y-2">
              <li>
                <Link href="/faq" className="hover:underline">
                  FAQ
                </Link>
              </li>
              <li>
                <Link href="/support" className="hover:underline">
                  Customer Support
                </Link>
              </li>
              <li>
                <Link href="/security" className="hover:underline">
                  Security
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4">Legal & Policies</h4>
            <ul className="text-gray-300 text-sm space-y-2">
              <li>
                <Link href="/privacy-policy" className="hover:underline">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms-of-service" className="hover:underline">
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="container mx-auto mt-8 text-center text-gray-400 text-sm">
          &copy; {new Date().getFullYear()} Velstron Bank. All rights reserved.
        </div>
      </footer>
    </main>
  );
}
