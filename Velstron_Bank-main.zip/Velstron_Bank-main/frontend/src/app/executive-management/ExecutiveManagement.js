import React, { useEffect, useState } from 'react';
import { getExecutives, addExecutive, updateExecutive, deleteExecutive } from '../services/ExecutiveService';

const ExecutiveManagement = () => {
  const [executives, setExecutives] = useState([]);
  const [executiveData, setExecutiveData] = useState({ name: '', position: '' });

  // Fetch executives on component mount
  useEffect(() => {
    const fetchExecutives = async () => {
      try {
        const data = await getExecutives();
        setExecutives(data);
      } catch (error) {
        console.error('Failed to fetch executives', error);
      }
    };
    fetchExecutives();
  }, []);

  // Handle adding a new executive
  const handleAddExecutive = async () => {
    try {
      const newExecutive = await addExecutive(executiveData);
      setExecutives([...executives, newExecutive]);
    } catch (error) {
      console.error('Error adding executive:', error);
    }
  };

  // Handle updating an executive
  const handleUpdateExecutive = async (id) => {
    try {
      const updatedExecutive = await updateExecutive(id, executiveData);
      setExecutives(executives.map(exec => exec.id === id ? updatedExecutive : exec));
    } catch (error) {
      console.error('Error updating executive:', error);
    }
  };

  // Handle deleting an executive
  const handleDeleteExecutive = async (id) => {
    try {
      await deleteExecutive(id);
      setExecutives(executives.filter(exec => exec.id !== id));
    } catch (error) {
      console.error('Error deleting executive:', error);
    }
  };

  return (
    <div>
      <h1>Executive Management</h1>
      
      <input 
        type="text" 
        value={executiveData.name} 
        onChange={(e) => setExecutiveData({ ...executiveData, name: e.target.value })} 
        placeholder="Executive Name" 
      />
      <input 
        type="text" 
        value={executiveData.position} 
        onChange={(e) => setExecutiveData({ ...executiveData, position: e.target.value })} 
        placeholder="Executive Position" 
      />
      <button onClick={handleAddExecutive}>Add Executive</button>
      
      <h2>Executives List</h2>
      <ul>
        {executives.map((executive) => (
          <li key={executive.id}>
            {executive.name} - {executive.position}
            <button onClick={() => handleUpdateExecutive(executive.id)}>Update</button>
            <button onClick={() => handleDeleteExecutive(executive.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ExecutiveManagement;