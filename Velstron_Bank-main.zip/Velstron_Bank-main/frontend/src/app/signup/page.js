"use client";
import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { Check, AlertCircle } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Upload } from "lucide-react";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import countries from "i18n-iso-countries";
import enLocale from "i18n-iso-countries/langs/en.json";
import ReactDatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

countries.registerLocale(enLocale);
const countryList = Object.entries(countries.getNames("en")).map(
  ([code, name]) => ({
    value: code,
    label: name,
  })
);

const industries = [
  { label: "Finance", value: "finance" },
  { label: "Technology", value: "technology" },
  { label: "Real Estate", value: "real_estate" },
  { label: "Healthcare", value: "healthcare" },
  { label: "Education", value: "education" },
  { label: "Manufacturing", value: "manufacturing" },
  { label: "Retail", value: "retail" },
  { label: "Other", value: "other" },
];

const occupations = [
  { label: "Business Owner", value: "business_owner" },
  { label: "Salaried", value: "salaried" },
  { label: "Investor", value: "investor" },
  { label: "Retired", value: "retired" },
  { label: "Other", value: "other" },
];

const businessTypes = [
  { label: "Private Ltd", value: "private_ltd" },
  { label: "Public Ltd", value: "public_ltd" },
  { label: "LLP", value: "llp" },
  { label: "Trust", value: "trust" },
  { label: "Family Office", value: "family_office" },
  { label: "Partnership", value: "partnership" },
];

const educationQualifications = [
  { label: "High School", value: "high_school" },
  { label: "Bachelor's", value: "bachelors" },
  { label: "Master's", value: "masters" },
  { label: "PhD", value: "phd" },
  { label: "Other", value: "other" },
];

const maritalStatuses = [
  { label: "Single", value: "single" },
  { label: "Married", value: "married" },
  { label: "Divorced", value: "divorced" },
  { label: "Widowed", value: "widowed" },
];

const residencyTypes = [
  { label: "Permanent", value: "permanent" },
  { label: "Temporary", value: "temporary" },
  { label: "NRI", value: "nri" },
  { label: "PIO", value: "pio" },
];

const incomeRanges = [
  { label: "Under $50,000", value: "under_50k" },
  { label: "$50,000 - $100,000", value: "50k_100k" },
  { label: "$100,000 - $250,000", value: "100k_250k" },
  { label: "$250,000 - $500,000", value: "250k_500k" },
  { label: "$500,000 - $1 Million", value: "500k_1m" },
  { label: "Over $1 Million", value: "over_1m" },
];

const accountPurposes = [
  { label: "Asset Holding", value: "asset_holding" },
  { label: "Offshore Reserve", value: "offshore_reserve" },
  { label: "Investment Management", value: "investment_management" },
  { label: "Legacy Planning", value: "legacy_planning" },
  { label: "Other", value: "other" },
];

const signatoryDesignations = [
  { label: "Director", value: "director" },
  { label: "CFO", value: "cfo" },
  { label: "Trustee", value: "trustee" },
  { label: "Partner", value: "partner" },
  { label: "Other", value: "other" },
];

const authorityTypes = [
  { label: "Sole Signatory", value: "sole_signatory" },
  { label: "Joint Signatory", value: "joint_signatory" },
  { label: "Board-Authorized", value: "board_authorized" },
];

const relationships = [
  { label: "Owner", value: "owner" },
  { label: "Trustee", value: "trustee" },
  { label: "Employee", value: "employee" },
  { label: "Partner", value: "partner" },
  { label: "Other", value: "other" },
];

const fundSources = [
  { label: "Salary", value: "salary" },
  { label: "Business Income", value: "business_income" },
  { label: "Investments", value: "investments" },
  { label: "Inheritance", value: "inheritance" },
  { label: "Other", value: "other" },
];

const stepsInfo = [
  { id: 1, title: "General Information" },
  { id: 2, title: "Corporate Information" },
  { id: 3, title: "KYC & Documents" },
];

const formSchema = z.object({
  // Step 1: General Information
  accountType: z.string(),
  firstName: z.string().min(1, "First name is required"),
  middleName: z.string().optional(),
  lastName: z.string().min(1, "Last name is required"),
  gender: z.string().min(1, "Gender is required"),
  dateOfBirth: z.date().nullable().optional(),
  dateOfIncorporation: z.date().nullable().optional(),
  nationality: z.string().min(1, "Nationality is required"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(6, "Valid phone number is required"),
  alternatePhone: z.string().optional(),
  whatsappPhone: z.string().optional(),
  countryOfResidence: z.string().min(1, "Country is required"),
  state: z.string().min(1, "State is required"),
  city: z.string().min(1, "City is required"),
  zipCode: z.string().min(1, "ZIP/Postal code is required"),
  residentialAddress: z.string().min(1, "Address is required"),
  residencyType: z.string().optional(),
  occupation: z.string().optional(),
  industry: z.string().optional(),
  education: z.string().optional(),
  maritalStatus: z.string().optional(),
  incomeRange: z.string().optional(),
  accountPurpose: z.string().min(1, "Account purpose is required"),
  communicationMode: z.string().optional(),

  // Step 2: Corporate Information (conditional)
  companyName: z.string().min(1, "Company name is required"),
  businessType: z.string().min(1, "Business type is required"),
  businessActivity: z.string().min(1, "Business activity is required"),
  countryOfIncorporation: z
    .string()
    .min(1, "Country of incorporation is required"),
  companyState: z.string().min(1, "Company state is required"),
  companyCity: z.string().min(1, "Company city is required"),
  companyWebsite: z.string().url("Invalid URL").optional(),
  companyEmail: z
    .string()
    .email("Invalid company email")
    .min(1, "Company email is required"),
  taxId: z.string().min(1, "Tax ID is required"),
  companyPhone: z.string().min(7, "Valid company phone number is required"),
  signatoryName: z.string().min(1, "Signatory name is required"),
  signatoryDesignation: z.string().min(1, "Signatory designation is required"),
  signatoryEmail: z
    .string()
    .email("Invalid signatory email")
    .min(1, "Signatory email is required"),
  signatoryPhone: z.string().min(7, "Valid signatory phone number is required"),
  authorityType: z.string().min(1, "Authority type is required"),
  relationship: z.string().min(1, "Relationship is required"),

  // Step 3: KYC & Document Submission
  fundsSource: z.string().min(1, "Source of funds is required"),
  fundsDetails: z.string().optional(),
  fatcaDeclaration: z.boolean().default(false),
  taxResidencyCountry: z.string().optional(),
  consent: z.literal(true, {
    errorMap: () => ({ message: "You must agree to the terms" }),
  }),
});

const AccountOpeningForm = () => {
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(1);
  const [showAlert, setShowAlert] = useState(false);
  const [alertType, setAlertType] = useState("success");
  const [alertMessage, setAlertMessage] = useState("");
  const [files, setFiles] = useState({
    selfie: null,
    passport: null,
    businessProof: null,
    signatureImage: null,
    incorporationCertificate: null,
    taxLicense: null,
    boardResolution: null,
    shareholderList: null,
  });

  const form = useForm({
    resolver: zodResolver(formSchema),
    defaultValues: {
      accountType: "uhni",
      firstName: "",
      middleName: "",
      lastName: "",
      gender: "",
      nationality: "",
      email: "",
      phone: "",
      alternatePhone: "",
      whatsappPhone: "",
      countryOfResidence: "",
      state: "",
      city: "",
      zipCode: "",
      residentialAddress: "",
      residencyType: "",
      occupation: "",
      industry: "",
      education: "",
      maritalStatus: "",
      incomeRange: "",
      accountPurpose: "",
      communicationMode: "",

      // Corporate info
      companyName: "",
      businessType: "",
      businessActivity: "",
      countryOfIncorporation: "",
      companyState: "",
      companyCity: "",
      companyWebsite: "",
      companyEmail: "",
      taxId: "",
      companyPhone: "",
      signatoryName: "",
      signatoryDesignation: "",
      signatoryEmail: "",
      signatoryPhone: "",
      authorityType: "",
      relationship: "",

      // KYC info
      fundsSource: "",
      fundsDetails: "",
      fatcaDeclaration: false,
      taxResidencyCountry: "",
      consent: false,
    },
  });

  const accountType = form.watch("accountType");

  const nextStep = async () => {
    let isValid = false;

    if (currentStep === 1) {
      isValid = await validateStepOne();
    } else if (currentStep === 2) {
      isValid = await validateStepTwo();
    }

    if (isValid && currentStep < 3) {
      setCurrentStep(currentStep + 1);
      window.scrollTo(0, 0);
    }
  };

  const validateStepOne = async () => {
    const step1Fields = [
      "accountType",
      "firstName",
      "lastName",
      "gender",
      "nationality",
      "email",
      "phone",
      "countryOfResidence",
      "state",
      "city",
      "zipCode",
      "residentialAddress",
      "accountPurpose",
    ];

    const result = await form.trigger(step1Fields);
    return result;
  };

  const validateStepTwo = async () => {
    if (accountType !== "corporate") return true;

    const step2Fields = [
      "companyName",
      "businessType",
      "businessActivity",
      "countryOfIncorporation",
      "companyState",
      "companyCity",
      "companyEmail",
      "taxId",
      "companyPhone",
      "signatoryName",
      "signatoryDesignation",
      "signatoryEmail",
      "signatoryPhone",
      "authorityType",
      "relationship",
    ];

    const result = await form.trigger(step2Fields);
    return result;
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
      window.scrollTo(0, 0);
    }
  };
  const handleFileUpload = (fieldName, e) => {
    if (e.target.files && e.target.files[0]) {
      setFiles({
        ...files,
        [fieldName]: e.target.files[0],
      });
    }
  };

  const onSubmit = async (data) => {
    console.log("onSubmit triggered");

    try {
      const completeData = {
        ...data,
        ...files,
      };

      console.log("Form submitted with data:", completeData);

      setAlertType("success");
      setAlertMessage("Application submitted successfully!");
      setShowAlert(true);
      window.scrollTo(0, 0);

      await new Promise((resolve) => setTimeout(resolve, 1000));
      router.push("/");
    } catch (error) {
      console.error("Form submission error:", error);

      setAlertType("error");
      setAlertMessage("Error submitting form. Please try again.");
      setShowAlert(true);
      window.scrollTo(0, 0);
    }
  };

  return (
    <div className="container mx-auto py-8 px-4 max-w-5xl">
      {showAlert && (
        <Alert
          className={`mb-4 ${
            alertType === "success"
              ? "bg-green-50 text-green-900 border-green-200"
              : "bg-red-50 text-red-900 border-red-200"
          }`}
        >
          {alertType === "success" ? (
            <Check className="h-4 w-4" />
          ) : (
            <AlertCircle className="h-4 w-4" />
          )}
          <AlertTitle>
            {alertType === "success" ? "Success" : "Error"}
          </AlertTitle>
          <AlertDescription>{alertMessage}</AlertDescription>
        </Alert>
      )}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="text-2xl text-[#174e82]">
            Velstron Bank – Account Opening Form
          </CardTitle>
          <CardDescription>
            Please fill out the form below to open your account
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Step Indicator */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              {stepsInfo.map((step, index) => (
                <React.Fragment key={step.id}>
                  {" "}
                  <div
                    className={`flex flex-col items-center  ${
                      currentStep === step.id
                        ? "text-[#174e82] font-bold"
                        : "text-muted-foreground"
                    }`}
                  >
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 bg-[#174e82] ${
                        currentStep === step.id
                          ? "bg-[#174e82] text-primary-foreground"
                          : currentStep > step.id
                          ? "bg-[#174e82]/20"
                          : "bg-muted"
                      }`}
                    >
                      {step.id}
                    </div>
                    <span className="text-sm">{step.title}</span>
                  </div>
                  {index < stepsInfo.length - 1 && (
                    <div
                      className={`h-1 flex-1 mx-2 ${
                        currentStep > index + 1 ? "bg-[#174e82]" : "bg-muted"
                      }`}
                    ></div>
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>

          <Form {...form}>
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                await form.handleSubmit(onSubmit)(e);
              }}
            >
              {/* Step 1: General Information */}
              {currentStep === 1 && (
                <div>
                  <h3 className="text-xl font-semibold text-[#174e82] mb-6">
                    Step 1: General Information
                  </h3>

                  <div className="space-y-6">
                    {/* Account Type */}
                    <FormField
                      control={form.control}
                      name="accountType"
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          <FormLabel>1. Account Type</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex gap-4"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="uhni" id="uhni" />
                                <Label htmlFor="uhni">UHNI</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem
                                  value="corporate"
                                  id="corporate"
                                />
                                <Label htmlFor="corporate">Corporate</Label>
                              </div>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Full Name */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <FormField
                        control={form.control}
                        name="firstName"
                        render={({ field }) => (
                          <FormItem className="space-y-2">
                            <FormLabel>2. First Name*</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Enter first name"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="middleName"
                        render={({ field }) => (
                          <FormItem className="space-y-2">
                            <FormLabel>Middle Name (optional)</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Enter middle name"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="lastName"
                        render={({ field }) => (
                          <FormItem className="space-y-2">
                            <FormLabel>Last Name*</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter last name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    {/* Gender */}
                    <FormField
                      control={form.control}
                      name="gender"
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          <FormLabel>3. Gender</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex gap-4"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="male" id="male" />
                                <Label htmlFor="male">Male</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="female" id="female" />
                                <Label htmlFor="female">Female</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="other" id="other" />
                                <Label htmlFor="other">Other</Label>
                              </div>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Date of Birth / Incorporation */}
                    <FormField
                      control={form.control}
                      name={
                        accountType === "uhni"
                          ? "dateOfBirth"
                          : "dateOfIncorporation"
                      }
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          {" "}
                          <FormLabel>
                            4.{" "}
                            {accountType === "uhni"
                              ? "Date of Birth"
                              : "Date of Incorporation"}
                          </FormLabel>
                          <FormControl>
                            <ReactDatePicker
                              selected={field.value}
                              onChange={(date) => field.onChange(date)}
                              dateFormat="MMMM d, yyyy"
                              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
                              placeholderText="Select a date"
                              showYearDropdown
                              scrollableYearDropdown
                              yearDropdownItemNumber={100}
                              maxDate={new Date()}
                              minDate={new Date("1900-01-01")}
                              dropdownMode="select"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Nationality */}
                    <FormField
                      control={form.control}
                      name="nationality"
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          <FormLabel>5. Nationality*</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select nationality" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent className="max-h-[200px]">
                              {countryList.map((country) => (
                                <SelectItem
                                  key={country.value}
                                  value={country.value}
                                >
                                  {country.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Email Address */}
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          <FormLabel>6. Email Address*</FormLabel>
                          <FormControl>
                            <Input
                              type="email"
                              placeholder="Enter email address"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Phone Number */}
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          <FormLabel>7. Mobile Number*</FormLabel>
                          <FormControl>
                            <div className="phone-input-container">
                              <PhoneInput
                                country={"us"}
                                value={field.value}
                                onChange={(phone) => field.onChange(phone)}
                                inputClass="form-control"
                                buttonClass="dropdown-button"
                                containerClass="phone-container"
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Alternate Phone Number */}
                    <FormField
                      control={form.control}
                      name="alternatePhone"
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          <FormLabel>
                            8. Alternate Mobile Number (optional)
                          </FormLabel>
                          <FormControl>
                            <div className="phone-input-container">
                              <PhoneInput
                                country={"us"}
                                value={field.value}
                                onChange={(phone) => field.onChange(phone)}
                                inputClass="form-control"
                                buttonClass="dropdown-button"
                                containerClass="phone-container"
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* WhatsApp Number */}
                    <FormField
                      control={form.control}
                      name="whatsappPhone"
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          <FormLabel>9. WhatsApp Number (optional)</FormLabel>
                          <FormControl>
                            <div className="phone-input-container">
                              <PhoneInput
                                country={"us"}
                                value={field.value}
                                onChange={(phone) => field.onChange(phone)}
                                inputClass="form-control"
                                buttonClass="dropdown-button"
                                containerClass="phone-container"
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Country of Residence */}
                    <FormField
                      control={form.control}
                      name="countryOfResidence"
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          <FormLabel>10. Country of Residence*</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select country of residence" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent className="max-h-[200px]">
                              {countryList.map((country) => (
                                <SelectItem
                                  key={country.value}
                                  value={country.value}
                                >
                                  {country.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* State/Province */}
                    <FormField
                      control={form.control}
                      name="state"
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          <FormLabel>11. State / Province*</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Enter state or province"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* City */}
                    <FormField
                      control={form.control}
                      name="city"
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          <FormLabel>12. City*</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter city" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Zip/Postal Code */}
                    <FormField
                      control={form.control}
                      name="zipCode"
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          <FormLabel>13. Zip / Postal Code*</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Enter zip or postal code"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Full Residential Address */}
                    <FormField
                      control={form.control}
                      name="residentialAddress"
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          <FormLabel>14. Full Residential Address*</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Enter your full residential address"
                              {...field}
                              rows={3}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Type of Residency */}
                    <FormField
                      control={form.control}
                      name="residencyType"
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          <FormLabel>15. Type of Residency</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select residency type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {residencyTypes.map((type) => (
                                <SelectItem key={type.value} value={type.value}>
                                  {type.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* UHNI-specific fields */}
                    {accountType === "uhni" && (
                      <>
                        {/* Occupation */}
                        <FormField
                          control={form.control}
                          name="occupation"
                          render={({ field }) => (
                            <FormItem className="space-y-2">
                              <FormLabel>16. Occupation</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select occupation" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {occupations.map((occupation) => (
                                    <SelectItem
                                      key={occupation.value}
                                      value={occupation.value}
                                    >
                                      {occupation.label}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        {/* Industry */}
                        <FormField
                          control={form.control}
                          name="industry"
                          render={({ field }) => (
                            <FormItem className="space-y-2">
                              <FormLabel>17. Industry</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select industry" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {industries.map((industry) => (
                                    <SelectItem
                                      key={industry.value}
                                      value={industry.value}
                                    >
                                      {industry.label}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </>
                    )}

                    {/* Education */}
                    <FormField
                      control={form.control}
                      name="education"
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          <FormLabel>
                            18. Highest Education Qualification (optional)
                          </FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select education qualification" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {educationQualifications.map((edu) => (
                                <SelectItem key={edu.value} value={edu.value}>
                                  {edu.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Marital Status */}
                    <FormField
                      control={form.control}
                      name="maritalStatus"
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          <FormLabel>19. Marital Status (optional)</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select marital status" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {maritalStatuses.map((status) => (
                                <SelectItem
                                  key={status.value}
                                  value={status.value}
                                >
                                  {status.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Annual Income Range */}
                    <FormField
                      control={form.control}
                      name="incomeRange"
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          <FormLabel>20. Annual Income Range</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select income range" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {incomeRanges.map((range) => (
                                <SelectItem
                                  key={range.value}
                                  value={range.value}
                                >
                                  {range.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Purpose of Account Opening */}
                    <FormField
                      control={form.control}
                      name="accountPurpose"
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          <FormLabel>21. Purpose of Account Opening*</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select account purpose" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {accountPurposes.map((purpose) => (
                                <SelectItem
                                  key={purpose.value}
                                  value={purpose.value}
                                >
                                  {purpose.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Preferred Communication Mode */}
                    <FormField
                      control={form.control}
                      name="communicationMode"
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          <FormLabel>
                            22. Preferred Communication Mode
                          </FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex flex-wrap gap-4"
                            >
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="email" id="comm-email" />
                                <Label htmlFor="comm-email">Email</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="phone" id="comm-phone" />
                                <Label htmlFor="comm-phone">Phone</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem
                                  value="whatsapp"
                                  id="comm-whatsapp"
                                />
                                <Label htmlFor="comm-whatsapp">WhatsApp</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem
                                  value="no-preference"
                                  id="comm-no-preference"
                                />
                                <Label htmlFor="comm-no-preference">
                                  No Preference
                                </Label>
                              </div>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              )}
              {/* Step 2: Corporate Information (Only if "Corporate" selected) */}
              {currentStep === 2 && (
                <div>
                  <h3 className="text-xl font-semibold mb-6">
                    Step 2: Corporate Information
                  </h3>

                  {accountType === "corporate" ? (
                    <div className="space-y-6">
                      {/* Company Legal Name */}
                      <FormField
                        control={form.control}
                        name="companyName"
                        render={({ field }) => (
                          <FormItem className="space-y-2">
                            <FormLabel>1. Company Legal Name*</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Enter company legal name"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Business Type */}
                      <FormField
                        control={form.control}
                        name="businessType"
                        render={({ field }) => (
                          <FormItem className="space-y-2">
                            <FormLabel>2. Business Type*</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select business type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {businessTypes.map((type) => (
                                  <SelectItem
                                    key={type.value}
                                    value={type.value}
                                  >
                                    {type.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Business Activity / Nature */}
                      <FormField
                        control={form.control}
                        name="businessActivity"
                        render={({ field }) => (
                          <FormItem className="space-y-2">
                            <FormLabel>
                              3. Business Activity / Nature*
                            </FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Describe business activity"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Country of Incorporation */}
                      <FormField
                        control={form.control}
                        name="countryOfIncorporation"
                        render={({ field }) => (
                          <FormItem className="space-y-2">
                            <FormLabel>4. Country of Incorporation*</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select country of incorporation" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="max-h-[200px]">
                                {countryList.map((country) => (
                                  <SelectItem
                                    key={country.value}
                                    value={country.value}
                                  >
                                    {country.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* State */}
                      <FormField
                        control={form.control}
                        name="companyState"
                        render={({ field }) => (
                          <FormItem className="space-y-2">
                            <FormLabel>5. State*</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter state" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* City */}
                      <FormField
                        control={form.control}
                        name="companyCity"
                        render={({ field }) => (
                          <FormItem className="space-y-2">
                            <FormLabel>6. City*</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter city" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Company Website */}
                      <FormField
                        control={form.control}
                        name="companyWebsite"
                        render={({ field }) => (
                          <FormItem className="space-y-2">
                            <FormLabel>7. Company Website (optional)</FormLabel>
                            <FormControl>
                              <Input
                                type="url"
                                placeholder="Enter company website URL"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Company Email ID */}
                      <FormField
                        control={form.control}
                        name="companyEmail"
                        render={({ field }) => (
                          <FormItem className="space-y-2">
                            <FormLabel>8. Company Email ID*</FormLabel>
                            <FormControl>
                              <Input
                                type="email"
                                placeholder="Enter company email"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Corporate Tax ID / Registration Number */}
                      <FormField
                        control={form.control}
                        name="taxId"
                        render={({ field }) => (
                          <FormItem className="space-y-2">
                            <FormLabel>
                              9. Corporate Tax ID / Registration Number*
                            </FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Enter tax ID or registration number"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Company Contact Number */}
                      <FormField
                        control={form.control}
                        name="companyPhone"
                        render={({ field }) => (
                          <FormItem className="space-y-2">
                            <FormLabel>10. Company Contact Number*</FormLabel>
                            <FormControl>
                              <div className="phone-input-container">
                                <PhoneInput
                                  country={"us"}
                                  value={field.value}
                                  onChange={(phone) => field.onChange(phone)}
                                  inputClass="form-control"
                                  buttonClass="dropdown-button"
                                  containerClass="phone-container"
                                />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Authorized Signatory Full Name */}
                      <FormField
                        control={form.control}
                        name="signatoryName"
                        render={({ field }) => (
                          <FormItem className="space-y-2">
                            <FormLabel>
                              11. Authorized Signatory Full Name*
                            </FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Enter signatory's full name"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Signatory Designation */}
                      <FormField
                        control={form.control}
                        name="signatoryDesignation"
                        render={({ field }) => (
                          <FormItem className="space-y-2">
                            <FormLabel>12. Signatory Designation*</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select signatory designation" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {signatoryDesignations.map((designation) => (
                                  <SelectItem
                                    key={designation.value}
                                    value={designation.value}
                                  >
                                    {designation.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Signatory Email & Mobile */}
                      <div className="space-y-2">
                        <Label>13. Signatory Email & Mobile*</Label>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="signatoryEmail"
                            render={({ field }) => (
                              <FormItem className="space-y-2">
                                <FormControl>
                                  <Input
                                    type="email"
                                    placeholder="Enter signatory's email"
                                    {...field}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="signatoryPhone"
                            render={({ field }) => (
                              <FormItem className="space-y-2">
                                <FormControl>
                                  <div className="phone-input-container">
                                    <PhoneInput
                                      country={"us"}
                                      value={field.value}
                                      onChange={(phone) =>
                                        field.onChange(phone)
                                      }
                                      inputClass="form-control"
                                      buttonClass="dropdown-button"
                                      containerClass="phone-container"
                                    />
                                  </div>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>

                      {/* Authority Type */}
                      <FormField
                        control={form.control}
                        name="authorityType"
                        render={({ field }) => (
                          <FormItem className="space-y-2">
                            <FormLabel>14. Authority Type*</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select authority type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {authorityTypes.map((type) => (
                                  <SelectItem
                                    key={type.value}
                                    value={type.value}
                                  >
                                    {type.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Relationship to Company */}
                      <FormField
                        control={form.control}
                        name="relationship"
                        render={({ field }) => (
                          <FormItem className="space-y-2">
                            <FormLabel>15. Relationship to Company*</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select relationship" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {relationships.map((rel) => (
                                  <SelectItem key={rel.value} value={rel.value}>
                                    {rel.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Upload Certificate of Incorporation */}
                      <div className="space-y-2">
                        <Label htmlFor="incorporationCertificate">
                          16. Upload Certificate of Incorporation*
                        </Label>
                        <div className="flex items-center gap-2">
                          <Input
                            id="incorporationCertificate"
                            type="file"
                            onChange={(e) =>
                              handleFileUpload("incorporationCertificate", e)
                            }
                            className="w-full max-w-sm"
                            accept="image/jpeg, image/png, application/pdf"
                          />
                          <Upload className="h-5 w-5 text-muted-foreground" />
                        </div>
                      </div>

                      {/* Upload Tax License / Business Registration Document */}
                      <div className="space-y-2">
                        <Label htmlFor="taxLicense">
                          17. Upload Tax License / Business Registration
                          Document*
                        </Label>
                        <div className="flex items-center gap-2">
                          <Input
                            id="taxLicense"
                            type="file"
                            onChange={(e) => handleFileUpload("taxLicense", e)}
                            className="w-full max-w-sm"
                            accept="image/jpeg, image/png, application/pdf"
                          />
                          <Upload className="h-5 w-5 text-muted-foreground" />
                        </div>
                      </div>

                      {/* Upload Board Resolution / Consent Letter */}
                      <div className="space-y-2">
                        <Label htmlFor="boardResolution">
                          18. Upload Board Resolution / Consent Letter*
                        </Label>
                        <div className="flex items-center gap-2">
                          <Input
                            id="boardResolution"
                            type="file"
                            onChange={(e) =>
                              handleFileUpload("boardResolution", e)
                            }
                            className="w-full max-w-sm"
                            accept="image/jpeg, image/png, application/pdf"
                          />
                          <Upload className="h-5 w-5 text-muted-foreground" />
                        </div>
                      </div>

                      {/* Upload Shareholder List / Trust Deed (optional) */}
                      <div className="space-y-2">
                        <Label htmlFor="shareholderList">
                          19. Upload Shareholder List / Trust Deed (optional)
                        </Label>
                        <div className="flex items-center gap-2">
                          <Input
                            id="shareholderList"
                            type="file"
                            onChange={(e) =>
                              handleFileUpload("shareholderList", e)
                            }
                            className="w-full max-w-sm"
                            accept="image/jpeg, image/png, application/pdf"
                          />
                          <Upload className="h-5 w-5 text-muted-foreground" />
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="py-10 text-center">
                      <p className="text-lg text-muted-foreground">
                        This section is only applicable for Corporate accounts.
                        Please proceed to the next step.
                      </p>
                    </div>
                  )}
                </div>
              )}
              {/* Step 3: KYC & Document Submission */}
              {currentStep === 3 && (
                <div>
                  <h3 className="text-xl font-semibold mb-6">
                    Step 3: KYC & Document Submission
                  </h3>

                  <div className="space-y-6">
                    {/* Source of Funds */}
                    <FormField
                      control={form.control}
                      name="fundsSource"
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          <FormLabel>1. Source of Funds*</FormLabel>
                          <div className="grid grid-cols-1 gap-4">
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select source of funds" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {fundSources.map((source) => (
                                  <SelectItem
                                    key={source.value}
                                    value={source.value}
                                  >
                                    {source.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="fundsDetails"
                      render={({ field }) => (
                        <FormItem className="space-y-2">
                          <FormLabel className="text-sm text-muted-foreground">
                            Please provide additional details
                          </FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Provide additional details about your source of funds"
                              {...field}
                              rows={3}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Upload Live Selfie */}
                    <div className="space-y-2">
                      <Label htmlFor="selfie">2. Upload Live Selfie*</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          id="selfie"
                          type="file"
                          onChange={(e) => handleFileUpload("selfie", e)}
                          className="w-full max-w-sm"
                          accept="image/jpeg, image/png"
                        />
                        <Upload className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <p className="text-xs text-muted-foreground">
                        JPG or PNG format only
                      </p>
                    </div>

                    {/* Upload Original Passport */}
                    <div className="space-y-2">
                      <Label htmlFor="passport">
                        3. Upload Original Passport*
                      </Label>
                      <div className="flex items-center gap-2">
                        <Input
                          id="passport"
                          type="file"
                          onChange={(e) => handleFileUpload("passport", e)}
                          className="w-full max-w-sm"
                          accept="image/jpeg, image/png, application/pdf"
                        />
                        <Upload className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <p className="text-xs text-muted-foreground">
                        High-resolution JPG or PDF of photo page
                      </p>
                    </div>

                    {/* Upload Business Proof (optional) */}
                    <div className="space-y-2">
                      <Label htmlFor="businessProof">
                        4. Upload Business Proof (optional)
                      </Label>
                      <div className="flex items-center gap-2">
                        <Input
                          id="businessProof"
                          type="file"
                          onChange={(e) => handleFileUpload("businessProof", e)}
                          className="w-full max-w-sm"
                          accept="image/jpeg, image/png, application/pdf"
                        />
                        <Upload className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Company license, tax document, trade registration
                      </p>
                    </div>

                    {/* FATCA / CRS Declaration */}
                    <FormField
                      control={form.control}
                      name="fatcaDeclaration"
                      render={({ field }) => (
                        <FormItem className="space-y-4">
                          <FormLabel>5. FATCA / CRS Declaration*</FormLabel>
                          <div className="space-y-4">
                            <FormControl>
                              <RadioGroup
                                onValueChange={(value) =>
                                  field.onChange(value === "yes")
                                }
                                defaultValue={field.value ? "yes" : "no"}
                                className="flex gap-6"
                              >
                                <div className="flex items-center space-x-2">
                                  <RadioGroupItem value="yes" id="fatca-yes" />
                                  <Label htmlFor="fatca-yes">Yes</Label>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <RadioGroupItem value="no" id="fatca-no" />
                                  <Label htmlFor="fatca-no">No</Label>
                                </div>
                              </RadioGroup>
                            </FormControl>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {form.watch("fatcaDeclaration") && (
                      <FormField
                        control={form.control}
                        name="taxResidencyCountry"
                        render={({ field }) => (
                          <FormItem className="space-y-2">
                            <FormLabel>Country of Tax Residency</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select country of tax residency" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="max-h-[200px]">
                                {countryList.map((country) => (
                                  <SelectItem
                                    key={country.value}
                                    value={country.value}
                                  >
                                    {country.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}

                    {/* Upload Signature Image */}
                    <div className="space-y-2">
                      <Label htmlFor="signatureImage">
                        6. Upload Signature Image*
                      </Label>
                      <div className="flex items-center gap-2">
                        <Input
                          id="signatureImage"
                          type="file"
                          onChange={(e) =>
                            handleFileUpload("signatureImage", e)
                          }
                          className="w-full max-w-sm"
                          accept="image/jpeg, image/png, application/pdf"
                        />
                        <Upload className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Digital or scanned signature
                      </p>
                    </div>

                    {/* Consent Checkbox */}
                    <FormField
                      control={form.control}
                      name="consent"
                      render={({ field }) => (
                        <FormItem className="space-y-2 pt-4">
                          <div className="flex items-start space-x-2">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                                id="consent"
                              />
                            </FormControl>
                            <div className="grid gap-1.5 leading-none">
                              <FormLabel
                                htmlFor="consent"
                                className="text-sm font-medium"
                              >
                                7. Consent*
                              </FormLabel>
                              <p className="text-sm text-muted-foreground">
                                I confirm that the information provided is true
                                and I authorize Velstron Bank to process it for
                                compliance and account setup.
                              </p>
                            </div>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              )}
              {/* Navigation buttons */}{" "}
              <div className="mt-10 flex justify-between">
                {currentStep > 1 && (
                  <Button
                    type="button"
                    variant="outline"
                    className="bg-[#174e82] text-white"
                    onClick={prevStep}
                  >
                    Previous Step
                  </Button>
                )}
                {currentStep < 3 ? (
                  <Button
                    type="button"
                    onClick={nextStep}
                    className="bg-[#174e82] hover:bg-primary/90 ml-auto"
                  >
                    Next Step
                  </Button>
                ) : (
                  <Button
                    type="submit"
                    className="bg-[#174e82] hover:bg-primary/90 ml-auto"
                    disabled={!form.getValues().consent}
                    onClick={async (e) => {
                      await form.handleSubmit(onSubmit(form.getValues()))(e);
                      console.log("Form submitted");
                    }}
                  >
                    Submit Application
                  </Button>
                )}
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
};

export default AccountOpeningForm;
