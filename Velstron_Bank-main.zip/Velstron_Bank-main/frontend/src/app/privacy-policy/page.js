"use client";

import React from 'react';

const PrivacyPolicyPage = () => {
  return (
    <div className="container mx-auto py-10 px-6">
      <h1 className="text-3xl font-bold text-blue-900 mb-6">Privacy Policy</h1>
      <p className="mb-4">
        **Last Updated:** May 31, 2025
      </p>
      <p className="mb-4">
        Velstron Bank ("we," "us," or "our") is committed to protecting your privacy and ensuring the security of your personal information. This Privacy Policy outlines how we collect, use, disclose, and safeguard your information when you interact with our website, services, and applications.
      </p>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">1. Information We Collect</h2>
      <ul className="list-disc list-inside mb-4">
        <li>**Personal Identification Information:** This includes your name, address, email address, phone number, date of birth, Velstron ID, and other similar identifiers.</li>
        <li>**Account Information:** If you are a customer, we collect information related to your accounts, such as account numbers, balances, transaction history, and investment details.</li>
        <li>**Technical Information:** When you visit our website, we may collect technical information such as your IP address, browser type, operating system, device information, and browsing activity. We may use cookies and similar tracking technologies for this purpose.</li>
        <li>**Usage Information:** We collect information about how you use our website and services, including the pages you visit, the features you use, and the time and duration of your activities.</li>
        <li>**Communication Data:** We may collect information from your communications with us, including emails, chat logs, and phone call recordings (with your consent where required by law).</li>
      </ul>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">2. How We Use Your Information</h2>
      <ul className="list-disc list-inside mb-4">
        <li>**To Provide and Manage Services:** To open and manage your accounts, process transactions, provide customer support, and personalize your banking experience.</li>
        <li>**To Communicate with You:** To respond to your inquiries, provide important updates about our services, and send you marketing communications (where permitted by law).</li>
        <li>**To Ensure Security:** To verify your identity, protect against fraud and unauthorized access, and maintain the security of our systems and your accounts.</li>
        <li>**To Improve Our Services:** To analyze usage patterns, conduct research and development, and improve our website, services, and offerings.</li>
        <li>**To Comply with Legal Obligations:** To comply with applicable laws, regulations, and legal processes.</li>
      </ul>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">3. Disclosure of Your Information</h2>
      <p className="mb-2">We may disclose your information to the following categories of recipients:</p>
      <ul className="list-disc list-inside mb-4">
        <li>**Affiliates and Subsidiaries:** Within the Velstron Bank group of companies for internal business purposes.</li>
        <li>**Service Providers:** Third-party vendors who provide services on our behalf, such as payment processors, IT support, and marketing agencies. These providers are contractually obligated to protect your information.</li>
        <li>**Regulatory Authorities and Law Enforcement:** When required by law or legal process, or to protect our rights and the safety of our users.</li>
        <li>**Business Transfers:** In connection with a merger, acquisition, or sale of all or a portion of our assets.</li>
        <li>**With Your Consent:** We may share your information with third parties when you provide your explicit consent.</li>
      </ul>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">4. Data Security</h2>
      <p className="mb-4">
        We implement reasonable security measures to protect your personal information from unauthorized access, use, disclosure, alteration, or destruction. These measures include encryption, firewalls, secure server facilities, and regular security audits. However, no method of transmission over the internet or electronic storage is completely secure, and we cannot guarantee absolute security.
      </p>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">5. Your Rights</h2>
      <p className="mb-4">
        Depending on your location, you may have certain rights regarding your personal information, such as the right to access, correct, delete, or restrict the processing of your data. To exercise these rights, please contact us using the information provided below.
      </p>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">6. Cookies and Tracking Technologies</h2>
      <p className="mb-4">
        Our website may use cookies and similar tracking technologies to enhance your browsing experience, personalize content, and collect usage data. You can manage your cookie preferences through your browser settings.
      </p>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">7. Links to Other Websites</h2>
      <p className="mb-4">
        Our website may contain links to third-party websites. We are not responsible for the privacy practices or content of these websites. We encourage you to review the privacy policies of any third-party sites you visit.
      </p>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">8. Changes to This Privacy Policy</h2>
      <p className="mb-4">
        We may update this Privacy Policy from time to time. We will notify you of any material changes by posting the updated policy on our website or through other appropriate communication channels. Your continued use of our services after the effective date of the revised policy constitutes your acceptance of the changes.
      </p>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">9. Contact Us</h2>
      <p className="mb-2">If you have any questions or concerns about this Privacy Policy or our data practices, please contact us at:</p>
      <p className="mb-2">Velstron Bank</p>
      <p className="mb-2">Head Office: First Floor Central Point, Club Road Jamnagar, Gujarat -361008</p>
      <p className="mb-2">Email: contact@velstron.com</p>
    </div>
  );
};

export default PrivacyPolicyPage;