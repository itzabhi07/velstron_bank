"use client";
import Image from "next/image";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";

import { useState } from "react";
import {
  FaUserCircle,
  FaPhone,
  FaEnvelope,
  FaMapMarkerAlt,
  FaShieldAlt,
  FaBuilding,
} from "react-icons/fa";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
export default function ContactUs() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    // TODO: Implement form submission logic
    console.log("Form submitted:", formData);
    // Reset form
    setFormData({ name: "", email: "", subject: "", message: "" });
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <main className="min-h-screen bg-gray-50 text-gray-900">
      {/* Top Bar */}
      <div className="bg-blue-900 text-white py-2 text-sm">
        <div className="container mx-auto px-6 flex justify-end space-x-4">
          <Link href="/help" className="hover:underline">
            Help
          </Link>
        </div>
      </div>

      {/* Navigation Bar */}
      <nav className="bg-white shadow-md py-4 px-6 sticky top-0 z-10">
        <div className="container mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center">
            <Image
              src="/images/logo_crop.jpg"
              alt="Velstron Bank Logo"
              width={180}
              height={50}
              className="mr-4 rounded-md shadow-sm"
            />
            <span className="font-extrabold text-xl text-blue-900 tracking-tight hidden sm:block">
              Velstron Bank
            </span>
          </Link>
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-3">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    className="flex items-center text-blue-700 hover:text-blue-900"
                  >
                    <FaUserCircle className="mr-1 w-4 h-4" /> Login
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56 bg-white border border-gray-200 shadow-lg">
                  <DropdownMenuItem asChild>
                    <a
                      href="/login/adminLogin"
                      className="flex items-center w-full px-4 py-2 hover:bg-blue-50"
                    >
                      <FaShieldAlt className="mr-2 w-4 h-4" />
                      Admin Login
                    </a>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <a
                      href="/login/adminLogin"
                      className="flex items-center w-full px-4 py-2 hover:bg-blue-50"
                    >
                      <FaBuilding className="mr-2 w-4 h-4" />
                      Executive Login
                    </a>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <a
                      href="/login/userLogin"
                      className="flex items-center w-full px-4 py-2 hover:bg-blue-50"
                    >
                      <FaUserCircle className="mr-2 w-4 h-4" />
                      User Login
                    </a>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <a
                to="/signup"
                className="bg-blue-900 text-white rounded-full px-4 py-2 hover:bg-blue-800 font-medium transition-colors duration-300"
              >
                Sign Up
              </a>
            </div>
          </div>
        </div>
      </nav>
      {/* Back to Home */}
      <a
        href="/"
        className="absolute top-36 left-6 flex items-center text-blue-700 hover:text-blue-900 transition-colors z-20"
      >
        <ArrowLeft className="w-4 h-4 mr-1" />
        Back to Home
      </a>
      {/* Contact Section */}
      <section className="py-16 px-6">
        <div className="container mx-auto">
          <h1 className="text-4xl font-bold text-blue-900 text-center mb-12">
            Contact Us
          </h1>

          <div className="grid md:grid-cols-2 gap-12">
            {/* Contact Information */}
            <div className="bg-white p-8 rounded-lg shadow-lg">
              <h2 className="text-2xl font-semibold text-blue-900 mb-6">
                Get in Touch
              </h2>
              <div className="space-y-6">
                <div className="flex items-center space-x-4">
                  <FaPhone className="text-blue-900 text-xl" />
                  <div>
                    <h3 className="font-semibold">Phone</h3>
                    <p>+91 1800-123-4567</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <FaEnvelope className="text-blue-900 text-xl" />
                  <div>
                    <h3 className="font-semibold">Email</h3>
                    <p>support@velstronbank.com</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <FaMapMarkerAlt className="text-blue-900 text-xl" />
                  <div>
                    <h3 className="font-semibold">Address</h3>
                    <p>123 Banking Street, Financial District</p>
                    <p>Mumbai, Maharashtra 400001</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-white p-8 rounded-lg shadow-lg">
              <h2 className="text-2xl font-semibold text-blue-900 mb-6">
                Send us a Message
              </h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-gray-700 mb-2">
                    Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-gray-700 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="subject" className="block text-gray-700 mb-2">
                    Subject
                  </label>
                  <input
                    type="text"
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-gray-700 mb-2">
                    Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows="4"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  ></textarea>
                </div>
                <button
                  type="submit"
                  className="w-full bg-blue-900 text-white rounded-full px-6 py-3 hover:bg-blue-800 transition-colors duration-300 font-semibold"
                >
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
