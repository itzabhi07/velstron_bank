"use client";
import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Toaster, toast } from "react-hot-toast";
import { format } from "date-fns";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { FileText, X, Search } from "lucide-react";
import { getExecutiveFinalReview, getKycdata,approveKYC_By_executive,rejectKYC_By_executive } from "./kycService";

const mockAllApplications = [
  {
    id: "APP006",
    applicationType: "UHNI",
    submissionDate: new Date(2023, 4, 18),
    status: "new",
    country: "United States",
    documents: [
      { id: "DOC021", name: "Passport", status: "submitted", url: "#" },
      { id: "DOC022", name: "Proof of Address", status: "submitted", url: "#" },
      { id: "DOC023", name: "Selfie", status: "submitted", url: "#" },
    ],
    history: [
      {
        date: new Date(2023, 4, 18),
        action: "Application Submitted",
        by: "Alex Thompson",
        notes: "",
      },
    ],
  },
  {
    id: "APP007",
    applicationType: "Corporate",
    submissionDate: new Date(2023, 4, 17),
    status: "new",
    country: "Singapore",
    documents: [
      {
        id: "DOC024",
        name: "Certificate of Incorporation",
        status: "submitted",
        url: "#",
      },
      { id: "DOC025", name: "Tax License", status: "submitted", url: "#" },
      { id: "DOC026", name: "Board Resolution", status: "submitted", url: "#" },
    ],
    history: [
      {
        date: new Date(2023, 4, 17),
        action: "Application Submitted",
        by: "Global Corp Ltd",
        notes: "",
      },
    ],
  },
];

const mockKycApplications = [
  {
    id: "APP001",
    applicationType: "UHNI",
    submissionDate: new Date(2023, 4, 15),
    status: "pending",
    country: "United Kingdom",
    documents: [
      { id: "DOC001", name: "Passport", status: "submitted", url: "#" },
      { id: "DOC002", name: "Proof of Address", status: "submitted", url: "#" },
      { id: "DOC003", name: "Selfie", status: "submitted", url: "#" },
    ],
    history: [
      {
        date: new Date(2023, 4, 15),
        action: "Application Submitted",
        by: "John Smith",
        notes: "",
      },
      {
        date: new Date(2023, 4, 16),
        action: "Under Review",
        by: "System",
        notes: "Auto-assigned to review queue",
      },
    ],
  },
  {
    id: "APP002",
    applicationType: "Corporate",
    submissionDate: new Date(2023, 4, 14),
    status: "pending",
    documents: [
      {
        id: "DOC004",
        name: "Certificate of Incorporation",
        status: "submitted",
        url: "#",
      },
      {
        id: "DOC005",
        name: "Tax License",
        status: "reupload_requested",
        url: "#",
      },
      { id: "DOC006", name: "Board Resolution", status: "submitted", url: "#" },
    ],
    history: [
      {
        date: new Date(2023, 4, 14),
        action: "Application Submitted",
        by: "Emma Johnson",
        notes: "",
      },
      {
        date: new Date(2023, 4, 15),
        action: "Under Review",
        by: "System",
        notes: "Auto-assigned to review queue",
      },
      {
        date: new Date(2023, 4, 16),
        action: "Reupload Requested",
        by: "David Wilson",
        notes: "Tax License not clearly visible",
      },
    ],
  },
  {
    id: "APP003",
    applicationType: "UHNI",
    submissionDate: new Date(2023, 4, 13),
    status: "pending",
    documents: [
      { id: "DOC007", name: "Passport", status: "submitted", url: "#" },
      { id: "DOC008", name: "Proof of Address", status: "submitted", url: "#" },
      { id: "DOC009", name: "Selfie", status: "submitted", url: "#" },
      { id: "DOC010", name: "Source of Funds", status: "submitted", url: "#" },
    ],
    history: [
      {
        date: new Date(2023, 4, 13),
        action: "Application Submitted",
        by: "Michael Chen",
        notes: "",
      },
      {
        date: new Date(2023, 4, 14),
        action: "Under Review",
        by: "System",
        notes: "Auto-assigned to review queue",
      },
    ],
  },
];

const mockReviewedApplications = [
  {
    id: "APP004",
    applicationType: "UHNI",
    submissionDate: new Date(2023, 4, 10),
    reviewDate: new Date(2023, 4, 12),
    status: "approved_by_executive",
    documents: [
      { id: "DOC011", name: "Passport", status: "approved", url: "#" },
      { id: "DOC012", name: "Proof of Address", status: "approved", url: "#" },
      { id: "DOC013", name: "Selfie", status: "approved", url: "#" },
    ],
    history: [
      {
        date: new Date(2023, 4, 10),
        action: "Application Submitted",
        by: "Sarah Williams",
        notes: "",
      },
      {
        date: new Date(2023, 4, 11),
        action: "Under Review",
        by: "System",
        notes: "Auto-assigned to review queue",
      },
      {
        date: new Date(2023, 4, 12),
        action: "Approved by Executive",
        by: "Lisa Chen",
        notes: "All documents verified",
      },
    ],
  },
  {
    id: "APP005",
    applicantName: "Robert Garcia",
    applicationType: "Corporate",
    submissionDate: new Date(2023, 4, 8),
    reviewDate: new Date(2023, 4, 11),
    status: "rejected_by_executive",
    documents: [
      {
        id: "DOC014",
        name: "Certificate of Incorporation",
        status: "rejected",
        url: "#",
      },
      { id: "DOC015", name: "Tax License", status: "approved", url: "#" },
      { id: "DOC016", name: "Board Resolution", status: "approved", url: "#" },
    ],
    history: [
      {
        date: new Date(2023, 4, 8),
        action: "Application Submitted",
        by: "Robert Garcia",
        notes: "",
      },
      {
        date: new Date(2023, 4, 9),
        action: "Under Review",
        by: "System",
        notes: "Auto-assigned to review queue",
      },
      {
        date: new Date(2023, 4, 11),
        action: "Rejected by Executive",
        by: "Thomas Brown",
        notes: "Certificate of Incorporation appears to be altered",
      },
    ],
  },
];

const rejectFormSchema = z.object({
  reason: z
    .string()
    .min(10, { message: "Rejection reason must be at least 10 characters." }),
});

const requestReuploadFormSchema = z.object({
  documentIds: z
    .array(z.string())
    .min(1, { message: "Select at least one document" }),
  reason: z
    .string()
    .min(10, { message: "Reason must be at least 10 characters." }),
});

const REQUIRED_DOCUMENTS = {
  corporate: [
    { id: "selfie", name: "Live Selfie" },
    { id: "passport", name: "Passport" },
    { id: "signatureImage", name: "Signature Image" },
    { id: "incorporationCertificate", name: "Certificate of Incorporation" },
    { id: "taxLicense", name: "Tax License" },
    { id: "boardResolution", name: "Board Resolution" },
  ],
  uhni: [
    { id: "selfie", name: "Live Selfie" },
    { id: "passport", name: "Passport" },
    { id: "signatureImage", name: "Signature Image" },
  ],
};

const StatusBadge = ({ status }) => {
  let badgeColor;
  let statusText;

  switch (status) {
    case "approved":
    case "approved_by_executive":
      badgeColor = "bg-green-500";
      statusText = status === "approved" ? "Approved" : "Approved (Executive)";
      break;
    case "rejected":
    case "rejected_by_executive":
      badgeColor = "bg-red-500";
      statusText = status === "rejected" ? "Rejected" : "Rejected (Executive)";
      break;
    case "reupload_requested":
      badgeColor = "bg-amber-500";
      statusText = "Reupload Requested";
      break;
    default:
      badgeColor = "bg-blue-500";
      statusText = "Pending";
  }

  return <Badge className={`${badgeColor} text-white`}>{statusText}</Badge>;
};

const DocumentItem = ({ document, onAction }) => {
  return (
    <div className="flex items-center justify-between border p-3 rounded-md mb-2">
      <div className="flex items-center gap-2">
        <FileText size={18} />
        <span>{document.name}</span>
        <StatusBadge status={document.status} />
      </div>
      <div className="flex gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => onAction("view", document)}
        >
          View
        </Button>
      </div>
    </div>
  );
};

const DocumentViewer = ({ document, onClose }) => {
  return (
    <div className="bg-gray-50 p-4 rounded-md">
      <div className="flex justify-between mb-4">
        <h3 className="text-lg font-medium">{document.name}</h3>
        <Button variant="ghost" size="sm" onClick={onClose}>
          <X size={16} />
        </Button>
      </div>
      <div className="aspect-[4/3] bg-gray-200 flex items-center justify-center rounded-md mb-4">
        <p className="text-gray-500">[Document Preview Placeholder]</p>
      </div>
      <div className="flex justify-end gap-2">
        <Button variant="outline" size="sm">
          Download
        </Button>
      </div>
    </div>
  );
};

const DocumentHistory = ({ history }) => {
  if (!Array.isArray(history) || history.length === 0) {
    return <p className="text-gray-500 italic">No history available.</p>;
  }

  return (
    <div className="space-y-4">
      {history.map((event, index) => {
        // Validate and parse date safely
        let eventDate = null;
        if (event.date) {
          eventDate =
            typeof event.date === "string" ? parseISO(event.date) : event.date;
        }

        const formattedDate =
          eventDate && isValid(eventDate)
            ? format(eventDate, "MMM dd, yyyy HH:mm")
            : "Invalid date";
        const fullName = `${event?.name?.first ?? ""} ${
          event?.name?.middle ?? ""
        } ${event?.name?.last ?? ""}`.trim();
        return (
          <div
            key={event.id || index}
            className="border-l-2 border-gray-300 pl-4 pb-4"
          >
            <div className="flex justify-between">
              <p className="font-medium">
                {event.status || "No action specified"}
              </p>
              <p className="text-sm text-gray-500">{formattedDate}</p>
            </div>
            <p className="text-sm text-gray-600">By: {fullName || "Unknown"}</p>
            {event.comment && <p className="text-sm mt-1">{event.comment}</p>}
          </div>
        );
      })}
    </div>
  );
};

const Page = () => {
  const [selectedTab, setSelectedTab] = useState("applications");
  const [selectedApplication, setSelectedApplication] = useState(null);
  const [viewingDocument, setViewingDocument] = useState(null);
  const [openDialog, setOpenDialog] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [applications, setApplications] = useState(mockAllApplications);

  const [pendingApplications, setPendingApplications] =
    useState(mockKycApplications);

    const [kycAppliction, setkycAppilication] = useState([]);
    const [ReviewedApplications, setReviewedApplications] = useState([]);

    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

  const rejectForm = useForm({
    resolver: zodResolver(rejectFormSchema),
    defaultValues: { reason: "" },
  });

  const requestReuploadForm = useForm({
    resolver: zodResolver(requestReuploadFormSchema),
    defaultValues: { documentIds: [], reason: "" },
  });

  const handleDocumentAction = (action, document) => {
    if (action === "view") {
      setViewingDocument(document);
    }
  };

  const handleApprove = async (executiveId, kycId) => {
    try {
      const response = await approveKYC_By_executive(executiveId, kycId); // ✅ use params passed in

      toast.success(
        `Application ${kycId} has been approved and sent to admin for final review.`,
        {
          duration: 4000,
          position: "top-right",
        }
      );

      setSelectedApplication((prev) => ({
        ...prev,
        status: "Approved",
        ...response,
      }));

      setOpenDialog("");
    } catch (error) {
      console.error("Approval failed:", error.message);
      toast.error("Failed to approve application. Please try again.", {
        duration: 4000,
        position: "top-right",
      });
    }
  };

  
  const handleReject = (data) => {
    toast.error(`Application ${selectedApplication.id} has been rejected.`, {
      duration: 4000,
      position: "top-right",
    });

    rejectForm.reset();
    setSelectedApplication(null);
    setOpenDialog("");
  };

  const handleRequestReupload = (data) => {
    toast.success(
      `Reupload request sent for ${data.documentIds.length} document(s).`,
      {
        duration: 4000,
        position: "top-right",
      }
    );

    requestReuploadForm.reset();
    setSelectedApplication(null);
    setOpenDialog("");
  };

  const handleAddToQueue = (application) => {
    // Move application from applications to pending queue
    setApplications((apps) => apps.filter((app) => app.id !== application.id));
    setPendingApplications((pending) => [
      ...pending,
      { ...application, status: "pending" },
    ]);

    toast.success(
      `Application ${application.id} has been added to the review queue`,
      {
        duration: 4000,
        position: "top-right",
      }
    );
  };

  const filterApplications = (applications) => {
    return applications.filter((app) => {
      const user = app.user ?? {};
      const idStr = (app.referenceNumber ?? "").toString().trim().toLowerCase();
      const fullName = `${user.name?.first ?? ""} ${user.name?.middle ?? ""} ${
        user.name?.last ?? ""
      }`
        .trim()
        .toLowerCase();

      return (
        idStr.includes(searchQuery.toLowerCase()) ||
        fullName.includes(searchQuery.toLowerCase())
      );

      // return applications.filter(
      //   (app) =>
      //     app.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      //     app.applicantName.toLowerCase().includes(searchQuery.toLowerCase())
      //
    });
  };


  const renderNewApplicationsTable = (applications) => (
    <div className="rounded-md border overflow-hidden">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              ID
            </th>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Type
            </th>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Submission Date
            </th>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Country
            </th>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {applications.map((app) => (
            <tr key={app.id}>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                {app.id}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {app.applicationType}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {format(app.submissionDate, "MMM dd, yyyy")}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {app.country}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleAddToQueue(app)}
                >
                  Add to Queue
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  const renderApplicationTable = (applications) => (
    <div className="rounded-md border overflow-hidden">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              ID
            </th>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Type
            </th>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Submission Date
            </th>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Status
            </th>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {applications.map((app) => {
            const user = app?.user ?? {};
            const accountType = user.accountType ?? "";
            const submissionDate = user.submissionDate
              ? new Date(user.submissionDate)
              : new Date();
            const executiveStatus =
              app.executiveStatus.toLowerCase() ?? "pending";
            const fullName = `${user?.name?.first ?? ""} ${
              user?.name?.middle ?? ""
            } ${user?.name?.last ?? ""}`.trim();

            return (
              <tr key={app.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {app.referenceNumber}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {fullName}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {accountType}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {format(submissionDate, "MMM dd, yyyy")}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <StatusBadge status={executiveStatus} />
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedApplication(app)}
                  >
                    Review
                  </Button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );

  useEffect(() => {
    const fetchKycData = async (executiveId) => {
      try {
        const response = await getKycdata("683975f7ff5916262eb5d4b7");
        setkycAppilication(Array.isArray(response?.data) ? response.data : []);
      } catch (err) {
        console.error("Failed to fetch KYC data", err);
        setError("Failed to load KYC data. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    const fetchReviewedApplications = async (executive_id) => {
      try {
        const response = await getExecutiveFinalReview(
          "683975f7ff5916262eb5d4b7"
        );

        const applications = Array.isArray(response?.data) ? response.data : [];

        setReviewedApplications(applications);

        console.log("✅ Reviewed application data:", applications);
        // applications.forEach((app, index) => {
        //   console.log(`Application ${index + 1}:`, app);
        // });
      } catch (err) {
        console.error("❌ Failed to fetch reviewed applications:", err);
        setError(
          "Failed to load reviewed applications. Please try again later."
        );
      }
    };
    fetchReviewedApplications();
    fetchKycData();
  }, []);

  if (loading) {
    return <p className="p-4">Loading...</p>;
  }

  if (error) {
    return <p className="p-4 text-red-600">{error}</p>;
  }

  if (!kycAppliction.length) {
    return <p className="p-4">No KYC records found.</p>;
  }


  return (
    <div className="container mx-auto py-8 px-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">
            KYC Review Dashboard (Executive)
          </CardTitle>
          <CardDescription>
            Review KYC applications and make decisions
          </CardDescription>
          <div className="mt-4">
            <div className="flex gap-2 items-center">
              <div className="relative w-full max-w-md">
                <Input
                  type="text"
                  placeholder="Search by ID or Name..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              </div>
              <Button
                className="bg-primary text-white hover:bg-primary/90"
                onClick={() => {}}
              >
                <Search className="h-4 w-4" />
                Search
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs
            defaultValue="applications"
            value={selectedTab}
            onValueChange={setSelectedTab}
          >
            <TabsList className="mb-4">
              <TabsTrigger value="applications">Applications</TabsTrigger>
              <TabsTrigger value="pending">Pending Review</TabsTrigger>
              <TabsTrigger value="reviewed">Reviewed Applications</TabsTrigger>
            </TabsList>
            <TabsContent value="applications" className="space-y-4">
              {renderNewApplicationsTable(
                applications.filter(
                  (app) =>
                    app.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    app.country
                      .toLowerCase()
                      .includes(searchQuery.toLowerCase())
                )
              )}
            </TabsContent>
            <TabsContent value="pending" className="space-y-4">
              {!selectedApplication ? (
                renderApplicationTable(filterApplications(kycAppliction))
              ) : (
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <h2 className="text-xl font-bold">
                      {selectedApplication.id}
                    </h2>
                    <Button
                      variant="outline"
                      onClick={() => setSelectedApplication(null)}
                    >
                      Back to List
                    </Button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card className="col-span-2">
                      <CardHeader>
                        <CardTitle>Submitted Documents</CardTitle>
                      </CardHeader>
                      <CardContent>
                        {viewingDocument ? (
                          <DocumentViewer
                            document={viewingDocument}
                            onClose={() => setViewingDocument(null)}
                          />
                        ) : (
                          <div className="space-y-2">
                            {selectedApplication.kycDocs.map((doc) => (
                              <DocumentItem
                                key={doc.url}
                                document={doc}
                                onAction={handleDocumentAction}
                              />
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    <div className="space-y-6">
                      <Card>
                        <CardHeader>
                          <CardTitle>Application Details</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <dl className="grid grid-cols-1 gap-2 text-sm">
                            <div className="flex justify-between">
                              <dt className="font-medium">Application Type:</dt>
                              <dd>{selectedApplication?.accountType}</dd>
                            </div>
                            <div className="flex justify-between">
                              <dt className="font-medium">Submission Date:</dt>
                              <dd>
                                {format(
                                  new Date(
                                    selectedApplication?.submissionDate ||
                                      new Date()
                                  ),
                                  "MMM dd, yyyy"
                                )}
                              </dd>
                            </div>
                            <div className="flex justify-between">
                              <dt className="font-medium">Status:</dt>
                              <dd>
                                <StatusBadge
                                  status={selectedApplication.executiveStatus}
                                />
                              </dd>
                            </div>
                          </dl>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle>Document History</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <DocumentHistory
                            history={selectedApplication.documentHistory}
                          />
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle>Actions</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-2">
                          <Button
                            className="w-full bg-green-600 hover:bg-green-700"
                            onClick={() => setOpenDialog("approve")}
                          >
                            Approve
                          </Button>
                          <Button
                            className="w-full bg-red-600 hover:bg-red-700"
                            onClick={() => setOpenDialog("reject")}
                          >
                            Reject
                          </Button>
                          <Button
                            className="w-full bg-amber-600 hover:bg-amber-700"
                            onClick={() => setOpenDialog("reupload")}
                          >
                            Request Reupload
                          </Button>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </div>
              )}
            </TabsContent>
            <TabsContent value="reviewed" className="space-y-4">
              {!selectedApplication ? (
                renderApplicationTable(filterApplications(kycAppliction))
              ) : (
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <h2 className="text-xl font-bold">
                      {selectedApplication.applicantName} -{" "}
                      {selectedApplication.id}
                    </h2>
                    <Button
                      variant="outline"
                      onClick={() => setSelectedApplication(null)}
                    >
                      Back to List
                    </Button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card className="col-span-2">
                      <CardHeader>
                        <CardTitle>Submitted Documents</CardTitle>
                      </CardHeader>
                      <CardContent>
                        {viewingDocument ? (
                          <DocumentViewer
                            document={viewingDocument}
                            onClose={() => setViewingDocument(null)}
                          />
                        ) : (
                          <div className="space-y-2">
                            {selectedApplication.kycDocs.map((doc, index) => (
                              <DocumentItem
                                key={index}
                                document={doc}
                                onAction={handleDocumentAction}
                              />
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    <div className="space-y-6">
                      <Card>
                        <CardHeader>
                          <CardTitle>Application Details</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <dl className="grid grid-cols-1 gap-2 text-sm">
                            <div className="flex justify-between">
                              <dt className="font-medium">Application Type:</dt>
                              <dd>{selectedApplication.accountType}</dd>
                            </div>
                            <div className="flex justify-between">
                              <dt className="font-medium">Submission Date:</dt>
                              <dd>
                                {selectedApplication.user.submissionDate
                                  ? format(
                                      new Date(
                                        selectedApplication.user.submissionDate
                                      ),
                                      "MMM dd, yyyy"
                                    )
                                  : "N/A"}
                              </dd>
                            </div>
                            <div className="flex justify-between">
                              <dt className="font-medium">Review Date:</dt>
                              <dd>
                                {selectedApplication.reviewDate
                                  ? format(
                                      selectedApplication.reviewDate,
                                      "MMM dd, yyyy"
                                    )
                                  : "Not reviewed yet"}
                              </dd>
                            </div>
                            <div className="flex justify-between">
                              <dt className="font-medium">Status:</dt>
                              <dd>
                                <StatusBadge
                                  status={selectedApplication.executiveStatus}
                                />
                              </dd>
                            </div>
                          </dl>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle>Document History</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <DocumentHistory
                            history={selectedApplication.DocumentHistory}
                          />
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Approval Dialog */}
      <Dialog
        open={openDialog === "approve"}
        onOpenChange={(open) => !open && setOpenDialog("")}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Approve Application</DialogTitle>
            <DialogDescription>
              Are you sure you want to approve this application? This will send
              it to admin for final review.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpenDialog("")}>
              Cancel
            </Button>
            <Button
              className="bg-green-600 hover:bg-green-700"
              // onClick={handleApprove}
              onClick={
                () =>
                  handleApprove(
                    "683975f7ff5916262eb5d4b7",
                    "683f139b18c82cdb79bdb918"
                  )
                // handleApprove(selectedApplication.executive,
                //   selectedApplication.id
                // )
              }
            >
              Confirm Approval
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Rejection Dialog */}
      <Dialog
        open={openDialog === "reject"}
        onOpenChange={(open) => !open && setOpenDialog("")}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Application</DialogTitle>
            <DialogDescription>
              Please provide a reason for rejecting this application.
            </DialogDescription>
          </DialogHeader>
          <Form {...rejectForm}>
            <form
              onSubmit={rejectForm.handleSubmit(handleReject)}
              className="space-y-4"
            >
              <FormField
                control={rejectForm.control}
                name="reason"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reason for Rejection</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Enter detailed reason for rejection"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button
                  variant="outline"
                  type="button"
                  onClick={() => setOpenDialog("")}
                >
                  Cancel
                </Button>
                <Button className="bg-red-600 hover:bg-red-700" type="submit">
                  Confirm Rejection
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Request Reupload Dialog */}
      <Dialog
        open={openDialog === "reupload"}
        onOpenChange={(open) => !open && setOpenDialog("")}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Request Document Reupload</DialogTitle>
            <DialogDescription>
              Select the documents you want to request for reupload and provide
              a reason.
            </DialogDescription>
          </DialogHeader>
          <Form {...requestReuploadForm}>
            <form
              onSubmit={requestReuploadForm.handleSubmit(handleRequestReupload)}
              className="space-y-4"
            >
              <FormField
                control={requestReuploadForm.control}
                name="documentIds"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Documents to Reupload</FormLabel>{" "}
                    <div className="space-y-2">
                      {REQUIRED_DOCUMENTS[
                        selectedApplication?.applicationType.toLowerCase()
                      ]?.map((doc) => (
                        <div
                          key={doc.id}
                          className="flex items-center space-x-2"
                        >
                          <Checkbox
                            id={`doc-${doc.id}`}
                            checked={field.value?.includes(doc.id)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                field.onChange([...field.value, doc.id]);
                              } else {
                                field.onChange(
                                  field.value?.filter((id) => id !== doc.id)
                                );
                              }
                            }}
                          />
                          <label htmlFor={`doc-${doc.id}`} className="text-sm">
                            {doc.name}
                          </label>
                        </div>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={requestReuploadForm.control}
                name="reason"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reason for Reupload</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Enter detailed reason for reupload request"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button
                  variant="outline"
                  type="button"
                  onClick={() => setOpenDialog("")}
                >
                  Cancel
                </Button>
                <Button
                  className="bg-amber-600 hover:bg-amber-700"
                  type="submit"
                >
                  Send Request
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Toaster />
    </div>
  );
};

export default Page;
