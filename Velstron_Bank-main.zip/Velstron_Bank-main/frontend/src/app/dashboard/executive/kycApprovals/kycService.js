import axios from "axios";
const API_URL = "http://localhost:8765/velstron-bank-review/review/";

export const getKycdata = async (executive_id) => {
  try {
    const response = await axios.get(`${API_URL}my-queue-executive`, {
      params: { executive_id: executive_id },
    });
    console.log("Fetched KYC data:", response.data);
    return response;
  } catch (error) {
    if (error.response) {
      console.error(
        "Server responded with:",
        error.response.status,
        error.response.data
      );
    } else if (error.request) {
      console.error("No response received:", error.request);
    } else {
      console.error("Axios setup error:", error.message);
    }
    throw error;
  }
};

export const getExecutiveFinalReview = async (executiveId) => {
  try {
    const response = await axios.get(`${API_URL}my-queue-final`, {
      params: { executive_id: executiveId },
    });
    console.log("Fetched executive final review:", response.data);
    return response;
  } catch (error) {
    console.error("Error fetching executive final review:", error);
    throw error;
  }
};

export const approveKYC_By_executive = async (executiveId, kycId) => {
  try {
    //  const API_URL = "http://localhost:8765/velstron-bank-review/review/";

    const response = await axios.post(
      `${API_URL}verify-executive`, // endpoint
      null, // empty body
      {
        params: {
          executive_id: executiveId,
          kycid: kycId,
        },
      }
    );

    console.log("✅ KYC approved by executive:", response.data);
    return response.data;
  } catch (error) {
    console.error("❌ Error approving KYC by executive:", error.message);
    throw error;
  }
};

export const rejectKYC_By_executive = async (
  refrenceNumber,
  executiveId,
  reason
) => {
  try {
    const response = await axios.put(`${API_URL}kyc-reject`, null, {
      params: {
        refrenceNumber: refrenceNumber,
        executive_id: executiveId,
        reason: reason,
      },
      headers: {
        "Content-Type": "application/json",
      },
    });

    console.log("✅ KYC rejected successfully:", response.data);
    return response.data;
  } catch (error) {
    console.error("❌ Error rejecting KYC:", error.message);
    throw error;
  }
};
