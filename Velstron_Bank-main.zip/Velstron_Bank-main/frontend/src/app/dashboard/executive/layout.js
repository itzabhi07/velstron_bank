'use client';

import { useState } from 'react';
import { DashboardSidebar } from '@/components/dashboard/dashboard-sidebar'; 
import { DashboardHeader } from '@/components/dashboard/dashboard-header'; 
import { Toaster } from 'react-hot-toast'; 

export default function ExecutiveLayout({ children }) {
    const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

    const toggleSidebar = () => {
        setIsSidebarCollapsed(!isSidebarCollapsed);
    };

    return (
        <div className="flex min-h-screen bg-background">
            <DashboardSidebar
                userRole="executive" 
                collapsed={isSidebarCollapsed}
                onCollapseToggle={toggleSidebar}
            />
            <div
                className={`flex flex-col flex-1 transition-all duration-300 ${
                    isSidebarCollapsed ? 'ml-16' : 'ml-64'
                }`}
            >
                <DashboardHeader userRole="executive" isSidebarCollapsed={isSidebarCollapsed} /> 
                <main className="flex-1 p-4 md:p-6">{children}</main>
                <Toaster /> 
            </div>
        </div>
    );
}