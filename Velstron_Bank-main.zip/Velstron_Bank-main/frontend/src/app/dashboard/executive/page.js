"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import {
    Users,
    FileCheck,
    Clock,
    ArrowUpRight,
    ChevronRight,
    Search,
    AlertTriangle,
    BarChart3,
    Download,
    Database,
    Briefcase,
    Activity,
} from "lucide-react";
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    Legend,
    ResponsiveContainer,
    LineChart,
    Line,
} from "recharts";

const primaryColor = "#007bff";
const secondaryColor = "#6c757d";

export default function ExecutiveDashboard() {
    const [searchValue, setSearchValue] = useState("");
    const [dashboardData, setDashboardData] = useState({
        totalClients: "",
        newClientsThisMonth: "",
        managedFunds: 0,
        fundsGrowthRate: null,
        clientPerformanceData: [],
        recentActivities: [],
        pendingReports: [],
    });
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const formatCurrency = (value) => {
        return new Intl.NumberFormat("en-US", {
            style: "currency",
            currency: "USD",
            notation: "compact",
            compactDisplay: "short",
        }).format(value);
    };

    const formatPercentage = (value) => {
        if (value === null) return "";
        return new Intl.NumberFormat("en-US", {
            style: "percent",
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        }).format(value);
    };

    useEffect(() => {
        const mockData = {
            totalClients: "1,550",
            newClientsThisMonth: "65",
            managedFunds: 18200000,
            fundsGrowthRate: 0.042,
            clientPerformanceData: [
                { name: "Jan", amountChange: 15000 },
                { name: "Feb", amountChange: -5000 },
                { name: "Mar", amountChange: 10000 },
                { name: "Apr", amountChange: 20000 },
                { name: "May", amountChange: -8000 },
            ],
            recentActivities: [
                {
                    id: "act1",
                    type: "Strategy Meeting",
                    description: "Discussed Q3 growth strategy.",
                    date: "May 15, 2025",
                },
                {
                    id: "act2",
                    type: "Report Review",
                    description: "Reviewed monthly client report.",
                    date: "May 14, 2025",
                },
            ],
            pendingReports: [
                {
                    id: "rep1",
                    title: "Mid-Year Review",
                    status: "Pending",
                    dueDate: "May 29, 2025",
                },
            ],
        };

        setDashboardData(mockData);
        setLoading(false);

    }, []);

    if (loading) {
        return <div>Loading executive dashboard data...</div>;
    }

    if (error) {
        return <div>Error: {error}</div>;
    }

    const filteredReports =
        dashboardData.pendingReports?.filter(
            (report) =>
                report?.title?.toLowerCase().includes(searchValue.toLowerCase()) ||
                report?.status?.toLowerCase().includes(searchValue.toLowerCase())
        ) || [];

    const exportClientPerformance = () => {
        if (dashboardData.clientPerformanceData && dashboardData.clientPerformanceData.length > 0) {
            const headers = Object.keys(dashboardData.clientPerformanceData[0]).join(",");
            const rows = dashboardData.clientPerformanceData.map(obj => Object.values(obj).join(",")).join("\n");
            const csvData = headers + "\n" + rows; 

            const blob = new Blob([csvData], { type: "text/csv" });
            const url = URL.createObjectURL(blob);
            const link = document.createElement("a");
            link.href = url;
            link.download = "client_performance.csv";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
        } else {
            alert("No client performance data to export.");
        }
    };

    return (
        <div>
            <div className="flex flex-row items-center justify-between">
                <h1 className="text-3xl font-semibold mb-6 text-gray-800">
                    Executive Dashboard
                </h1>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <div className="rounded-lg border bg-white shadow animate-fade-in">
                    <div className="p-6">
                        <div className="flex items-center justify-between">
                            <h3 className="text-lg font-semibold text-gray-700">
                                Total Clients
                            </h3>
                            <div
                                className="flex h-8 w-8 items-center justify-center rounded-full"
                                style={{ backgroundColor: `${primaryColor}1a` }}
                            >
                                <Users className="h-4 w-4" style={{ color: primaryColor }} />
                            </div>
                        </div>
                        <div className="mt-4">
                            <p className="text-3xl font-bold text-gray-800">
                                {dashboardData.totalClients}
                            </p>
                            <p className="text-xs text-gray-500 mt-1">
                                <span className="text-green-500 font-medium">
                                    ↑ {dashboardData.newClientsThisMonth}
                                </span>{" "}
                                this month
                            </p>
                        </div>
                        <div className="mt-4">
                            <Link
                                href="/dashboard/executive/clients"
                                className="inline-flex items-center text-sm font-medium"
                                style={{ color: primaryColor }}
                            >
                                View Clients <ChevronRight className="h-3 w-3 ml-1" />
                            </Link>
                        </div>
                    </div>
                </div>

                <div
                    className="rounded-lg border bg-white shadow animate-fade-in"
                    style={{ animationDelay: "0.1s" }}
                >
                    <div className="p-6">
                        <div className="flex items-center justify-between">
                            <h3 className="text-lg font-semibold text-gray-700">
                                Managed Funds
                            </h3>
                            <div
                                className="flex h-8 w-8 items-center justify-center rounded-full"
                                style={{ backgroundColor: `${primaryColor}1a` }}
                            >
                                <Database className="h-4 w-4" style={{ color: primaryColor }} />
                            </div>
                        </div>
                        <div className="mt-4">
                            <p className="text-3xl font-bold text-gray-800">
                                {formatCurrency(dashboardData.managedFunds)}
                            </p>
                            {dashboardData.fundsGrowthRate !== null && (
                                <p className="text-xs text-gray-500 mt-1">
                                    <span
                                        className={`${
                                            dashboardData.fundsGrowthRate >= 0
                                                ? "text-green-500"
                                                : "text-red-500"
                                        } font-medium`}
                                    >
                                        {dashboardData.fundsGrowthRate >= 0 ? "↑" : "↓"}{" "}
                                        {formatPercentage(dashboardData.fundsGrowthRate)}
                                    </span>{" "}
                                    month over month
                                </p>
                            )}
                        </div>
                        <div className="mt-4">
                            <Link
                                href="/dashboard/executive/funds"
                                className="inline-flex items-center text-sm font-medium"
                                style={{ color: primaryColor }}
                            >
                                View Funds <ChevronRight className="h-3 w-3 ml-1" />
                            </Link>
                        </div>
                    </div>
                </div>

                <div
                    className="rounded-lg border bg-white shadow animate-fade-in"
                    style={{ animationDelay: "0.2s" }}
                >
                    <div className="p-6">
                        <div className="flex items-center justify-between">
                            <h3 className="text-lg font-semibold text-gray-700">
                                Pending Reports
                            </h3>
                            <div
                                className="flex h-8 w-8 items-center justify-center rounded-full"
                                style={{ backgroundColor: "#ffcc001a" }}
                            >
                                <FileCheck className="h-4 w-4" style={{ color: "#ffcc00" }} />
                            </div>
                        </div>
                        <div className="mt-4">
                            <p className="text-3xl font-bold text-gray-800">
                                {dashboardData.pendingReports?.length}
                            </p>
                            <p className="text-xs text-gray-500 mt-1">
                                <span className="font-medium">
                                    {
                                        dashboardData.pendingReports?.filter(
                                            (r) => r.status === "Pending"
                                        )?.length
                                    }
                                </span>{" "}
                                pending
                            </p>
                        </div>
                        <div className="mt-4">
                            <Link
                                href="/dashboard/executive/reports"
                                className="inline-flex items-center text-sm font-medium"
                                style={{ color: primaryColor }}
                            >
                                View Reports <ChevronRight className="h-3 w-3 ml-1" />
                            </Link>
                        </div>
                    </div>
                </div>
            </div>

            <div className="grid gap-6 md:grid-cols-2 mt-6">
                <div
                    className="rounded-lg border bg-white shadow animate-fade-in"
                    style={{ animationDelay: "0.4s" }}
                >
                    <div className="p-6">
                        <div className="flex items-center justify-between mb-4">
                            <h3 className="text-lg font-semibold text-gray-700">
                                Client Performance
                            </h3>
                            <div className="flex items-center space-x-2">
                                <button
                                    onClick={exportClientPerformance}
                                    className="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                                >
                                    <Download className="h-3 w-3 mr-1 text-gray-500" />
                                    <span>Export</span>
                                </button>
                            </div>
                        </div>
                        <div className="h-[300px]">
                            <ResponsiveContainer width="100%" height="100%">
                                <LineChart
                                    data={dashboardData.clientPerformanceData}
                                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                                >
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="name" stroke="#6b7280" />
                                    <YAxis
                                        tickFormatter={(value) => formatCurrency(value)}
                                        stroke="#6b7280"
                                    />
                                    <Tooltip
                                        formatter={(value) => [formatCurrency(value), "Amount Change"]}
                                    />
                                    <Legend wrapperStyle={{ top: -10 }} />
                                    <Line
                                        type="monotone"
                                        dataKey="amountChange"
                                        name="Client Amount Change"
                                        stroke={primaryColor}
                                        strokeWidth={2}
                                        activeDot={{ r: 8 }}
                                    />
                                </LineChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                </div>

                <div
                    className="rounded-lg border bg-white shadow animate-fade-in"
                    style={{ animationDelay: "0.5s" }}
                >
                    <div className="p-6">
                        <div className="flex items-center justify-between mb-4">
                            <h3 className="text-lg font-semibold text-gray-700">
                                Recent Activities
                            </h3>
                            <div className="flex items-center space-x-2">
                                <Link
                                    href="/dashboard/executive/activity"
                                    className="inline-flex items-center text-sm font-medium"
                                    style={{ color: primaryColor }}
                                >
                                    View All <ChevronRight className="h-3 w-3 ml-1" />
                                </Link>
                            </div>
                        </div>
                        <div className="space-y-3">
                            {dashboardData.recentActivities?.map((activity) => (
                                <div key={activity.id} className="flex items-center space-x-4">
                                    <Activity className="h-5 w-5 text-gray-500" />
                                    <div>
                                        <p className="text-sm font-medium text-gray-800">
                                            {activity.type}
                                        </p>
                                        <p className="text-xs text-gray-500">
                                            {activity.description} - {activity.date}
                                        </p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            <div
                className="mt-6 rounded-lg border bg-white shadow animate-fade-in md:col-span-2"
                style={{ animationDelay: "0.6s" }}
            >
                <div className="p-6">
                    <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold text-gray-700">
                            Pending Reports
                        </h3>
                        <div className="relative">
                            <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
                            <input
                                type="search"
                                placeholder="Search Reports..."
                                className="rounded-md border border-gray-300 bg-white pl-8 pr-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-primary w-full"
                                value={searchValue}
                                onChange={(e) => setSearchValue(e.target.value)}
                            />
                        </div>
                    </div>
                    <div className="space-y-2">
                        {filteredReports.map((report) => (
                            <div
                                key={report.id}
                                className="flex items-center justify-between p-4 rounded-md border hover:bg-gray-50 transition-colors"
                            >
                                <div>
                                    <p className="text-sm font-medium text-gray-800">
                                        {report.title}
                                    </p>
                                    <p className="text-xs text-gray-500">
                                        Status: {report.status} • Due: {report.dueDate}
                                        </p>
                                </div>
                                <Link
                                    href={`/dashboard/executive/reports/${report.id}`}
                                    className="inline-flex items-center rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-indigo-600"
                                >
                                    Review
                                </Link>
                            </div>
                        ))}
                    </div>
                    <div className="mt-4 text-center">
                        <Link
                            href="/dashboard/executive/reports"
                            className="inline-flex items-center text-sm font-medium"
                            style={{ color: primaryColor }}
                        >
                            View All Pending Reports <ChevronRight className="h-4 w-4 ml-1" />
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    );
}