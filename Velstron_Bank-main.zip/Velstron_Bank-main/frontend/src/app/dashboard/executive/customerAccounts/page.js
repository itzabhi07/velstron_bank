"use client";
import React, { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { MoreHorizontal } from "lucide-react";
import {
  DropdownMenu,
  //   DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import countries from "i18n-iso-countries";
import enLocale from "i18n-iso-countries/langs/en.json";
countries.registerLocale(enLocale);

const customers = [
  {
    id: "123456789",
    accountType: "Individual",
    status: "Active",
    country: "India",
  },
  {
    id: "987654321",
    accountType: "Business",
    status: "Inactive",
    country: "Australia",
  },
];

function Page() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCountry, setSelectedCountry] = useState("");
  const [filteredCustomers, setFilteredCustomers] = useState(customers);

  const handleSearch = (e) => {
    e.preventDefault();
    filterCustomers(searchQuery, selectedCountry);
  };

  const filterCustomers = (query, country) => {
    let filtered = [...customers];

    if (query) {
      filtered = filtered.filter(
        (customer) =>
          customer.id.toLowerCase().includes(query.toLowerCase()) ||
          customer.accountType.toLowerCase().includes(query.toLowerCase())
      );
    }

    if (country) {
      filtered = filtered.filter((customer) => customer.country === country);
    }

    setFilteredCustomers(filtered);
  };

  //   useEffect(() => {
  //     filterCustomers(searchQuery, selectedCountry);
  //   }, [searchQuery, selectedCountry]);

  return (
    <>
      <title>Customer Accounts</title>
      <div className="flex flex-row items-center justify-between">
        <h1 className="text-3xl font-semibold mb-6 text-gray-800">
          Customer Accounts
        </h1>
      </div>
      <form
        onSubmit={handleSearch}
        className="flex gap-4 items-end mt-8 mb-4 w-2/3"
      >
        <div className="flex flex-col gap-2">
          <label htmlFor="search" className="text-sm font-medium text-gray-700">
            Search
          </label>
          <Input
            id="search"
            placeholder="Enter ID or Account Type"
            className="px-2 py-2 max-w-sm border border-gray-300 rounded-md text-gray-700"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex flex-col gap-2">
          <label
            htmlFor="country"
            className="text-sm font-medium text-gray-700"
          >
            Country
          </label>
          <select
            id="country"
            className="px-2 py-2 border border-gray-300 rounded-md text-gray-700"
            value={selectedCountry}
            onChange={(e) => setSelectedCountry(e.target.value)}
          >
            <option value="">All Countries</option>
            {Object.entries(
              countries.getNames("en", { select: "official" })
            ).map(([code, name]) => (
              <option key={code} value={name}>
                {name}
              </option>
            ))}
          </select>
        </div>

        <Button type="submit" variant="secondary">
          Search
        </Button>
      </form>
      <div className="flex flex-col gap-4 items-end mt-8 w-full max-w-5xl">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Velstron ID</TableHead>
              <TableHead>Account Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Country</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredCustomers.map((customer) => (
              <TableRow key={customer.id}>
                <TableCell className="font-medium">{customer.id}</TableCell>
                <TableCell>{customer.accountType}</TableCell>
                <TableCell>{customer.status}</TableCell>
                <TableCell>{customer.country}</TableCell>
                <TableCell>
                  {/* <Button
                    href={`/executive/customerAccounts/${customer.id}`}
                    color="secondary"
                    className="mr-2"
                  >
                    View
                  </Button>

                  <Button
                    href={`/executive/customerAccounts/MIS/${customer.id}`}
                    color="secondary"
                  >
                    MIS
                  </Button> */}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <span className="sr-only">Open menu</span>
                        <MoreHorizontal />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem>
                        {/* <a href={`/executive/customerAccounts/accountOverview`}>
                          View customer
                        </a> */}
                        <Link
                          href={`/dashboard/executive/customerAccounts/accountOverview?id=${customer.id}`}
                        >
                          View customer
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Link
                          href={`/dashboard/executive/customerAccounts/mis`}
                        >
                          MIS
                        </Link>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </>
  );
}

export default Page;
