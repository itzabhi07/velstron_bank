"use client";
import React, { useState, useEffect } from "react";
// import { Link } from "react-router-dom";
import {
  Users,
  FileCheck,
  Database,
  Activity,
  TrendingUp,
  ChevronRight,
  Download,
  Search,
  AlertCircle,
  FileText,
  CreditCard,
  Calendar,
  Mail,
  Phone,
  MapPin,
  ArrowUp,
  ArrowDown,
  RefreshCw,
} from "lucide-react";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

const chartColors = [
  "#007bff",
  "#6c757d",
  "#28a745",
  "#dc3545",
  "#ffc107",
  "#17a2b8",
];

function Page() {
  const [searchValue, setSearchValue] = useState("");
  const [documentSearchValue, setDocumentSearchValue] = useState("");
  const [activeTab, setActiveTab] = useState("overview");
  const [accountData, setAccountData] = useState({
    accountId: "ACT-2023-45789",
    status: "Active",
    accountType: "Premium Investment",
    financialSummary: {
      totalFunds: 850000,
      activeAccounts: 5,
      inactiveAccounts: 2,
      fundAllocation: [
        { name: "Stocks", value: 45 },
        { name: "Bonds", value: 25 },
        { name: "Real Estate", value: 15 },
        { name: "Cash", value: 10 },
        { name: "Alternative", value: 5 },
      ],
      monthlyPerformance: [
        { month: "Jan", value: 825000 },
        { month: "Feb", value: 830000 },
        { month: "Mar", value: 815000 },
        { month: "Apr", value: 840000 },
        { month: "May", value: 850000 },
      ],
    },
    documents: [
      {
        id: "doc1",
        name: "Account Agreement",
        type: "PDF",
        date: "May 10, 2023",
        status: "Verified",
      },
      {
        id: "doc2",
        name: "ID Verification",
        type: "PDF",
        date: "May 10, 2023",
        status: "Verified",
      },
      {
        id: "doc3",
        name: "Risk Assessment",
        type: "PDF",
        date: "May 15, 2023",
        status: "Pending Review",
      },
      {
        id: "doc4",
        name: "Tax Documents",
        type: "PDF",
        date: "Apr 20, 2023",
        status: "Verified",
      },
    ],
    transactions: [
      {
        id: "tr1",
        type: "Deposit",
        amount: 50000,
        date: "May 15, 2023",
        status: "Completed",
      },
      {
        id: "tr2",
        type: "Withdrawal",
        amount: 15000,
        date: "Apr 28, 2023",
        status: "Completed",
      },
      {
        id: "tr3",
        type: "Stock Purchase",
        amount: 25000,
        date: "Apr 20, 2023",
        status: "Completed",
      },
      {
        id: "tr4",
        type: "Dividend Income",
        amount: 2500,
        date: "Apr 15, 2023",
        status: "Completed",
      },
      {
        id: "tr5",
        type: "Fund Transfer",
        amount: 35000,
        date: "Mar 30, 2023",
        status: "Completed",
      },
    ],
  });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Simulate data loading
    const timer = setTimeout(() => {
      setLoading(false);
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  // Formatting functions
  const formatCurrency = (value) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      maximumFractionDigits: 0,
    }).format(value);
  };

  // Function for FinancialSummary
  const calculateGrowth = () => {
    const performance = accountData.financialSummary.monthlyPerformance;
    if (performance.length >= 2) {
      const lastMonth = performance[performance.length - 1].value;
      const previousMonth = performance[performance.length - 2].value;
      const growth = ((lastMonth - previousMonth) / previousMonth) * 100;
      return growth.toFixed(2);
    }
    return "0.00";
  };

  // Filter functions
  const filteredDocuments = accountData.documents.filter(
    (document) =>
      document.name.toLowerCase().includes(documentSearchValue.toLowerCase()) ||
      document.status.toLowerCase().includes(documentSearchValue.toLowerCase())
  );

  const filteredTransactions = accountData.transactions.filter(
    (transaction) =>
      transaction.type.toLowerCase().includes(searchValue.toLowerCase()) ||
      transaction.status.toLowerCase().includes(searchValue.toLowerCase())
  );

  // Helper functions
  const getStatusColor = (status) => {
    switch (status) {
      case "Verified":
      case "Completed":
        return "bg-green-500";
      case "Pending Review":
      case "Pending":
        return "bg-yellow-500";
      default:
        return "bg-red-500";
    }
  };

  const getTransactionIcon = (type) => {
    switch (type) {
      case "Deposit":
        return <ArrowDown className="h-4 w-4 text-green-500" />;
      case "Withdrawal":
        return <ArrowUp className="h-4 w-4 text-red-500" />;
      default:
        return <RefreshCw className="h-4 w-4 text-blue-500" />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="spinner animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-gray-600">Loading account data...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <p className="text-gray-800 font-semibold">
            Error loading account data
          </p>
          <p className="text-red-500">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 bg-gray-50 min-h-screen">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-semibold text-gray-800">
            Account Overview
          </h1>
          <p className="text-gray-600 mt-1">
            Complete financial and account details
          </p>
        </div>
        <div className="mt-4 md:mt-0 flex space-x-2">
          <button className="inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium shadow-sm hover:bg-gray-50">
            <FileText className="h-4 w-4 mr-2" />
            Export PDF
          </button>
          <button className="inline-flex items-center rounded-md bg-primary text-white px-4 py-2 text-sm font-medium shadow-sm hover:bg-blue-600">
            <Activity className="h-4 w-4 mr-2" />
            Account Actions
          </button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="mb-6 border-b border-gray-200 w-full justify-start">
          <TabsTrigger value="overview" className="py-4 px-8">
            Overview
          </TabsTrigger>
          <TabsTrigger value="transactions" className="py-4 px-8">
            Transactions
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-0">
          <div className="grid grid-cols-1 gap-6">
            {/* AccountInfo Component (inline) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-fade-in">
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-lg font-semibold text-gray-700 mb-4 flex items-center gap-2">
                  <CreditCard className="h-5 w-5 text-primary" />
                  Account Details
                </h3>

                <div className="space-y-4">
                  <div className="flex flex-col">
                    <span className="text-sm text-gray-500">Account ID</span>
                    <span className="text-gray-800 font-medium">
                      {accountData.accountId}
                    </span>
                  </div>

                  <div className="flex flex-col">
                    <span className="text-sm text-gray-500">Status</span>
                    <div>
                      <Badge
                        className={`${
                          accountData.status === "Active"
                            ? "bg-green-500"
                            : accountData.status === "Pending"
                            ? "bg-yellow-500"
                            : "bg-red-500"
                        }`}
                      >
                        {accountData.status}
                      </Badge>
                    </div>
                  </div>

                  <div className="flex flex-col">
                    <span className="text-sm text-gray-500">Account Type</span>
                    <span className="text-gray-800 font-medium">
                      {accountData.accountType}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* FinancialSummary Component (inline) */}
              <div className="lg:col-span-2">
                <div className="bg-white rounded-lg shadow p-6 h-full">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-semibold text-gray-700 flex items-center gap-2">
                      <Database className="h-5 w-5 text-primary" />
                      Financial Summary
                    </h3>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="text-sm text-gray-500 mb-1">
                        Total Funds (USD)
                      </h4>
                      <p className="text-2xl font-bold text-gray-800">
                        {formatCurrency(
                          accountData.financialSummary.totalFunds
                        )}
                      </p>
                      <p className="text-xs text-gray-500 mt-1 flex items-center">
                        <span
                          className={`font-medium ${
                            parseFloat(calculateGrowth()) >= 0
                              ? "text-green-500"
                              : "text-red-500"
                          }`}
                        >
                          {parseFloat(calculateGrowth()) >= 0 ? "↑" : "↓"}{" "}
                          {calculateGrowth()}%
                        </span>{" "}
                        last month
                      </p>
                    </div>

                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="text-sm text-gray-500 mb-1">
                        Hot Accounts
                      </h4>
                      <p className="text-2xl font-bold text-gray-800">
                        {accountData.financialSummary.activeAccounts}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        Active investment accounts
                      </p>
                    </div>

                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="text-sm text-gray-500 mb-1">
                        Cold Accounts
                      </h4>
                      <p className="text-2xl font-bold text-gray-800">
                        {accountData.financialSummary.inactiveAccounts}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        Dormant investment accounts
                      </p>
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-sm font-medium text-gray-700 flex items-center gap-1">
                        <TrendingUp className="h-4 w-4 text-primary" /> Fund
                        Performance
                      </h4>
                    </div>
                    <div className="h-[200px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={accountData.financialSummary.monthlyPerformance}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid
                            strokeDasharray="3 3"
                            stroke="#f0f0f0"
                          />
                          <XAxis dataKey="month" stroke="#6b7280" />
                          <YAxis
                            stroke="#6b7280"
                            tickFormatter={(value) => formatCurrency(value)}
                          />
                          <Tooltip
                            formatter={(value) => [
                              formatCurrency(value),
                              "Value",
                            ]}
                          />
                          <Line
                            type="monotone"
                            dataKey="value"
                            stroke="#007bff"
                            strokeWidth={2}
                            dot={{ r: 4, fill: "#007bff" }}
                            activeDot={{ r: 6 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-1">
                <div className="bg-white rounded-lg shadow p-6 h-full">
                  <h3 className="text-lg font-semibold text-gray-700 mb-4">
                    Fund Allocation
                  </h3>
                  <div className="h-[250px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={accountData.financialSummary.fundAllocation}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                          label={({ name, percent }) =>
                            `${name} ${(percent * 100).toFixed(0)}%`
                          }
                        >
                          {accountData.financialSummary.fundAllocation.map(
                            (entry, index) => (
                              <Cell
                                key={`cell-${index}`}
                                fill={chartColors[index % chartColors.length]}
                              />
                            )
                          )}
                        </Pie>
                        <Tooltip formatter={(value) => `${value}%`} />
                        <Legend
                          layout="vertical"
                          verticalAlign="bottom"
                          align="center"
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="transactions" className="mt-0">
          {/* TransactionHistory Component (inline) */}
          <div className="bg-white rounded-lg shadow p-6 animate-fade-in">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-700 flex items-center gap-2">
                <Activity className="h-5 w-5 text-primary" />
                Transaction History
              </h3>

              <div className="mt-4 sm:mt-0 flex flex-col sm:flex-row items-center gap-4">
                <div className="relative">
                  <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
                  <input
                    type="search"
                    placeholder="Search transactions..."
                    className="rounded-md border border-gray-300 bg-white pl-8 pr-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-primary"
                    value={searchValue}
                    onChange={(e) => setSearchValue(e.target.value)}
                  />
                </div>

                <button className="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium shadow-sm hover:bg-gray-50">
                  <Download className="h-4 w-4 mr-1 text-gray-600" />
                  <span>Export</span>
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full min-w-[600px]">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      Transaction
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      Type
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      Amount
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      Date
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filteredTransactions.map((transaction) => (
                    <tr
                      key={transaction.id}
                      className="border-b border-gray-100 hover:bg-gray-50"
                    >
                      <td className="px-4 py-4">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-gray-100 flex items-center justify-center mr-3">
                            {getTransactionIcon(transaction.type)}
                          </div>
                          <div>
                            <div className="text-sm font-medium text-gray-900">
                              {transaction.id}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <div className="text-sm text-gray-900">
                          {transaction.type}
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <div
                          className={`text-sm font-medium ${
                            transaction.type === "Deposit" ||
                            transaction.type === "Dividend Income"
                              ? "text-green-600"
                              : transaction.type === "Withdrawal"
                              ? "text-red-600"
                              : "text-gray-900"
                          }`}
                        >
                          {transaction.type === "Withdrawal" ? "-" : ""}
                          {formatCurrency(transaction.amount)}
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <div className="text-sm text-gray-700">
                          {transaction.date}
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <Badge className={getStatusColor(transaction.status)}>
                          {transaction.status}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {filteredTransactions.length === 0 && (
                <div className="text-center py-4">
                  <p className="text-gray-500 text-sm">No transactions found</p>
                </div>
              )}
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default Page;
