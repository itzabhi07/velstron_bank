"use client";
import React, { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
} from "recharts";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";
import { Progress } from "@/components/ui/progress";
import {
  DownloadIcon,
  TrendingUpIcon,
  BarChartIcon,
  UsersIcon,
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Mock data for charts
const monthlyNetFlowData = [
  { name: "Jan", income: 4000, expenses: 2400, net: 1600 },
  { name: "Feb", income: 3000, expenses: 2800, net: 200 },
  { name: "Mar", income: 5000, expenses: 3000, net: 2000 },
  { name: "Apr", income: 2780, expenses: 3908, net: -1128 },
  { name: "May", income: 1890, expenses: 4800, net: -2910 },
  { name: "Jun", income: 2390, expenses: 3800, net: -1410 },
  { name: "Jul", income: 3490, expenses: 2300, net: 1190 },
  { name: "Aug", income: 4000, expenses: 2400, net: 1600 },
  { name: "Sep", income: 3000, expenses: 1398, net: 1602 },
  { name: "Oct", income: 2000, expenses: 2800, net: -800 },
  { name: "Nov", income: 2780, expenses: 2908, net: -128 },
  { name: "Dec", income: 4890, expenses: 2800, net: 2090 },
];

const hotColdTrendData = [
  { month: "Jan", hot: 30, cold: 70 },
  { month: "Feb", hot: 35, cold: 65 },
  { month: "Mar", hot: 40, cold: 60 },
  { month: "Apr", hot: 45, cold: 55 },
  { month: "May", hot: 50, cold: 50 },
  { month: "Jun", hot: 55, cold: 45 },
  { month: "Jul", hot: 60, cold: 40 },
  { month: "Aug", hot: 65, cold: 35 },
  { month: "Sep", hot: 60, cold: 40 },
  { month: "Oct", hot: 55, cold: 45 },
  { month: "Nov", hot: 50, cold: 50 },
  { month: "Dec", hot: 45, cold: 55 },
];

const performanceScoreData = [
  { name: "Return", score: 85 },
  { name: "Risk", score: 70 },
  { name: "Volatility", score: 65 },
  { name: "Consistency", score: 75 },
  { name: "Growth", score: 80 },
];

const behaviorData = [
  { name: "Login Frequency", value: 4.2, fullMark: 5 },
  { name: "Trade Frequency", value: 3.8, fullMark: 5 },
  { name: "Research Time", value: 2.9, fullMark: 5 },
  { name: "Diversification", value: 4.5, fullMark: 5 },
  { name: "Long-Term Focus", value: 3.6, fullMark: 5 },
];

const comparativeData = [
  { category: "ROI", user: 8.4, country: 6.2, type: 7.1, tier: 9.3 },
  { category: "Risk Score", user: 3.2, country: 4.5, type: 3.8, tier: 2.9 },
  { category: "Fees", user: 0.8, country: 1.2, type: 1.0, tier: 0.7 },
  {
    category: "Diversification",
    user: 8.1,
    country: 7.3,
    type: 7.5,
    tier: 8.7,
  },
  { category: "Growth Rate", user: 6.9, country: 5.4, type: 6.3, tier: 7.8 },
];

const ExecutiveMIS = () => {
  const [performanceType, setPerformanceType] = useState("country");

  const generatePdfReport = () => {
    console.log("Downloading PDF report...");
    alert("PDF report download started");
  };

  return (
    <div className="container mx-auto py-6 px-4 max-w-7xl">
      <div className="flex flex-col gap-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">MIS Dashboard</h1>
            <p className="text-muted-foreground">
              Executive analytics and performance metrics
            </p>
          </div>
          <Button onClick={generatePdfReport} className="gap-2">
            <DownloadIcon size={16} />
            Download PDF Report
          </Button>
        </div>

        {/* Graphical Analytics */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Monthly Net Flow */}
          <Card className="col-span-1 md:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2">
                <TrendingUpIcon size={20} />
                Monthly Net Flow
              </CardTitle>
              <CardDescription>
                Income vs expenses over the last 12 months
              </CardDescription>
            </CardHeader>
            <CardContent className="h-160">
              <ChartContainer
                config={{
                  income: { theme: { light: "#4ade80", dark: "#4ade80" } },
                  expenses: { theme: { light: "#f87171", dark: "#f87171" } },
                  net: { theme: { light: "#60a5fa", dark: "#60a5fa" } },
                }}
              >
                <LineChart
                  data={monthlyNetFlowData}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="income"
                    stroke="var(--color-income)"
                    activeDot={{ r: 8 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="expenses"
                    stroke="var(--color-expenses)"
                  />
                  <Line
                    type="monotone"
                    dataKey="net"
                    stroke="var(--color-net)"
                    strokeWidth={2}
                  />
                </LineChart>
              </ChartContainer>
            </CardContent>
          </Card>

          {/* Allocation Trend (Hot/Cold) */}
          <Card>
            <CardHeader>
              <CardTitle>Allocation Trend (Hot/Cold)</CardTitle>
              <CardDescription>
                Distribution between hot and cold investments over time
              </CardDescription>
            </CardHeader>
            <CardContent className="h-80">
              <ChartContainer
                config={{
                  hot: { theme: { light: "#f87171", dark: "#f87171" } },
                  cold: { theme: { light: "#60a5fa", dark: "#60a5fa" } },
                }}
              >
                <BarChart
                  data={hotColdTrendData}
                  margin={{
                    top: 20,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Legend />
                  <Bar
                    dataKey="hot"
                    stackId="a"
                    fill="var(--color-hot)"
                    name="Hot"
                  />
                  <Bar
                    dataKey="cold"
                    stackId="a"
                    fill="var(--color-cold)"
                    name="Cold"
                  />
                </BarChart>
              </ChartContainer>
            </CardContent>
          </Card>
          {/* Usage & Behavior Indicators */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UsersIcon size={20} />
                Usage & Behavior Indicators
              </CardTitle>
              <CardDescription>
                Analysis of user behavior patterns
              </CardDescription>
            </CardHeader>
            <CardContent className="h-80 space-y-4">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart outerRadius={90} data={behaviorData}>
                  <PolarGrid />
                  <PolarAngleAxis dataKey="name" />
                  <PolarRadiusAxis domain={[0, 5]} />
                  <Radar
                    name="Score"
                    dataKey="value"
                    stroke="#8884d8"
                    fill="#8884d8"
                    fillOpacity={0.6}
                  />
                  <Tooltip />
                </RadarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Comparative Performance Metrics */}
        <Card>
          <CardHeader>
            <CardTitle>Comparative Performance Metrics</CardTitle>
            <CardDescription>
              Performance comparison vs benchmarks
            </CardDescription>

            <div className="flex gap-2 pt-2">
              <Select
                value={performanceType}
                onValueChange={setPerformanceType}
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select comparison" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="country">vs Country</SelectItem>
                  <SelectItem value="type">vs Type</SelectItem>
                  <SelectItem value="tier">vs Tier</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent className="h-160">
            <ChartContainer
              config={{
                user: { theme: { light: "#8884d8", dark: "#8884d8" } },
                benchmark: { theme: { light: "#82ca9d", dark: "#82ca9d" } },
              }}
            >
              <BarChart
                data={comparativeData}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="category" />
                <YAxis />
                <ChartTooltip />
                <Legend />
                <Bar
                  dataKey="user"
                  name="Current Score"
                  fill="var(--color-user)"
                />
                <Bar
                  dataKey={performanceType}
                  name={`${
                    performanceType.charAt(0).toUpperCase() +
                    performanceType.slice(1)
                  } Average`}
                  fill="var(--color-benchmark)"
                />
              </BarChart>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ExecutiveMIS;
