"use client";
import { useState, useEffect } from "react";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Check } from "lucide-react";
import { toast } from "react-hot-toast";

const supportedCurrencies = [
    "BDT", "USD", "EUR", "GBP", "JPY", "CAD", "AUD", "INR", "SGD"
];
const supportedCountries = [
    "Bangladesh",
    "United States",
    "United Kingdom",
    "Germany",
    "Japan",
    "Canada",
    "Australia",
    "India",
    "Singapore"
];

const LOCAL_STORAGE_KEY = "velstron_bank_system_settings";

export default function SystemSettingsPage() {
    const [localSettings, setLocalSettings] = useState({
        supportedCurrencies: ["INR"],
        supportedCountries: ["India"],
    });
    const [loadingStates, setLoadingStates] = useState({
        supportedCurrencies: false,
        supportedCountries: false,
    });

    useEffect(() => {
        const storedSettings = localStorage.getItem(LOCAL_STORAGE_KEY);
        if (storedSettings) {
            try {
                const parsedSettings = JSON.parse(storedSettings);
                setLocalSettings({
                    supportedCurrencies: parsedSettings.supportedCurrencies || ["BDT"],
                    supportedCountries: parsedSettings.supportedCountries || ["Bangladesh"],
                });
            } catch (e) {
                console.error("Error parsing local storage settings:", e);
            }
        }
    }, []); 
    const handleMultiSelectChange = (section, value) => {
        setLocalSettings((prev) => ({
            ...prev,
            [section]: value,
        }));
    };

    const handleSave = (section) => {
        setLoadingStates((prev) => ({ ...prev, [section]: true }));
        setTimeout(() => {
            const updatedSettings = { ...localSettings };
            localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updatedSettings));
            toast.success(`${section.charAt(0).toUpperCase() + section.slice(1)} saved!`);
            setLoadingStates((prev) => ({ ...prev, [section]: false }));
        }, 500);
    };

    return (
        <div className="container mx-auto p-6">
            <h1 className="text-3xl font-semibold mb-6 text-gray-800">System Settings</h1>

            <div className="mb-8 rounded-lg border bg-white shadow p-6 animate-fade-in">
                <h2 className="text-xl font-semibold mb-4 text-gray-700 flex justify-between items-center">
                    Supported Currencies & Countries Config
                    <div>
                        <Button size="sm" onClick={() => handleSave("supportedCurrencies")} disabled={loadingStates.supportedCurrencies}>
                            {loadingStates.supportedCurrencies ? "Saving..." : "Save Currencies"}
                        </Button>
                        <Button size="sm" className="ml-2" onClick={() => handleSave("supportedCountries")} disabled={loadingStates.supportedCountries}>
                            {loadingStates.supportedCountries ? "Saving..." : "Save Countries"}
                        </Button>
                    </div>
                </h2>
                <div className="mb-4">
                    <Label className="block text-gray-600 text-sm font-medium mb-2">Supported Currencies</Label>
                    <DropdownMenu>
                        <DropdownMenuTrigger className="inline-flex w-full justify-between rounded-md border border-gray-300 px-3 py-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-indigo-500 data-[state=open]:bg-accent data-[state=open]:text-accent-foreground">
                            <span>{localSettings.supportedCurrencies.length > 0 ? localSettings.supportedCurrencies.join(", ") : "Select Currencies"}</span>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent className="w-56">
                            {supportedCurrencies.map((currency) => (
                                <DropdownMenuItem key={currency} onSelect={() => {
                                    const updatedCurrencies = localSettings.supportedCurrencies.includes(currency)
                                        ? localSettings.supportedCurrencies.filter((c) => c !== currency)
                                        : [...localSettings.supportedCurrencies, currency];
                                    handleMultiSelectChange("supportedCurrencies", updatedCurrencies);
                                }}>
                                    {localSettings.supportedCurrencies.includes(currency) && <Check className="mr-2 h-4 w-4" />}
                                    {currency}
                                </DropdownMenuItem>
                            ))}
                        </DropdownMenuContent>
                    </DropdownMenu>
                </div>
                <div>
                    <Label className="block text-gray-600 text-sm font-medium mb-2">Supported Countries</Label>
                    <DropdownMenu>
                        <DropdownMenuTrigger className="inline-flex w-full justify-between rounded-md border border-gray-300 px-3 py-2 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-indigo-500 data-[state=open]:bg-accent data-[state=open]:text-accent-foreground">
                            <span>{localSettings.supportedCountries.length > 0 ? localSettings.supportedCountries.join(", ") : "Select Countries"}</span>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent className="w-56">
                            {supportedCountries.map((country) => (
                                <DropdownMenuItem key={country} onSelect={() => {
                                    const updatedCountries = localSettings.supportedCountries.includes(country)
                                        ? localSettings.supportedCountries.filter((c) => c !== country)
                                        : [...localSettings.supportedCountries, country];
                                    handleMultiSelectChange("supportedCountries", updatedCountries);
                                }}>
                                    {localSettings.supportedCountries.includes(country) && <Check className="mr-2 h-4 w-4" />}
                                    {country}
                                </DropdownMenuItem>
                            ))}
                        </DropdownMenuContent>
                    </DropdownMenu>
                </div>
            </div>
        </div>
    );
}