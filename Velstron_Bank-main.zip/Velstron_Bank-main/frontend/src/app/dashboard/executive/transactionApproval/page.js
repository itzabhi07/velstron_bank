"use client";
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import {
  CheckCircle,
  XCircle,
  Clock,
  Eye,
  Filter,
  Search,
  Download,
  AlertTriangle,
} from "lucide-react";
import { toast } from "sonner";

// ... keep existing code (state and mock data setup)

const TransactionApproval = () => {
  const [selectedTransaction, setSelectedTransaction] = useState(null);
  const [activeTab, setActiveTab] = useState("pending");
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [filterAmount, setFilterAmount] = useState("all");
  const [rejectReason, setRejectReason] = useState("");
  const [approvalComments, setApprovalComments] = useState("");

  // Mock data for pending transactions
  const [pendingTransactions, setPendingTransactions] = useState([
    {
      id: "TXN001",
      accountNumber: "ACC12345678",
      type: "Wire Transfer",
      amount: 25000,
      currency: "USD",
      recipient: "ABC Corporation",
      recipientAccount: "987654321",
      description: "Business payment for services",
      submittedDate: "2024-01-15",
      submittedTime: "10:30 AM",
      status: "Pending",
      documents: ["wire_transfer_form.pdf", "invoice.pdf"],
    },
    {
      id: "TXN002",
      accountNumber: "ACC87654321",
      type: "International Transfer",
      amount: 15000,
      currency: "EUR",
      recipient: "XYZ Ltd",
      recipientAccount: "123456789",
      description: "Import payment",
      submittedDate: "2024-01-15",
      submittedTime: "11:15 AM",
      status: "Pending",
      documents: ["transfer_request.pdf"],
    },
    {
      id: "TXN003",
      accountNumber: "ACC11223344",
      type: "Domestic Transfer",
      amount: 5000,
      currency: "USD",
      recipient: "Personal Account",
      recipientAccount: "555666777",
      description: "Personal transfer",
      submittedDate: "2024-01-15",
      submittedTime: "02:45 PM",
      status: "Pending",
      documents: ["domestic_transfer.pdf"],
    },
  ]);

  // Mock data for processed transactions
  const [processedTransactions, setProcessedTransactions] = useState([
    {
      id: "TXN004",
      accountNumber: "ACC55667788",
      type: "Wire Transfer",
      amount: 30000,
      currency: "USD",
      recipient: "Global Corp",
      recipientAccount: "888999000",
      description: "Contract payment",
      submittedDate: "2024-01-14",
      processedDate: "2024-01-14",
      processedTime: "03:20 PM",
      status: "Approved",
      approvedBy: "Executive John",
      comments: "All documents verified",
    },
    {
      id: "TXN005",
      accountNumber: "ACC99887766",
      type: "International Transfer",
      amount: 50000,
      currency: "GBP",
      recipient: "UK Limited",
      recipientAccount: "111222333",
      description: "Investment payment",
      submittedDate: "2024-01-14",
      processedDate: "2024-01-14",
      processedTime: "01:15 PM",
      status: "Rejected",
      rejectedBy: "Executive Jane",
      comments: "Insufficient documentation",
    },
  ]);

  const handleApprove = (transactionId) => {
    const transaction = pendingTransactions.find((t) => t.id === transactionId);
    if (transaction) {
      // Update transaction status
      const updatedTransaction = {
        ...transaction,
        status: "Approved",
        processedDate: new Date().toISOString().split("T")[0],
        processedTime: new Date().toLocaleTimeString(),
        approvedBy: "Current Executive",
        comments: approvalComments,
      };

      // Move to processed transactions
      setProcessedTransactions((prev) => [updatedTransaction, ...prev]);
      setPendingTransactions((prev) =>
        prev.filter((t) => t.id !== transactionId)
      );

      setApprovalComments("");
      toast.success(`Transaction ${transactionId} approved successfully`);
    }
  };

  const handleReject = (transactionId) => {
    if (!rejectReason.trim()) {
      toast.error("Please provide a reason for rejection");
      return;
    }

    const transaction = pendingTransactions.find((t) => t.id === transactionId);
    if (transaction) {
      // Update transaction status
      const updatedTransaction = {
        ...transaction,
        status: "Rejected",
        processedDate: new Date().toISOString().split("T")[0],
        processedTime: new Date().toLocaleTimeString(),
        rejectedBy: "Current Executive",
        comments: rejectReason,
      };

      // Move to processed transactions
      setProcessedTransactions((prev) => [updatedTransaction, ...prev]);
      setPendingTransactions((prev) =>
        prev.filter((t) => t.id !== transactionId)
      );

      setRejectReason("");
      toast.success(`Transaction ${transactionId} rejected`);
    }
  };

  const handleViewDetails = (transaction) => {
    setSelectedTransaction(transaction);
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "Pending":
        return (
          <Badge
            variant="outline"
            className="bg-yellow-50 text-yellow-700 border-yellow-200"
          >
            <Clock className="w-3 h-3 mr-1" />
            Pending
          </Badge>
        );
      case "Approved":
        return (
          <Badge
            variant="outline"
            className="bg-green-50 text-green-700 border-green-200"
          >
            <CheckCircle className="w-3 h-3 mr-1" />
            Approved
          </Badge>
        );
      case "Rejected":
        return (
          <Badge
            variant="outline"
            className="bg-red-50 text-red-700 border-red-200"
          >
            <XCircle className="w-3 h-3 mr-1" />
            Rejected
          </Badge>
        );
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const filteredPendingTransactions = pendingTransactions.filter(
    (transaction) => {
      const matchesSearch =
        transaction.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        transaction.accountNumber
          .toLowerCase()
          .includes(searchTerm.toLowerCase());

      const matchesType =
        filterType === "all" || transaction.type === filterType;

      const matchesAmount =
        filterAmount === "all" ||
        (filterAmount === "low" && transaction.amount < 10000) ||
        (filterAmount === "medium" &&
          transaction.amount >= 10000 &&
          transaction.amount < 50000) ||
        (filterAmount === "high" && transaction.amount >= 50000);

      return matchesSearch && matchesType && matchesAmount;
    }
  );

  const filteredProcessedTransactions = processedTransactions.filter(
    (transaction) => {
      const matchesSearch =
        transaction.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        transaction.accountNumber
          .toLowerCase()
          .includes(searchTerm.toLowerCase());
      return matchesSearch;
    }
  );

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">
            Transaction Approval
          </h1>
          <p className="text-gray-600">
            Review and approve pending transactions
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">
                    Pending Approval
                  </p>
                  <p className="text-2xl font-bold text-yellow-600">
                    {pendingTransactions.length}
                  </p>
                </div>
                <Clock className="h-8 w-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">
                    Approved Today
                  </p>
                  <p className="text-2xl font-bold text-green-600">
                    {
                      processedTransactions.filter(
                        (t) =>
                          t.status === "Approved" &&
                          t.processedDate ===
                            new Date().toISOString().split("T")[0]
                      ).length
                    }
                  </p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">
                    Rejected Today
                  </p>
                  <p className="text-2xl font-bold text-red-600">
                    {
                      processedTransactions.filter(
                        (t) =>
                          t.status === "Rejected" &&
                          t.processedDate ===
                            new Date().toISOString().split("T")[0]
                      ).length
                    }
                  </p>
                </div>
                <XCircle className="h-8 w-8 text-red-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search by transaction ID, or account number..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex gap-4">
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Transaction Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="Wire Transfer">Wire Transfer</SelectItem>
                    <SelectItem value="International Transfer">
                      International Transfer
                    </SelectItem>
                    <SelectItem value="Domestic Transfer">
                      Domestic Transfer
                    </SelectItem>
                  </SelectContent>
                </Select>

                <Select value={filterAmount} onValueChange={setFilterAmount}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Amount Range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Amounts</SelectItem>
                    <SelectItem value="low">Under $10,000</SelectItem>
                    <SelectItem value="medium">$10,000 - $50,000</SelectItem>
                    <SelectItem value="high">Over $50,000</SelectItem>
                  </SelectContent>
                </Select>

                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Main Content */}
        <Tabs
          value={activeTab}
          onValueChange={setActiveTab}
          className="space-y-6"
        >
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="pending">
              Pending Transactions ({pendingTransactions.length})
            </TabsTrigger>
            <TabsTrigger value="processed">
              Transaction History ({processedTransactions.length})
            </TabsTrigger>
          </TabsList>

          {/* Pending Transactions */}
          <TabsContent value="pending">
            <Card>
              <CardHeader>
                <CardTitle>Pending Transactions</CardTitle>
                <CardDescription>
                  Transactions awaiting your approval
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Transaction ID</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Submitted</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPendingTransactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell className="font-medium">
                          {transaction.id}
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">
                              {transaction.accountNumber}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{transaction.type}</TableCell>
                        <TableCell>
                          <div className="font-medium">
                            {transaction.currency}{" "}
                            {transaction.amount.toLocaleString()}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">
                            <div>{transaction.submittedDate}</div>
                            <div className="text-gray-500">
                              {transaction.submittedTime}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleViewDetails(transaction)}
                                >
                                  <Eye className="w-4 h-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                                <DialogHeader>
                                  <DialogTitle>
                                    Transaction Details - {transaction.id}
                                  </DialogTitle>
                                  <DialogDescription>
                                    Review transaction information and take
                                    action
                                  </DialogDescription>
                                </DialogHeader>

                                {selectedTransaction && (
                                  <div className="space-y-6">
                                    {/* Transaction Overview */}
                                    <div className="grid grid-cols-2 gap-6">
                                      <div className="space-y-4">
                                        <h3 className="text-lg font-semibold">
                                          Transaction Information
                                        </h3>
                                        <div className="space-y-2">
                                          <div>
                                            <strong>Transaction ID:</strong>{" "}
                                            {selectedTransaction.id}
                                          </div>
                                          <div>
                                            <strong>Type:</strong>{" "}
                                            {selectedTransaction.type}
                                          </div>
                                          <div>
                                            <strong>Amount:</strong>{" "}
                                            {selectedTransaction.currency}{" "}
                                            {selectedTransaction.amount.toLocaleString()}
                                          </div>
                                          <div>
                                            <strong>Description:</strong>{" "}
                                            {selectedTransaction.description}
                                          </div>
                                        </div>
                                      </div>

                                      <div className="space-y-4">
                                        <h3 className="text-lg font-semibold">
                                          Customer Information
                                        </h3>
                                        <div className="space-y-2">
                                          <div>
                                            <strong>Account Number:</strong>{" "}
                                            {selectedTransaction.accountNumber}
                                          </div>
                                          <div>
                                            <strong>Recipient:</strong>{" "}
                                            {selectedTransaction.recipient}
                                          </div>
                                          <div>
                                            <strong>Recipient Account:</strong>{" "}
                                            {
                                              selectedTransaction.recipientAccount
                                            }
                                          </div>
                                          <div>
                                            <strong>Submitted:</strong>{" "}
                                            {selectedTransaction.submittedDate}{" "}
                                            at{" "}
                                            {selectedTransaction.submittedTime}
                                          </div>
                                        </div>
                                      </div>
                                    </div>

                                    {/* Documents */}
                                    <div>
                                      <h3 className="text-lg font-semibold mb-3">
                                        Supporting Documents
                                      </h3>
                                      <div className="flex flex-wrap gap-2">
                                        {selectedTransaction.documents?.map(
                                          (doc, index) => (
                                            <Button
                                              key={index}
                                              variant="outline"
                                              size="sm"
                                            >
                                              <Download className="w-4 h-4 mr-2" />
                                              {doc}
                                            </Button>
                                          )
                                        )}
                                      </div>
                                    </div>

                                    {/* Action Section */}
                                    <div className="space-y-4 border-t pt-4">
                                      <h3 className="text-lg font-semibold">
                                        Take Action
                                      </h3>

                                      {/* Approval Comments */}
                                      <div>
                                        <Label htmlFor="approvalComments">
                                          Comments (Optional)
                                        </Label>
                                        <Textarea
                                          id="approvalComments"
                                          placeholder="Add any comments for this approval..."
                                          value={approvalComments}
                                          onChange={(e) =>
                                            setApprovalComments(e.target.value)
                                          }
                                          rows={3}
                                        />
                                      </div>

                                      {/* Rejection Reason */}
                                      <div>
                                        <Label htmlFor="rejectReason">
                                          Rejection Reason (Required for
                                          rejection)
                                        </Label>
                                        <Textarea
                                          id="rejectReason"
                                          placeholder="Provide reason for rejection..."
                                          value={rejectReason}
                                          onChange={(e) =>
                                            setRejectReason(e.target.value)
                                          }
                                          rows={3}
                                        />
                                      </div>

                                      {/* Action Buttons */}
                                      <div className="flex space-x-4">
                                        <Button
                                          onClick={() =>
                                            handleApprove(
                                              selectedTransaction.id
                                            )
                                          }
                                          className="bg-green-600 hover:bg-green-700"
                                        >
                                          <CheckCircle className="w-4 h-4 mr-2" />
                                          Approve Transaction
                                        </Button>
                                        <Button
                                          variant="destructive"
                                          onClick={() =>
                                            handleReject(selectedTransaction.id)
                                          }
                                        >
                                          <XCircle className="w-4 h-4 mr-2" />
                                          Reject Transaction
                                        </Button>
                                      </div>
                                    </div>
                                  </div>
                                )}
                              </DialogContent>
                            </Dialog>

                            <Button
                              size="sm"
                              onClick={() => handleApprove(transaction.id)}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              <CheckCircle className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => handleReject(transaction.id)}
                            >
                              <XCircle className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Processed Transactions */}
          <TabsContent value="processed">
            <Card>
              <CardHeader>
                <CardTitle>Transaction History</CardTitle>
                <CardDescription>
                  Previously processed transactions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Transaction ID</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Processed By</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Comments</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredProcessedTransactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell className="font-medium">
                          {transaction.id}
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">
                              {transaction.accountNumber}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{transaction.type}</TableCell>
                        <TableCell>
                          <div className="font-medium">
                            {transaction.currency}{" "}
                            {transaction.amount.toLocaleString()}
                          </div>
                        </TableCell>
                        <TableCell>
                          {getStatusBadge(transaction.status)}
                        </TableCell>
                        <TableCell>
                          {transaction.approvedBy || transaction.rejectedBy}
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">
                            <div>{transaction.processedDate}</div>
                            <div className="text-gray-500">
                              {transaction.processedTime}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div
                            className="max-w-xs truncate"
                            title={transaction.comments}
                          >
                            {transaction.comments}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default TransactionApproval;
