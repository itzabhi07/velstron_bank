"use client";
import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Search,
  Filter,
  Settings,
  MoreHorizontal,
  User,
  Ban,
  Key,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const mockUsers = [
  {
    id: 1,
    name: "John Doe",
    email: "john@example.com",
    country: "USA",
    type: "Admin",
    status: "Active",
    accountNumber: "HOT-12345",
  },
  {
    id: 2,
    name: "Jane Smith",
    email: "jane@example.com",
    country: "Canada",
    type: "User",
    status: "Active",
    accountNumber: "COLD-23456",
  },
  {
    id: 3,
    name: "David Wilson",
    email: "david@example.com",
    country: "UK",
    type: "User",
    status: "Inactive",
    accountNumber: "HOT-34567",
  },
  {
    id: 4,
    name: "Sarah Brown",
    email: "sarah@example.com",
    country: "Australia",
    type: "Manager",
    status: "Active",
    accountNumber: "COLD-45678",
  },
  {
    id: 5,
    name: "Michael Davis",
    email: "michael@example.com",
    country: "Germany",
    type: "User",
    status: "Active",
    accountNumber: "HOT-56789",
  },
  {
    id: 6,
    name: "Emma Johnson",
    email: "emma@example.com",
    country: "France",
    type: "User",
    status: "Inactive",
    accountNumber: "COLD-67890",
  },
  {
    id: 7,
    name: "Daniel Lee",
    email: "daniel@example.com",
    country: "Japan",
    type: "Manager",
    status: "Active",
    accountNumber: "HOT-78901",
  },
  {
    id: 8,
    name: "Olivia Garcia",
    email: "olivia@example.com",
    country: "Spain",
    type: "User",
    status: "Active",
    accountNumber: "COLD-89012",
  },
];

function Page() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filters, setFilters] = useState({
    country: "",
    type: "",
    status: "",
    velstronId: "",
  });
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isPasswordResetDialogOpen, setIsPasswordResetDialogOpen] =
    useState(false);
  const [isAssignAccountDialogOpen, setIsAssignAccountDialogOpen] =
    useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [editFormData, setEditFormData] = useState({
    name: "",
    email: "",
    country: "",
    type: "",
    status: "",
  });

  const handleSearch = (e) => setSearchQuery(e.target.value);
  const toggleFilters = () => setIsFiltersOpen(!isFiltersOpen);

  const handleFilterChange = (key, value) => {
    if (["all-countries", "all-types", "all-statuses"].includes(value)) {
      setFilters({ ...filters, [key]: "" });
    } else {
      setFilters({ ...filters, [key]: value });
    }
  };

  const resetFilters = () =>
    setFilters({ country: "", type: "", status: "", velstronId: "" });

  const handleEdit = (user) => {
    setSelectedUser(user);
    setEditFormData({
      name: user.name,
      email: user.email,
      country: user.country,
      type: user.type,
      status: user.status,
    });
    setIsEditDialogOpen(true);
  };

  const handleFormChange = (key, value) =>
    setEditFormData({ ...editFormData, [key]: value });
  const saveUserEdits = () => {
    console.log("Saving user edits:", editFormData);
    setIsEditDialogOpen(false);
  };

  const handlePasswordReset = (user) => {
    setSelectedUser(user);
    setIsPasswordResetDialogOpen(true);
  };
  const confirmPasswordReset = () => {
    console.log("Password reset for user:", selectedUser);
    setIsPasswordResetDialogOpen(false);
  };

  const handleAssignAccount = (user) => {
    setSelectedUser(user);
    setIsAssignAccountDialogOpen(true);
  };
  const confirmAccountAssignment = (type) => {
    console.log(`Assigning ${type} account to user:`, selectedUser);
    setIsAssignAccountDialogOpen(false);
  };

  const handleDisableUser = (user) => {
    console.log("Disabling user:", user);
  };

  const filteredUsers = mockUsers.filter((user) => {
    const searchMatch =
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.accountNumber.toLowerCase().includes(searchQuery.toLowerCase());
    const countryMatch = filters.country
      ? user.country === filters.country
      : true;
    const typeMatch = filters.type ? user.type === filters.type : true;
    const statusMatch = filters.status ? user.status === filters.status : true;
    const velstronMatch = filters.velstronId
      ? user.id.toString() === filters.velstronId
      : true;
    return (
      searchMatch && countryMatch && typeMatch && statusMatch && velstronMatch
    );
  });

  const countries = [...new Set(mockUsers.map((u) => u.country))];
  const types = [...new Set(mockUsers.map((u) => u.type))];
  const statuses = [...new Set(mockUsers.map((u) => u.status))];

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold mb-6">User Management</h1>

      <div className="mb-6 flex flex-col gap-4">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search users by name, email, or account number..."
              value={searchQuery}
              onChange={handleSearch}
              className="pl-10"
            />
          </div>
          <Button
            variant="outline"
            onClick={toggleFilters}
            className="flex items-center gap-2"
          >
            <Filter size={16} />
            Filters
          </Button>
        </div>

        {isFiltersOpen && (
          <div className="bg-white p-4 rounded-md shadow-md border">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-1">
                  Country
                </label>
                <Select
                  value={filters.country}
                  onValueChange={(value) =>
                    handleFilterChange("country", value)
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-countries">All Countries</SelectItem>
                    {countries.map((country) => (
                      <SelectItem key={country} value={country}>
                        {country}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Type</label>
                <Select
                  value={filters.type}
                  onValueChange={(value) => handleFilterChange("type", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-types">All Types</SelectItem>
                    {types.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Status</label>
                <Select
                  value={filters.status}
                  onValueChange={(value) => handleFilterChange("status", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-statuses">All Statuses</SelectItem>
                    {statuses.map((status) => (
                      <SelectItem key={status} value={status}>
                        {status}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">
                  Velstron ID
                </label>
                <Input
                  placeholder="Enter ID..."
                  value={filters.velstronId}
                  onChange={(e) =>
                    handleFilterChange("velstronId", e.target.value)
                  }
                />
              </div>
            </div>
            <div className="flex justify-end">
              <Button variant="outline" onClick={resetFilters} className="mr-2">
                Reset
              </Button>
              <Button onClick={toggleFilters}>Apply Filters</Button>
            </div>
          </div>
        )}
      </div>

      <div className="rounded-md border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Country</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Account</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredUsers.length > 0 ? (
              filteredUsers.map((user) => (
                <TableRow key={user.id}>
                  <TableCell>{user.id}</TableCell>
                  <TableCell>{user.name}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>{user.country}</TableCell>
                  <TableCell>{user.type}</TableCell>
                  <TableCell>
                    <span
                      className={`px-2 py-1 rounded text-xs font-medium ${
                        user.status === "Active"
                          ? "bg-green-100 text-green-800"
                          : "bg-red-100 text-red-800"
                      }`}
                    >
                      {user.status}
                    </span>
                  </TableCell>
                  <TableCell>
                    <span
                      className={`px-2 py-1 rounded text-xs font-medium ${
                        user.accountNumber.startsWith("HOT")
                          ? "bg-orange-100 text-orange-800"
                          : "bg-blue-100 text-blue-800"
                      }`}
                    >
                      {user.accountNumber}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-white">
                        <DropdownMenuItem
                          onClick={() => handleEdit(user)}
                          className="cursor-pointer"
                        >
                          <User className="mr-2 h-4 w-4" />
                          <span>View/Edit Profile</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handleAssignAccount(user)}
                          className="cursor-pointer"
                        >
                          <Settings className="mr-2 h-4 w-4" />
                          <span>Assign Account</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handlePasswordReset(user)}
                          className="cursor-pointer"
                        >
                          <Key className="mr-2 h-4 w-4" />
                          <span>Reset Password</span>
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          onClick={() => handleDisableUser(user)}
                          className="cursor-pointer text-red-600"
                        >
                          <Ban className="mr-2 h-4 w-4" />
                          <span>Disable User</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-6">
                  No users found matching your search criteria
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Edit User Profile</DialogTitle>
            <DialogDescription>
              Make changes to the user&apos;s profile here. Click save when
              you&apos;re done.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <label className="text-right text-sm font-medium">Name</label>
              <Input
                className="col-span-3"
                value={editFormData.name}
                onChange={(e) => handleFormChange("name", e.target.value)}
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <label className="text-right text-sm font-medium">Email</label>
              <Input
                className="col-span-3"
                value={editFormData.email}
                onChange={(e) => handleFormChange("email", e.target.value)}
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <label className="text-right text-sm font-medium">Country</label>
              <Select
                value={editFormData.country}
                onValueChange={(value) => handleFormChange("country", value)}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select country" />
                </SelectTrigger>
                <SelectContent>
                  {countries.map((country) => (
                    <SelectItem key={country} value={country}>
                      {country}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <label className="text-right text-sm font-medium">Type</label>
              <Select
                value={editFormData.type}
                onValueChange={(value) => handleFormChange("type", value)}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  {types.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <label className="text-right text-sm font-medium">Status</label>
              <Select
                value={editFormData.status}
                onValueChange={(value) => handleFormChange("status", value)}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  {statuses.map((status) => (
                    <SelectItem key={status} value={status}>
                      {status}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsEditDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button onClick={saveUserEdits}>Save changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog
        open={isPasswordResetDialogOpen}
        onOpenChange={setIsPasswordResetDialogOpen}
      >
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Reset Password</DialogTitle>
            <DialogDescription>
              Are you sure you want to reset the password for{" "}
              {selectedUser?.name}? A new temporary password will be sent to
              their email address.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsPasswordResetDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button onClick={confirmPasswordReset}>Reset Password</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog
        open={isAssignAccountDialogOpen}
        onOpenChange={setIsAssignAccountDialogOpen}
      >
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Assign Account</DialogTitle>
            <DialogDescription>
              Choose an account type to assign to {selectedUser?.name}.
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-4 justify-center py-6">
            <Button
              onClick={() => confirmAccountAssignment("HOT")}
              className="bg-orange-500 hover:bg-orange-600 text-white"
            >
              Assign HOT Account
            </Button>
            <Button
              onClick={() => confirmAccountAssignment("COLD")}
              className="bg-blue-500 hover:bg-blue-600 text-white"
            >
              Assign COLD Account
            </Button>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsAssignAccountDialogOpen(false)}
            >
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default Page;
