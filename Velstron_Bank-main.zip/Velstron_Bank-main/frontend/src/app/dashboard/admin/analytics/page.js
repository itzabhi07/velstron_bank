"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import {
  Download,
  BarChart3,
  PieChart,
  Globe,
  TrendingUp,
  User,
  ListOrdered,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
} from "recharts";
import { format } from "date-fns";

const primaryColor = "#ffdd00";
const secondaryColor = "#0d62a6";

const formatCurrency = (value) => {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    notation: "compact",
    compactDisplay: "short",
  }).format(value);
};

export default function AnalyticsDashboard() {
  const [analyticsData, setAnalyticsData] = useState({
    totalAUMGlobal: 0,
    totalAUMByCountry: [],
    monthlyNetFlow: [],
    userLevelMIS: [],
    allocationTrends: { hot: 0, cold: 0 },
    countryWisePerformance: [],
    topAccountsByAUM: [],
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
  async function fetchAnalytics() {
    try {
      setLoading(true);
      const res = await fetch('/api/analytics/analytics');  // simple GET
      if (!res.ok) throw new Error('Failed to fetch analytics data');
      const data = await res.json();
      setAnalyticsData(data);
      setError(null);
    } catch (err) {
      setError(err.message);
      setAnalyticsData(null);
    } finally {
      setLoading(false);
    }
  }

  fetchAnalytics();
}, []);

  const exportToPDF = (data, filename) => {
    import('jspdf').then((jsPDFModule) => {
      import('jspdf-autotable').then((autoTableModule) => {
        const doc = new jsPDFModule.default();

        if (autoTableModule && typeof autoTableModule.default === 'function') {
          autoTableModule.default(doc, {
            head: [Object.keys(data[0] || {}).map((key) => key.toUpperCase())],
            body: data.map((item) => Object.values(item)),
          });
        } else if (typeof doc.autoTable === 'function') {
          doc.autoTable({
            head: [Object.keys(data[0] || {}).map((key) => key.toUpperCase())],
            body: data.map((item) => Object.values(item)),
          });
        } else {
          console.error("jspdf-autotable plugin was not correctly loaded.");
          return;
        }

        doc.save(`${filename}.pdf`);
      });
    });
  };

  const exportToExcel = (data, filename) => {
    import('xlsx').then((xlsx) => {
      const worksheet = xlsx.utils.json_to_sheet(data);
      const workbook = xlsx.utils.book_new();
      xlsx.utils.book_append_sheet(workbook, worksheet, 'Data');
      xlsx.writeFile(workbook, `${filename}.xlsx`);
    });
  };

  if (loading) {
    return <div className="container mx-auto p-6">Loading Analytics Data...</div>;
  }

  if (error) {
    return <div className="container mx-auto p-6 text-red-500">Error: {error}</div>;
  }

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-semibold mb-6 text-gray-800">Analytics Dashboard</h1>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mb-6">
        {/* Total AUM (Global) */}
        <div className="rounded-lg border bg-white shadow p-6 animate-fade-in">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-700">Total AUM (Global)</h3>
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-100 text-blue-500">
              <Globe className="h-4 w-4" />
            </div>
          </div>
          <p className="text-2xl font-bold text-gray-800">{formatCurrency(analyticsData.totalAUMGlobal)}</p>
        </div>

        {/* Total AUM by Country */}
        <div className="rounded-lg border bg-white shadow p-6 animate-fade-in">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-700">AUM by Country</h3>
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-green-100 text-green-500">
              <BarChart3 className="h-4 w-4" />
            </div>
          </div>
          <ul className="space-y-2">
            {analyticsData.totalAUMByCountry.map((item) => (
              <li key={item.country} className="flex items-center justify-between text-sm text-gray-600">
                <span>{item.country}</span>
                <span className="font-medium">{formatCurrency(item.aum)}</span>
              </li>
            ))}
          </ul>
          {analyticsData.totalAUMByCountry.length > 0 && (
            <button
              onClick={() => exportToPDF(analyticsData.totalAUMByCountry, "aum_by_country")}
              className="inline-flex items-center mt-4 text-sm font-medium text-indigo-600 hover:text-indigo-500"
            >
              <Download className="h-4 w-4 mr-1" />
              Download
            </button>
          )}
        </div>

        {/* Allocation Trends */}
        <div className="rounded-lg border bg-white shadow p-6 animate-fade-in">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-700">Allocation Trends</h3>
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-yellow-100 text-yellow-500">
              <PieChart className="h-4 w-4" />
            </div>
          </div>
          <div className="flex items-center justify-around">
            <div className="text-center">
              <p className="text-xl font-bold text-gray-800">{analyticsData.allocationTrends.hot}%</p>
              <p className="text-sm text-gray-500">Hot</p>
            </div>
            <div className="text-center">
              <p className="text-xl font-bold text-gray-800">{analyticsData.allocationTrends.cold}%</p>
              <p className="text-sm text-gray-500">Cold</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2 mb-6">
        {/* Monthly Net Flow Charts */}
        <div className="rounded-lg border bg-white shadow p-6 animate-fade-in">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-700">Monthly Net Flow</h3>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => exportToPDF(analyticsData.monthlyNetFlow, "monthly_net_flow")}
                className="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
              >
                <Download className="h-4 w-4 mr-1 text-gray-500" />
                <span>PDF</span>
              </button>
              <button
                onClick={() => exportToExcel(analyticsData.monthlyNetFlow, "monthly_net_flow")}
                className="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
              >
                <Download className="h-4 w-4 mr-1 text-gray-500" />
                <span>Excel</span>
              </button>
            </div>
          </div>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analyticsData.monthlyNetFlow}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis tickFormatter={formatCurrency} />
                <Tooltip formatter={(value) => [formatCurrency(value), "Net Flow"]} />
                <Legend />
                <Bar dataKey="netFlow" name="Net Flow" fill={primaryColor} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Country-wise Performance */}
        <div className="rounded-lg border bg-white shadow p-6 animate-fade-in">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-700">Country-wise Performance</h3>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => exportToPDF(analyticsData.countryWisePerformance, "country_performance")}
                className="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
              >
                <Download className="h-4 w-4 mr-1 text-gray-500" />
                <span>PDF</span>
              </button>
              <button
                onClick={() => exportToExcel(analyticsData.countryWisePerformance, "country_performance")}
                className="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
              >
                <Download className="h-4 w-4 mr-1 text-gray-500" />
                <span>Excel</span>
              </button>
            </div>
          </div>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analyticsData.countryWisePerformance}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="country" />
                <YAxis tickFormatter={(value) => `${(value * 100).toFixed(2)}%`} />
                <Tooltip formatter={(value) => [`${(value * 100).toFixed(2)}%`, "Performance"]} />
                <Legend />
                <Bar dataKey="performance" name="Performance" fill={secondaryColor} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2 mb-6">
        {/* Top Accounts by AUM */}
        <div className="rounded-lg border bg-white shadow p-6 animate-fade-in">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-700">Top Accounts by AUM</h3>
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-indigo-100 text-indigo-500">
              <ListOrdered className="h-4 w-4" />
            </div>
          </div>
          <ul>
            {analyticsData.topAccountsByAUM.map((item) => (
              <li key={item.accountId} className="py-2 border-b last:border-b-0">
                <div className="flex items-center justify-between text-sm text-gray-600">
                  <span>{item.accountId}</span>
                  <span className="font-medium">{formatCurrency(item.aum)}</span>
                </div>
              </li>
            ))}
          </ul>
          {analyticsData.topAccountsByAUM.length > 0 && (
            <button
              onClick={() => exportToPDF(analyticsData.topAccountsByAUM, "top_accounts_aum")}
              className="inline-flex items-center mt-4 text-sm font-medium text-indigo-600 hover:text-indigo-500"
            >
              <Download className="h-4 w-4 mr-1" />
              Download
            </button>
          )}
        </div>

        {/* User-Level MIS */}
        <div className="rounded-lg border bg-white shadow p-6 animate-fade-in overflow-x-auto">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-700">User-Level MIS</h3>
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-purple-100 text-purple-500">
              <User className="h-4 w-4" />
            </div>
          </div>
          <table className="min-w-full leading-normal">
            <thead>
              <tr>
                <th className="px-3 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  User ID
                </th>
                <th className="px-3 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Total Investment
                </th>
                <th className="px-3 py-2 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Active Since
                </th>
              </tr>
            </thead>
            <tbody>
              {analyticsData.userLevelMIS.map((user) => (
                <tr key={user.userId}>
                  <td className="px-3 py-2 border-b border-gray-200 text-sm">{user.userId}</td>
                  <td className="px-3 py-2 border-b border-gray-200 text-sm">{formatCurrency(user.totalInvestment)}</td>
                  <td className="px-3 py-2 border-b border-gray-200 text-sm">{user.activeSince}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {analyticsData.userLevelMIS.length > 0 && (
            <button
              onClick={() => exportToPDF(analyticsData.userLevelMIS, "user_level_mis")}
              className="inline-flex items-center mt-4 text-sm font-medium text-indigo-600 hover:text-indigo-500"
            >
              <Download className="h-4 w-4 mr-1" />
              Download
            </button>
          )}
        </div>
      </div>
    </div>
  );
}