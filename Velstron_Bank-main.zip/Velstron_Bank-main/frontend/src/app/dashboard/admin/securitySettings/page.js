"use client";
import React, { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Shield,
  Users,
  Clock,
  Key,
  LogOut,
  AlertTriangle,
  Check,
  X,
} from "lucide-react";

const SecuritySettings = () => {
  const [permissions, setPermissions] = useState({
    admin: {
      createUsers: true,
      deleteUsers: true,
      manageRoles: true,
      viewReports: true,
      systemSettings: true,
      kycApproval: true,
      accountCreation: true,
      auditLogs: true,
    },
    executive: {
      createUsers: false,
      deleteUsers: false,
      manageRoles: false,
      viewReports: true,
      systemSettings: false,
      kycApproval: true,
      accountCreation: true,
      auditLogs: false,
    },
  });

  const [twoFactorSettings, setTwoFactorSettings] = useState({
    adminRequired: true,
    executiveRequired: false,
    customerRequired: false,
    backupCodes: true,
    smsEnabled: true,
    emailEnabled: true,
  });

  const [loginLogs] = useState([
    {
      id: 1,
      user: "admin@bank.com",
      role: "Admin",
      device: "Chrome - Windows 10",
      ip: "192.168.1.100",
      location: "New York, US",
      time: "2024-01-15 14:30:22",
      status: "Success",
    },
    {
      id: 2,
      user: "executive1@bank.com",
      role: "Executive",
      device: "Safari - MacOS",
      ip: "192.168.1.105",
      location: "Los Angeles, US",
      time: "2024-01-15 13:45:11",
      status: "Success",
    },
    {
      id: 3,
      user: "exec2@bank.com",
      role: "Executive",
      device: "Firefox - Ubuntu",
      ip: "10.0.0.50",
      location: "Chicago, US",
      time: "2024-01-15 12:15:33",
      status: "Failed",
    },
    {
      id: 4,
      user: "admin2@bank.com",
      role: "Admin",
      device: "Edge - Windows 11",
      ip: "172.16.0.25",
      location: "Miami, US",
      time: "2024-01-15 11:20:45",
      status: "Success",
    },
  ]);

  const [activeSessions] = useState([
    {
      id: 1,
      user: "admin@bank.com",
      device: "Chrome - Windows 10",
      ip: "192.168.1.100",
      loginTime: "2024-01-15 14:30:22",
      lastActivity: "2024-01-15 16:45:10",
      status: "Active",
    },
    {
      id: 2,
      user: "executive1@bank.com",
      device: "Safari - MacOS",
      ip: "192.168.1.105",
      loginTime: "2024-01-15 13:45:11",
      lastActivity: "2024-01-15 16:40:33",
      status: "Active",
    },
    {
      id: 3,
      user: "exec3@bank.com",
      device: "Mobile App - iOS",
      ip: "203.0.113.45",
      loginTime: "2024-01-15 10:15:22",
      lastActivity: "2024-01-15 15:20:11",
      status: "Idle",
    },
  ]);

  const handlePermissionChange = (role, permission, value) => {
    setPermissions((prev) => ({
      ...prev,
      [role]: {
        ...prev[role],
        [permission]: value,
      },
    }));
  };

  const handle2FAChange = (setting, value) => {
    setTwoFactorSettings((prev) => ({
      ...prev,
      [setting]: value,
    }));
  };

  const handleForceLogout = (sessionId) => {
    console.log(`Force logout session: ${sessionId}`);
    // Add logout logic here
  };

  const handlePasswordReset = (userEmail) => {
    console.log(`Password reset for: ${userEmail}`);
    // Add password reset logic here
  };

  const permissionLabels = {
    createUsers: "Create Users",
    deleteUsers: "Delete Users",
    manageRoles: "Manage Roles",
    viewReports: "View Reports",
    systemSettings: "System Settings",
    kycApproval: "KYC Approval",
    accountCreation: "Account Creation",
    auditLogs: "Audit Logs",
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Shield className="h-8 w-8 text-blue-600" />
            Security Settings
          </h1>
          <p className="text-gray-600 mt-2">
            Manage system security, permissions, and access controls
          </p>
        </div>

        <Tabs defaultValue="permissions" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="permissions">Permissions</TabsTrigger>
            <TabsTrigger value="2fa">2FA Settings</TabsTrigger>
            <TabsTrigger value="logs">Login Logs</TabsTrigger>
            <TabsTrigger value="password">Password Reset</TabsTrigger>
            <TabsTrigger value="sessions">Active Sessions</TabsTrigger>
          </TabsList>

          {/* Permission Role Matrix */}
          <TabsContent value="permissions">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Permission Role Matrix
                </CardTitle>
                <CardDescription>
                  Configure permissions for different user roles
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Permission</TableHead>
                        <TableHead className="text-center">Admin</TableHead>
                        <TableHead className="text-center">Executive</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {Object.keys(permissionLabels).map((permission) => (
                        <TableRow key={permission}>
                          <TableCell className="font-medium">
                            {permissionLabels[permission]}
                          </TableCell>
                          <TableCell className="text-center">
                            <Switch
                              checked={permissions.admin[permission]}
                              onCheckedChange={(value) =>
                                handlePermissionChange(
                                  "admin",
                                  permission,
                                  value
                                )
                              }
                            />
                          </TableCell>
                          <TableCell className="text-center">
                            <Switch
                              checked={permissions.executive[permission]}
                              onCheckedChange={(value) =>
                                handlePermissionChange(
                                  "executive",
                                  permission,
                                  value
                                )
                              }
                            />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                <div className="mt-6">
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    Save Permission Changes
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* 2FA Settings */}
          <TabsContent value="2fa">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key className="h-5 w-5" />
                  Two-Factor Authentication Settings
                </CardTitle>
                <CardDescription>
                  Configure 2FA requirements for different user types
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">
                        Role Requirements
                      </h3>

                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <p className="font-medium">Admin Users</p>
                          <p className="text-sm text-gray-600">
                            Require 2FA for all admin accounts
                          </p>
                        </div>
                        <Switch
                          checked={twoFactorSettings.adminRequired}
                          onCheckedChange={(value) =>
                            handle2FAChange("adminRequired", value)
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <p className="font-medium">Executive Users</p>
                          <p className="text-sm text-gray-600">
                            Require 2FA for executive accounts
                          </p>
                        </div>
                        <Switch
                          checked={twoFactorSettings.executiveRequired}
                          onCheckedChange={(value) =>
                            handle2FAChange("executiveRequired", value)
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <p className="font-medium">Customer Accounts</p>
                          <p className="text-sm text-gray-600">
                            Require 2FA for customer accounts
                          </p>
                        </div>
                        <Switch
                          checked={twoFactorSettings.customerRequired}
                          onCheckedChange={(value) =>
                            handle2FAChange("customerRequired", value)
                          }
                        />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">
                        Authentication Methods
                      </h3>

                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <p className="font-medium">SMS Authentication</p>
                          <p className="text-sm text-gray-600">
                            Enable SMS-based 2FA
                          </p>
                        </div>
                        <Switch
                          checked={twoFactorSettings.smsEnabled}
                          onCheckedChange={(value) =>
                            handle2FAChange("smsEnabled", value)
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <p className="font-medium">Email Authentication</p>
                          <p className="text-sm text-gray-600">
                            Enable email-based 2FA
                          </p>
                        </div>
                        <Switch
                          checked={twoFactorSettings.emailEnabled}
                          onCheckedChange={(value) =>
                            handle2FAChange("emailEnabled", value)
                          }
                        />
                      </div>

                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <p className="font-medium">Backup Codes</p>
                          <p className="text-sm text-gray-600">
                            Enable backup recovery codes
                          </p>
                        </div>
                        <Switch
                          checked={twoFactorSettings.backupCodes}
                          onCheckedChange={(value) =>
                            handle2FAChange("backupCodes", value)
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <div className="pt-4">
                    <Button className="bg-blue-600 hover:bg-blue-700">
                      Save 2FA Settings
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Login Logs */}
          <TabsContent value="logs">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Login Logs
                </CardTitle>
                <CardDescription>
                  Monitor user login activities and authentication attempts
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Export Logs
                      </Button>
                      <Button variant="outline" size="sm">
                        Filter
                      </Button>
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>User</TableHead>
                          <TableHead>Role</TableHead>
                          <TableHead>Device</TableHead>
                          <TableHead>IP Address</TableHead>
                          <TableHead>Location</TableHead>
                          <TableHead>Time</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {loginLogs.map((log) => (
                          <TableRow key={log.id}>
                            <TableCell className="font-medium">
                              {log.user}
                            </TableCell>
                            <TableCell>
                              <Badge
                                variant={
                                  log.role === "Admin" ? "default" : "secondary"
                                }
                              >
                                {log.role}
                              </Badge>
                            </TableCell>
                            <TableCell>{log.device}</TableCell>
                            <TableCell>{log.ip}</TableCell>
                            <TableCell>{log.location}</TableCell>
                            <TableCell>{log.time}</TableCell>
                            <TableCell>
                              <Badge
                                variant={
                                  log.status === "Success"
                                    ? "default"
                                    : "destructive"
                                }
                                className={
                                  log.status === "Success" ? "bg-green-600" : ""
                                }
                              >
                                {log.status === "Success" ? (
                                  <>
                                    <Check className="h-3 w-3 mr-1" /> Success
                                  </>
                                ) : (
                                  <>
                                    <X className="h-3 w-3 mr-1" /> Failed
                                  </>
                                )}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Password Reset Access */}
          <TabsContent value="password">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key className="h-5 w-5" />
                  Password Reset Access
                </CardTitle>
                <CardDescription>
                  Manage password reset requests and user account access
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">Reset Options</h3>

                      <div className="space-y-3">
                        <div className="p-4 border rounded-lg">
                          <p className="font-medium mb-2">Admin Users</p>
                          <div className="space-y-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() =>
                                handlePasswordReset("admin@bank.com")
                              }
                            >
                              Reset Admin Password
                            </Button>
                            <p className="text-sm text-gray-600">
                              Force password reset for admin accounts
                            </p>
                          </div>
                        </div>

                        <div className="p-4 border rounded-lg">
                          <p className="font-medium mb-2">Executive Users</p>
                          <div className="space-y-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() =>
                                handlePasswordReset("executive@bank.com")
                              }
                            >
                              Reset Executive Password
                            </Button>
                            <p className="text-sm text-gray-600">
                              Force password reset for executive accounts
                            </p>
                          </div>
                        </div>

                        <div className="p-4 border rounded-lg">
                          <p className="font-medium mb-2">Customer Accounts</p>
                          <div className="space-y-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() =>
                                handlePasswordReset("customer@email.com")
                              }
                            >
                              Reset Customer Password
                            </Button>
                            <p className="text-sm text-gray-600">
                              Send password reset email to customers
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">Reset Policies</h3>

                      <div className="space-y-3">
                        <div className="p-4 border rounded-lg bg-yellow-50">
                          <div className="flex items-center gap-2 mb-2">
                            <AlertTriangle className="h-4 w-4 text-yellow-600" />
                            <p className="font-medium text-yellow-800">
                              Security Notice
                            </p>
                          </div>
                          <p className="text-sm text-yellow-700">
                            Password resets require email verification and
                            expire after 24 hours
                          </p>
                        </div>

                        <div className="p-4 border rounded-lg">
                          <p className="font-medium mb-2">Reset Frequency</p>
                          <p className="text-sm text-gray-600">
                            Maximum 3 reset attempts per 24 hours per user
                          </p>
                        </div>

                        <div className="p-4 border rounded-lg">
                          <p className="font-medium mb-2">
                            Password Requirements
                          </p>
                          <ul className="text-sm text-gray-600 space-y-1">
                            <li>• Minimum 12 characters</li>
                            <li>
                              • Must include uppercase, lowercase, numbers
                            </li>
                            <li>• At least one special character</li>
                            <li>• Cannot reuse last 5 passwords</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Session Termination */}
          <TabsContent value="sessions">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LogOut className="h-5 w-5" />
                  Active Sessions & Force Logout
                </CardTitle>
                <CardDescription>
                  Monitor and manage active user sessions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <p className="text-sm text-gray-600">
                      {activeSessions.length} active sessions found
                    </p>
                    <Button variant="destructive" size="sm">
                      Force Logout All Sessions
                    </Button>
                  </div>

                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>User</TableHead>
                          <TableHead>Device</TableHead>
                          <TableHead>IP Address</TableHead>
                          <TableHead>Login Time</TableHead>
                          <TableHead>Last Activity</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {activeSessions.map((session) => (
                          <TableRow key={session.id}>
                            <TableCell className="font-medium">
                              {session.user}
                            </TableCell>
                            <TableCell>{session.device}</TableCell>
                            <TableCell>{session.ip}</TableCell>
                            <TableCell>{session.loginTime}</TableCell>
                            <TableCell>{session.lastActivity}</TableCell>
                            <TableCell>
                              <Badge
                                variant={
                                  session.status === "Active"
                                    ? "default"
                                    : "secondary"
                                }
                                className={
                                  session.status === "Active"
                                    ? "bg-green-600"
                                    : "bg-yellow-600"
                                }
                              >
                                {session.status}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Button
                                variant="destructive"
                                size="sm"
                                onClick={() => handleForceLogout(session.id)}
                              >
                                <LogOut className="h-3 w-3 mr-1" />
                                Force Logout
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>

                  <div className="mt-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="h-4 w-4 text-red-600" />
                      <p className="font-medium text-red-800">
                        Session Management Policy
                      </p>
                    </div>
                    <ul className="text-sm text-red-700 space-y-1">
                      <li>
                        • Sessions automatically expire after 8 hours of
                        inactivity
                      </li>
                      <li>• Force logout immediately terminates user access</li>
                      <li>
                        • Users will need to re-authenticate after forced logout
                      </li>
                      <li>
                        • All session actions are logged for audit purposes
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default SecuritySettings;
