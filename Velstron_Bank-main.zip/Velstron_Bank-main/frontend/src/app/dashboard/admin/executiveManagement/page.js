"use client";
import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Search,
  Filter,
  User,
  Key,
  MoreHorizontal,
  Lock,
  Activity,
  FileText,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";

// Mock executives data for demonstration
const mockExecutives = [
  {
    id: 1,
    name: "John Smith",
    email: "john@example.com",
    position: "CEO",
    department: "Executive",
    region: "Global",
    countries: ["USA", "UK", "Canada"],
    status: "Active",
    lastActive: "2023-05-21",
  },
  {
    id: 2,
    name: "Sarah Johnson",
    email: "sarah@example.com",
    position: "CFO",
    department: "Finance",
    region: "North America",
    countries: ["USA", "Canada"],
    status: "Active",
    lastActive: "2023-05-20",
  },
  {
    id: 3,
    name: "Michael Chen",
    email: "michael@example.com",
    position: "COO",
    department: "Operations",
    region: "Asia Pacific",
    countries: ["China", "Japan", "Australia"],
    status: "Active",
    lastActive: "2023-05-19",
  },
  {
    id: 4,
    name: "Emma Davis",
    email: "emma@example.com",
    position: "CTO",
    department: "Technology",
    region: "Europe",
    countries: ["Germany", "France", "Italy"],
    status: "On Leave",
    lastActive: "2023-05-15",
  },
  {
    id: 5,
    name: "David Wilson",
    email: "david@example.com",
    position: "CMO",
    department: "Marketing",
    region: "Middle East",
    countries: ["UAE", "Saudi Arabia", "Qatar"],
    status: "Active",
    lastActive: "2023-05-21",
  },
  {
    id: 6,
    name: "Olivia Brown",
    email: "olivia@example.com",
    position: "CHRO",
    department: "Human Resources",
    region: "Africa",
    countries: ["South Africa", "Nigeria", "Kenya"],
    status: "Inactive",
    lastActive: "2023-05-10",
  },
];

// Mock regions and countries data
const mockRegions = [
  { name: "Global", countries: ["All Countries"] },
  { name: "North America", countries: ["USA", "Canada", "Mexico"] },
  { name: "Europe", countries: ["UK", "Germany", "France", "Italy", "Spain"] },
  {
    name: "Asia Pacific",
    countries: ["China", "Japan", "Australia", "India", "Singapore"],
  },
  {
    name: "Middle East",
    countries: ["UAE", "Saudi Arabia", "Qatar", "Kuwait"],
  },
  { name: "Africa", countries: ["South Africa", "Nigeria", "Kenya", "Egypt"] },
  {
    name: "Latin America",
    countries: ["Brazil", "Argentina", "Colombia", "Chile"],
  },
];

// Mock performance metrics
const mockPerformanceMetrics = [
  {
    id: 1,
    executiveId: 1,
    metric: "Revenue Growth",
    value: "15%",
    period: "2023 Q2",
    trend: "up",
  },
  {
    id: 2,
    executiveId: 1,
    metric: "Cost Reduction",
    value: "8%",
    period: "2023 Q2",
    trend: "up",
  },
  {
    id: 3,
    executiveId: 1,
    metric: "Team Performance",
    value: "92%",
    period: "2023 Q2",
    trend: "stable",
  },
  {
    id: 4,
    executiveId: 2,
    metric: "Revenue Growth",
    value: "12%",
    period: "2023 Q2",
    trend: "up",
  },
  {
    id: 5,
    executiveId: 2,
    metric: "Cost Reduction",
    value: "10%",
    period: "2023 Q2",
    trend: "up",
  },
  {
    id: 6,
    executiveId: 3,
    metric: "Revenue Growth",
    value: "8%",
    period: "2023 Q2",
    trend: "down",
  },
  {
    id: 7,
    executiveId: 4,
    metric: "Team Performance",
    value: "85%",
    period: "2023 Q2",
    trend: "stable",
  },
];

// Mock activity logs
const mockActivityLogs = [
  {
    id: 1,
    executiveId: 1,
    activity: "Login",
    timestamp: "2023-05-21 09:30:00",
    ip: "192.168.1.1",
    device: "Desktop - Chrome",
  },
  {
    id: 2,
    executiveId: 1,
    activity: "Approved Budget",
    timestamp: "2023-05-21 10:15:00",
    ip: "192.168.1.1",
    device: "Desktop - Chrome",
  },
  {
    id: 3,
    executiveId: 1,
    activity: "Downloaded Report",
    timestamp: "2023-05-21 11:30:00",
    ip: "192.168.1.1",
    device: "Desktop - Chrome",
  },
  {
    id: 4,
    executiveId: 2,
    activity: "Login",
    timestamp: "2023-05-20 08:45:00",
    ip: "192.168.1.2",
    device: "Mobile - Safari",
  },
  {
    id: 5,
    executiveId: 2,
    activity: "Updated Profile",
    timestamp: "2023-05-20 09:10:00",
    ip: "192.168.1.2",
    device: "Mobile - Safari",
  },
  {
    id: 6,
    executiveId: 3,
    activity: "Login",
    timestamp: "2023-05-19 14:20:00",
    ip: "192.168.1.3",
    device: "Tablet - Chrome",
  },
];

const ExecutiveManagement = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [filters, setFilters] = useState({
    region: "",
    department: "",
    position: "",
    status: "",
  });
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);

  // Dialog states
  const [isAddEditDialogOpen, setIsAddEditDialogOpen] = useState(false);
  const [isAssignRegionDialogOpen, setIsAssignRegionDialogOpen] =
    useState(false);
  const [isPerformanceDialogOpen, setIsPerformanceDialogOpen] = useState(false);
  const [isResetPasswordDialogOpen, setIsResetPasswordDialogOpen] =
    useState(false);
  const [isActivityLogsDialogOpen, setIsActivityLogsDialogOpen] =
    useState(false);

  const [selectedExecutive, setSelectedExecutive] = useState(null);
  const [selectedRegion, setSelectedRegion] = useState("");
  const [selectedCountries, setSelectedCountries] = useState([]);
  const [availableCountries, setAvailableCountries] = useState([]);

  // Form states
  const [executiveForm, setExecutiveForm] = useState({
    name: "",
    email: "",
    position: "",
    department: "",
    region: "",
    status: "Active",
  });

  // Handle search
  const handleSearch = (e) => {
    setSearchQuery(e.target.value);
  };

  // Toggle filters
  const toggleFilters = () => {
    setIsFiltersOpen(!isFiltersOpen);
  };

  // Apply filters
  const handleFilterChange = (key, value) => {
    if (
      value === "all-regions" ||
      value === "all-departments" ||
      value === "all-positions" ||
      value === "all-statuses"
    ) {
      setFilters({ ...filters, [key]: "" });
    } else {
      setFilters({ ...filters, [key]: value });
    }
  };

  // Reset filters
  const resetFilters = () => {
    setFilters({
      region: "",
      department: "",
      position: "",
      status: "",
    });
  };

  // Handle executive edit
  const handleEdit = (executive) => {
    setSelectedExecutive(executive);
    setExecutiveForm({
      name: executive.name,
      email: executive.email,
      position: executive.position,
      department: executive.department,
      region: executive.region,
      status: executive.status,
    });
    setIsAddEditDialogOpen(true);
  };

  // Handle executive add
  const handleAdd = () => {
    setSelectedExecutive(null);
    setExecutiveForm({
      name: "",
      email: "",
      position: "",
      department: "",
      region: "",
      status: "Active",
    });
    setIsAddEditDialogOpen(true);
  };

  // Handle form change
  const handleFormChange = (key, value) => {
    setExecutiveForm({ ...executiveForm, [key]: value });
  };

  // Save executive (add or edit)
  const saveExecutive = () => {
    if (
      !executiveForm.name ||
      !executiveForm.email ||
      !executiveForm.position ||
      !executiveForm.department ||
      !executiveForm.region
    ) {
      toast.error("Please fill in all required fields");
      return;
    }

    // In a real app, you would save the executive to the database
    if (selectedExecutive) {
      // Edit existing executive
      toast.success(`Executive ${executiveForm.name} updated successfully`);
    } else {
      // Add new executive
      toast.success(`Executive ${executiveForm.name} added successfully`);
    }
    setIsAddEditDialogOpen(false);
  };

  // Open region assignment dialog
  const handleAssignRegion = (executive) => {
    setSelectedExecutive(executive);
    setSelectedRegion(executive.region);

    // Find available countries for the selected region
    const region = mockRegions.find((r) => r.name === executive.region);
    setAvailableCountries(region ? region.countries : []);

    // Set selected countries
    setSelectedCountries(executive.countries || []);

    setIsAssignRegionDialogOpen(true);
  };

  // Handle region change in assign region dialog
  const handleRegionChange = (region) => {
    setSelectedRegion(region);

    // Find available countries for the selected region
    const regionData = mockRegions.find((r) => r.name === region);
    setAvailableCountries(regionData ? regionData.countries : []);

    // Reset selected countries when region changes
    setSelectedCountries([]);
  };

  // Toggle country selection
  const toggleCountrySelection = (country) => {
    if (selectedCountries.includes(country)) {
      setSelectedCountries(selectedCountries.filter((c) => c !== country));
    } else {
      setSelectedCountries([...selectedCountries, country]);
    }
  };

  // Save region assignment
  const saveRegionAssignment = () => {
    // In a real app, you would save the region assignment to the database
    toast.success(`Region and countries assigned to ${selectedExecutive.name}`);
    setIsAssignRegionDialogOpen(false);
  };

  // View performance reports
  const handleViewPerformance = (executive) => {
    setSelectedExecutive(executive);
    setIsPerformanceDialogOpen(true);
  };

  // Reset password
  const handleResetPassword = (executive) => {
    setSelectedExecutive(executive);
    setIsResetPasswordDialogOpen(true);
  };

  const confirmPasswordReset = () => {
    // In a real app, you would reset the password and send an email
    toast.success(`Password reset email sent to ${selectedExecutive.email}`);
    setIsResetPasswordDialogOpen(false);
  };

  // View activity logs
  const handleViewActivityLogs = (executive) => {
    setSelectedExecutive(executive);
    setIsActivityLogsDialogOpen(true);
  };

  // Apply search and filters to executives list
  const filteredExecutives = mockExecutives.filter((executive) => {
    // Apply search
    const searchMatch =
      executive.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      executive.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      executive.position.toLowerCase().includes(searchQuery.toLowerCase());

    // Apply filters
    const regionMatch = filters.region
      ? executive.region === filters.region
      : true;
    const departmentMatch = filters.department
      ? executive.department === filters.department
      : true;
    const positionMatch = filters.position
      ? executive.position === filters.position
      : true;
    const statusMatch = filters.status
      ? executive.status === filters.status
      : true;

    return (
      searchMatch &&
      regionMatch &&
      departmentMatch &&
      positionMatch &&
      statusMatch
    );
  });

  // Get unique values for filter dropdowns
  const regions = Array.from(
    new Set(mockExecutives.map((executive) => executive.region))
  );
  const departments = Array.from(
    new Set(mockExecutives.map((executive) => executive.department))
  );
  const positions = Array.from(
    new Set(mockExecutives.map((executive) => executive.position))
  );
  const statuses = Array.from(
    new Set(mockExecutives.map((executive) => executive.status))
  );

  // Get performance metrics for selected executive
  const executivePerformance = (executiveId) => {
    return mockPerformanceMetrics.filter(
      (metric) => metric.executiveId === executiveId
    );
  };

  // Get activity logs for selected executive
  const executiveActivityLogs = (executiveId) => {
    return mockActivityLogs.filter((log) => log.executiveId === executiveId);
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold mb-6">Executive Management</h1>

      {/* Top Action Bar */}
      <div className="flex flex-wrap gap-4 mb-6">
        <Button
          onClick={handleAdd}
          className="flex items-center gap-2 bg-[#174e82] text-white hover:bg-[#174e82]/90"
        >
          <User size={16} />
          Add Executive
        </Button>
      </div>

      {/* Search and Filters */}
      <div className="mb-6 flex flex-col gap-4">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search executives by name, email, or position..."
              value={searchQuery}
              onChange={handleSearch}
              className="pl-10"
            />
          </div>
          <Button
            variant="outline"
            onClick={toggleFilters}
            className="flex items-center gap-2"
          >
            <Filter size={16} />
            Filters
          </Button>
        </div>

        {isFiltersOpen && (
          <div className="bg-white p-4 rounded-md shadow-md border dark:bg-background">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-1">Region</label>
                <Select
                  value={filters.region}
                  onValueChange={(value) => handleFilterChange("region", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select region" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-regions">All Regions</SelectItem>
                    {regions.map((region) => (
                      <SelectItem key={region} value={region}>
                        {region}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">
                  Department
                </label>
                <Select
                  value={filters.department}
                  onValueChange={(value) =>
                    handleFilterChange("department", value)
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select department" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-departments">
                      All Departments
                    </SelectItem>
                    {departments.map((department) => (
                      <SelectItem key={department} value={department}>
                        {department}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">
                  Position
                </label>
                <Select
                  value={filters.position}
                  onValueChange={(value) =>
                    handleFilterChange("position", value)
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select position" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-positions">All Positions</SelectItem>
                    {positions.map((position) => (
                      <SelectItem key={position} value={position}>
                        {position}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Status</label>
                <Select
                  value={filters.status}
                  onValueChange={(value) => handleFilterChange("status", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-statuses">All Statuses</SelectItem>
                    {statuses.map((status) => (
                      <SelectItem key={status} value={status}>
                        {status}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex justify-end">
              <Button variant="outline" onClick={resetFilters} className="mr-2">
                Reset
              </Button>
              <Button onClick={toggleFilters}>Apply Filters</Button>
            </div>
          </div>
        )}
      </div>

      {/* Executives Table */}
      <div className="rounded-md border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Position</TableHead>
              <TableHead>Department</TableHead>
              <TableHead>Region</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Last Active</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredExecutives.length > 0 ? (
              filteredExecutives.map((executive) => (
                <TableRow key={executive.id}>
                  <TableCell>{executive.id}</TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium">{executive.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {executive.email}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{executive.position}</TableCell>
                  <TableCell>{executive.department}</TableCell>
                  <TableCell>{executive.region}</TableCell>
                  <TableCell>
                    <span
                      className={`px-2 py-1 rounded text-xs font-medium ${
                        executive.status === "Active"
                          ? "bg-green-100 text-green-800"
                          : executive.status === "On Leave"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-red-100 text-red-800"
                      }`}
                    >
                      {executive.status}
                    </span>
                  </TableCell>
                  <TableCell>{executive.lastActive}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent
                        align="end"
                        className="bg-white dark:bg-background"
                      >
                        <DropdownMenuItem
                          onClick={() => handleEdit(executive)}
                          className="cursor-pointer"
                        >
                          <User className="mr-2 h-4 w-4" />
                          <span>Edit Executive</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handleAssignRegion(executive)}
                          className="cursor-pointer"
                        >
                          <FileText className="mr-2 h-4 w-4" />
                          <span>Assign Region/Country</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handleViewPerformance(executive)}
                          className="cursor-pointer"
                        >
                          <Activity className="mr-2 h-4 w-4" />
                          <span>View Performance</span>
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          onClick={() => handleResetPassword(executive)}
                          className="cursor-pointer"
                        >
                          <Key className="mr-2 h-4 w-4" />
                          <span>Reset Password</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handleViewActivityLogs(executive)}
                          className="cursor-pointer"
                        >
                          <Lock className="mr-2 h-4 w-4" />
                          <span>Activity Logs</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-6">
                  No executives found matching your search criteria
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {/* Add/Edit Executive Dialog */}
      <Dialog open={isAddEditDialogOpen} onOpenChange={setIsAddEditDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>
              {selectedExecutive ? "Edit Executive" : "Add Executive"}
            </DialogTitle>
            <DialogDescription>
              {selectedExecutive
                ? "Update executive information below."
                : "Enter executive details below to create a new executive profile."}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <label className="text-right text-sm font-medium">Name</label>
              <Input
                className="col-span-3"
                value={executiveForm.name}
                onChange={(e) => handleFormChange("name", e.target.value)}
                placeholder="Full name"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <label className="text-right text-sm font-medium">Email</label>
              <Input
                className="col-span-3"
                value={executiveForm.email}
                onChange={(e) => handleFormChange("email", e.target.value)}
                type="email"
                placeholder="Email address"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <label className="text-right text-sm font-medium">Position</label>
              <Input
                className="col-span-3"
                value={executiveForm.position}
                onChange={(e) => handleFormChange("position", e.target.value)}
                placeholder="Executive position"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <label className="text-right text-sm font-medium">
                Department
              </label>
              <Input
                className="col-span-3"
                value={executiveForm.department}
                onChange={(e) => handleFormChange("department", e.target.value)}
                placeholder="Department"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <label className="text-right text-sm font-medium">Region</label>
              <Select
                value={executiveForm.region}
                onValueChange={(value) => handleFormChange("region", value)}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select region" />
                </SelectTrigger>
                <SelectContent>
                  {mockRegions.map((region) => (
                    <SelectItem key={region.name} value={region.name}>
                      {region.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <label className="text-right text-sm font-medium">Status</label>
              <Select
                value={executiveForm.status}
                onValueChange={(value) => handleFormChange("status", value)}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Active">Active</SelectItem>
                  <SelectItem value="On Leave">On Leave</SelectItem>
                  <SelectItem value="Inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsAddEditDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button onClick={saveExecutive}>Save Executive</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Assign Region/Country Dialog */}
      <Dialog
        open={isAssignRegionDialogOpen}
        onOpenChange={setIsAssignRegionDialogOpen}
      >
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Assign Region and Countries</DialogTitle>
            <DialogDescription>
              Assign region and countries for {selectedExecutive?.name}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <label className="text-right text-sm font-medium">Region</label>
              <Select value={selectedRegion} onValueChange={handleRegionChange}>
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select region" />
                </SelectTrigger>
                <SelectContent>
                  {mockRegions.map((region) => (
                    <SelectItem key={region.name} value={region.name}>
                      {region.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-4 items-start gap-4">
              <label className="text-right text-sm font-medium pt-2">
                Countries
              </label>
              <div className="col-span-3 border rounded-md p-4 max-h-60 overflow-y-auto">
                {availableCountries.length > 0 ? (
                  availableCountries.map((country) => (
                    <div
                      key={country}
                      className="flex items-center space-x-2 mb-2"
                    >
                      <Checkbox
                        id={`country-${country}`}
                        checked={selectedCountries.includes(country)}
                        onCheckedChange={() => toggleCountrySelection(country)}
                      />
                      <label
                        htmlFor={`country-${country}`}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        {country}
                      </label>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground">
                    Select a region to view available countries
                  </p>
                )}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsAssignRegionDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button onClick={saveRegionAssignment}>Save Assignment</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Performance Dialog */}
      <Dialog
        open={isPerformanceDialogOpen}
        onOpenChange={setIsPerformanceDialogOpen}
      >
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>
              Performance Reports: {selectedExecutive?.name}
            </DialogTitle>
            <DialogDescription>
              View performance metrics and KPIs for this executive
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <h3 className="text-lg font-medium mb-4">
              Current Quarter Performance
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {selectedExecutive &&
              executivePerformance(selectedExecutive.id).length > 0 ? (
                executivePerformance(selectedExecutive.id).map((metric) => (
                  <Card key={metric.id} className="bg-white dark:bg-card">
                    <CardContent className="p-6">
                      <div className="text-sm text-muted-foreground mb-1">
                        {metric.metric}
                      </div>
                      <div className="text-2xl font-bold flex items-center">
                        {metric.value}
                        {metric.trend === "up" && (
                          <span className="ml-2 text-green-500">↑</span>
                        )}
                        {metric.trend === "down" && (
                          <span className="ml-2 text-red-500">↓</span>
                        )}
                        {metric.trend === "stable" && (
                          <span className="ml-2 text-gray-500">→</span>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground mt-2">
                        {metric.period}
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <div className="col-span-3 text-center py-6 text-muted-foreground">
                  No performance metrics available for this executive
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setIsPerformanceDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reset Password Dialog */}
      <Dialog
        open={isResetPasswordDialogOpen}
        onOpenChange={setIsResetPasswordDialogOpen}
      >
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Reset Password</DialogTitle>
            <DialogDescription>
              Are you sure you want to reset the password for{" "}
              {selectedExecutive?.name}? A new temporary password will be sent
              to their email address.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsResetPasswordDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button onClick={confirmPasswordReset}>Reset Password</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Activity Logs Dialog */}
      <Dialog
        open={isActivityLogsDialogOpen}
        onOpenChange={setIsActivityLogsDialogOpen}
      >
        <DialogContent className="sm:max-w-[700px]">
          <DialogHeader>
            <DialogTitle>Activity Logs: {selectedExecutive?.name}</DialogTitle>
            <DialogDescription>
              View recent activity logs for this executive
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="rounded-md border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Activity</TableHead>
                    <TableHead>Timestamp</TableHead>
                    <TableHead>IP Address</TableHead>
                    <TableHead>Device</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {selectedExecutive &&
                  executiveActivityLogs(selectedExecutive.id).length > 0 ? (
                    executiveActivityLogs(selectedExecutive.id).map((log) => (
                      <TableRow key={log.id}>
                        <TableCell>{log.activity}</TableCell>
                        <TableCell>{log.timestamp}</TableCell>
                        <TableCell>{log.ip}</TableCell>
                        <TableCell>{log.device}</TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-6">
                        No activity logs available for this executive
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setIsActivityLogsDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ExecutiveManagement;
