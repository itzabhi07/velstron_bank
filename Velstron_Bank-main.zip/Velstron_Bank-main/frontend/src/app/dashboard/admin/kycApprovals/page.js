"use client";
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "react-hot-toast";
import { format } from "date-fns";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { CalendarIcon, Check, FileText, UploadIcon, X } from "lucide-react";
import { cn } from "@/lib/utils";

// Mock data for KYC applications waiting for admin review
const mockPendingAdminApprovals = [
  {
    id: "APP004",
    applicantName: "Sarah Williams",
    applicationType: "UHNI",
    submissionDate: new Date(2023, 4, 10),
    reviewDate: new Date(2023, 4, 12),
    status: "approved_by_executive",
    reviewedBy: "Lisa Chen",
    documents: [
      { id: "DOC011", name: "Passport", status: "approved", url: "#" },
      { id: "DOC012", name: "Proof of Address", status: "approved", url: "#" },
      { id: "DOC013", name: "Selfie", status: "approved", url: "#" },
    ],
    history: [
      {
        date: new Date(2023, 4, 10),
        action: "Application Submitted",
        by: "Sarah Williams",
        notes: "",
      },
      {
        date: new Date(2023, 4, 11),
        action: "Under Review",
        by: "System",
        notes: "Auto-assigned to review queue",
      },
      {
        date: new Date(2023, 4, 12),
        action: "Approved by Executive",
        by: "Lisa Chen",
        notes: "All documents verified",
      },
    ],
  },
  {
    id: "APP006",
    applicantName: "David Lee",
    applicationType: "Corporate",
    submissionDate: new Date(2023, 4, 9),
    reviewDate: new Date(2023, 4, 11),
    status: "approved_by_executive",
    reviewedBy: "Thomas Brown",
    documents: [
      {
        id: "DOC017",
        name: "Certificate of Incorporation",
        status: "approved",
        url: "#",
      },
      { id: "DOC018", name: "Tax License", status: "approved", url: "#" },
      { id: "DOC019", name: "Board Resolution", status: "approved", url: "#" },
    ],
    history: [
      {
        date: new Date(2023, 4, 9),
        action: "Application Submitted",
        by: "David Lee",
        notes: "",
      },
      {
        date: new Date(2023, 4, 10),
        action: "Under Review",
        by: "System",
        notes: "Auto-assigned to review queue",
      },
      {
        date: new Date(2023, 4, 11),
        action: "Approved by Executive",
        by: "Thomas Brown",
        notes: "All documents verified",
      },
    ],
  },
];

// Mock data for pending applications (same as executive page)
const mockKycApplications = [
  {
    id: "APP001",
    applicantName: "John Smith",
    applicationType: "UHNI",
    submissionDate: new Date(2023, 4, 15),
    status: "pending",
    documents: [
      { id: "DOC001", name: "Passport", status: "submitted", url: "#" },
      { id: "DOC002", name: "Proof of Address", status: "submitted", url: "#" },
      { id: "DOC003", name: "Selfie", status: "submitted", url: "#" },
    ],
    history: [
      {
        date: new Date(2023, 4, 15),
        action: "Application Submitted",
        by: "John Smith",
        notes: "",
      },
      {
        date: new Date(2023, 4, 16),
        action: "Under Review",
        by: "System",
        notes: "Auto-assigned to review queue",
      },
    ],
  },
  {
    id: "APP002",
    applicantName: "Emma Johnson",
    applicationType: "Corporate",
    submissionDate: new Date(2023, 4, 14),
    status: "pending",
    documents: [
      {
        id: "DOC004",
        name: "Certificate of Incorporation",
        status: "submitted",
        url: "#",
      },
      {
        id: "DOC005",
        name: "Tax License",
        status: "reupload_requested",
        url: "#",
      },
      { id: "DOC006", name: "Board Resolution", status: "submitted", url: "#" },
    ],
    history: [
      {
        date: new Date(2023, 4, 14),
        action: "Application Submitted",
        by: "Emma Johnson",
        notes: "",
      },
      {
        date: new Date(2023, 4, 15),
        action: "Under Review",
        by: "System",
        notes: "Auto-assigned to review queue",
      },
      {
        date: new Date(2023, 4, 16),
        action: "Reupload Requested",
        by: "David Wilson",
        notes: "Tax License not clearly visible",
      },
    ],
  },
];

// Mock data for finalized applications
const mockFinalizedApplications = [
  {
    id: "APP007",
    applicantName: "James Wilson",
    applicationType: "UHNI",
    submissionDate: new Date(2023, 4, 5),
    finalReviewDate: new Date(2023, 4, 8),
    status: "approved",
    reviewedByExecutive: "Lisa Chen",
    reviewedByAdmin: "Admin User",
    documents: [
      { id: "DOC020", name: "Passport", status: "approved", url: "#" },
      { id: "DOC021", name: "Proof of Address", status: "approved", url: "#" },
      { id: "DOC022", name: "Selfie", status: "approved", url: "#" },
    ],
    history: [
      {
        date: new Date(2023, 4, 5),
        action: "Application Submitted",
        by: "James Wilson",
        notes: "",
      },
      {
        date: new Date(2023, 4, 6),
        action: "Under Review",
        by: "System",
        notes: "Auto-assigned to review queue",
      },
      {
        date: new Date(2023, 4, 7),
        action: "Approved by Executive",
        by: "Lisa Chen",
        notes: "All documents verified",
      },
      {
        date: new Date(2023, 4, 8),
        action: "Final Approval",
        by: "Admin User",
        notes: "Account activation approved",
      },
    ],
  },
  {
    id: "APP008",
    applicantName: "Patricia Moore",
    applicationType: "Corporate",
    submissionDate: new Date(2023, 4, 3),
    finalReviewDate: new Date(2023, 4, 7),
    status: "rejected",
    reviewedByExecutive: "Thomas Brown",
    reviewedByAdmin: "Admin User",
    documents: [
      {
        id: "DOC023",
        name: "Certificate of Incorporation",
        status: "rejected",
        url: "#",
      },
      { id: "DOC024", name: "Tax License", status: "approved", url: "#" },
      { id: "DOC025", name: "Board Resolution", status: "approved", url: "#" },
    ],
    history: [
      {
        date: new Date(2023, 4, 3),
        action: "Application Submitted",
        by: "Patricia Moore",
        notes: "",
      },
      {
        date: new Date(2023, 4, 4),
        action: "Under Review",
        by: "System",
        notes: "Auto-assigned to review queue",
      },
      {
        date: new Date(2023, 4, 6),
        action: "Approved by Executive",
        by: "Thomas Brown",
        notes: "All documents verified",
      },
      {
        date: new Date(2023, 4, 7),
        action: "Final Rejection",
        by: "Admin User",
        notes: "Discrepancies found in incorporation certificate",
      },
    ],
  },
];

// Mock data for executives
const mockExecutives = [
  { id: "EXE001", name: "Lisa Chen" },
  { id: "EXE002", name: "Thomas Brown" },
  { id: "EXE003", name: "David Wilson" },
  { id: "EXE004", name: "Amanda Garcia" },
];

// Schemas for form validation
const rejectFormSchema = z.object({
  reason: z
    .string()
    .min(10, { message: "Rejection reason must be at least 10 characters." }),
});

const requestReuploadFormSchema = z.object({
  documentIds: z
    .array(z.string())
    .min(1, { message: "Select at least one document" }),
  reason: z
    .string()
    .min(10, { message: "Reason must be at least 10 characters." }),
});

const assignExecutiveFormSchema = z.object({
  executiveId: z.string().min(1, { message: "Please select an executive" }),
  note: z.string().optional(),
});

// Status badge component
const StatusBadge = ({ status }) => {
  let badgeColor;
  let statusText;

  switch (status) {
    case "approved":
      badgeColor = "bg-green-500";
      statusText = "Approved";
      break;
    case "approved_by_executive":
      badgeColor = "bg-green-300";
      statusText = "Approved by Executive";
      break;
    case "rejected":
      badgeColor = "bg-red-500";
      statusText = "Rejected";
      break;
    case "rejected_by_executive":
      badgeColor = "bg-red-300";
      statusText = "Rejected by Executive";
      break;
    case "reupload_requested":
      badgeColor = "bg-amber-500";
      statusText = "Reupload Requested";
      break;
    default:
      badgeColor = "bg-blue-500";
      statusText = "Pending";
  }

  return <Badge className={`${badgeColor} text-white`}>{statusText}</Badge>;
};

// Document item component
const DocumentItem = ({ document, onAction }) => {
  return (
    <div className="flex items-center justify-between border p-3 rounded-md mb-2">
      <div className="flex items-center gap-2">
        <FileText size={18} />
        <span>{document.name}</span>
        <StatusBadge status={document.status} />
      </div>
      <div className="flex gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => onAction("view", document)}
        >
          View
        </Button>
      </div>
    </div>
  );
};

// Document viewer component
const DocumentViewer = ({ document, onClose }) => {
  return (
    <div className="bg-gray-50 p-4 rounded-md">
      <div className="flex justify-between mb-4">
        <h3 className="text-lg font-medium">{document.name}</h3>
        <Button variant="ghost" size="sm" onClick={onClose}>
          <X size={16} />
        </Button>
      </div>
      <div className="aspect-[4/3] bg-gray-200 flex items-center justify-center rounded-md mb-4">
        <p className="text-gray-500">[Document Preview Placeholder]</p>
        {/* In a real implementation, this would be an actual document viewer */}
      </div>
      <div className="flex justify-end gap-2">
        <Button variant="outline" size="sm">
          Download
        </Button>
      </div>
    </div>
  );
};

// Document history component
const DocumentHistory = ({ history }) => {
  return (
    <div className="space-y-4">
      {history.map((event, index) => (
        <div key={index} className="border-l-2 border-gray-300 pl-4 pb-4">
          <div className="flex justify-between">
            <p className="font-medium">{event.action}</p>
            <p className="text-sm text-gray-500">
              {format(event.date, "MMM dd, yyyy HH:mm")}
            </p>
          </div>
          <p className="text-sm text-gray-600">By: {event.by}</p>
          {event.notes && <p className="text-sm mt-1">{event.notes}</p>}
        </div>
      ))}
    </div>
  );
};

// Main KYC admin review page
const KYCAdminReview = () => {
  const [selectedTab, setSelectedTab] = useState("admin-approval");
  const [selectedApplication, setSelectedApplication] = useState(null);
  const [viewingDocument, setViewingDocument] = useState(null);
  const [openDialog, setOpenDialog] = useState("");

  // Initialize forms
  const rejectForm = useForm({
    resolver: zodResolver(rejectFormSchema),
    defaultValues: { reason: "" },
  });

  const requestReuploadForm = useForm({
    resolver: zodResolver(requestReuploadFormSchema),
    defaultValues: { documentIds: [], reason: "" },
  });

  const assignExecutiveForm = useForm({
    resolver: zodResolver(assignExecutiveFormSchema),
    defaultValues: { executiveId: "", note: "" },
  });

  const handleDocumentAction = (action, document) => {
    if (action === "view") {
      setViewingDocument(document);
    }
  };

  const handleApprove = () => {
    toast.success(
      `Application ${selectedApplication.id} has been finally approved. Account activation in progress.`,
      {
        duration: 4000,
        position: "top-right",
      }
    );

    setSelectedApplication(null);
    setOpenDialog("");
  };

  const handleReject = (data) => {
    toast.error(
      `Application ${selectedApplication.id} has been rejected. Notification sent to applicant.`,
      {
        duration: 4000,
        position: "top-right",
      }
    );

    rejectForm.reset();
    setSelectedApplication(null);
    setOpenDialog("");
  };

  const handleRequestReupload = (data) => {
    toast.success(
      `Reupload request sent for ${data.documentIds.length} document(s). Email notification sent to applicant.`,
      {
        duration: 4000,
        position: "top-right",
      }
    );

    requestReuploadForm.reset();
    setSelectedApplication(null);
    setOpenDialog("");
  };

  const handleAssignExecutive = (data) => {
    const executiveName = mockExecutives.find(
      (e) => e.id === data.executiveId
    ).name;
    toast.success(
      `Application ${selectedApplication.id} has been assigned to ${executiveName}.`,
      {
        duration: 4000,
        position: "top-right",
      }
    );

    assignExecutiveForm.reset();
    setSelectedApplication(null);
    setOpenDialog("");
  };

  const renderApplicationTable = (applications) => (
    <div className="rounded-md border overflow-hidden">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              ID
            </th>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Applicant Name
            </th>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Type
            </th>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Submission Date
            </th>
            {selectedTab === "admin-approval" && (
              <th
                scope="col"
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
              >
                Executive
              </th>
            )}
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Status
            </th>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {applications.map((app) => (
            <tr key={app.id}>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                {app.id}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {app.applicantName}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {app.applicationType}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {format(app.submissionDate, "MMM dd, yyyy")}
              </td>
              {selectedTab === "admin-approval" && (
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {app.reviewedBy}
                </td>
              )}
              <td className="px-6 py-4 whitespace-nowrap">
                <StatusBadge status={app.status} />
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedApplication(app)}
                >
                  Review
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  return (
    <div className="container mx-auto py-8 px-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">KYC Admin Dashboard</CardTitle>
          <CardDescription>
            Manage KYC applications and make final decisions
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs
            defaultValue="admin-approval"
            value={selectedTab}
            onValueChange={setSelectedTab}
          >
            <TabsList className="mb-4">
              <TabsTrigger value="admin-approval">
                Awaiting Final Approval
              </TabsTrigger>
              <TabsTrigger value="pending">Pending Applications</TabsTrigger>
              <TabsTrigger value="finalized">
                Finalized Applications
              </TabsTrigger>
            </TabsList>

            {/* Applications awaiting admin final approval after executive review */}
            <TabsContent value="admin-approval" className="space-y-4">
              {!selectedApplication ? (
                renderApplicationTable(mockPendingAdminApprovals)
              ) : (
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <h2 className="text-xl font-bold">
                      {selectedApplication.applicantName} -{" "}
                      {selectedApplication.id}
                    </h2>
                    <Button
                      variant="outline"
                      onClick={() => setSelectedApplication(null)}
                    >
                      Back to List
                    </Button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card className="col-span-2">
                      <CardHeader>
                        <CardTitle>Submitted Documents</CardTitle>
                      </CardHeader>
                      <CardContent>
                        {viewingDocument ? (
                          <DocumentViewer
                            document={viewingDocument}
                            onClose={() => setViewingDocument(null)}
                          />
                        ) : (
                          <div className="space-y-2">
                            {selectedApplication.documents.map((doc) => (
                              <DocumentItem
                                key={doc.id}
                                document={doc}
                                onAction={handleDocumentAction}
                              />
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    <div className="space-y-6">
                      <Card>
                        <CardHeader>
                          <CardTitle>Application Details</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <dl className="grid grid-cols-1 gap-2 text-sm">
                            <div className="flex justify-between">
                              <dt className="font-medium">Application Type:</dt>
                              <dd>{selectedApplication.applicationType}</dd>
                            </div>
                            <div className="flex justify-between">
                              <dt className="font-medium">Submission Date:</dt>
                              <dd>
                                {selectedApplication.submissionDate
                                  ? format(
                                      new Date(
                                        selectedApplication.submissionDate
                                      ),
                                      "MMM dd, yyyy"
                                    )
                                  : "Pending"}
                              </dd>
                            </div>
                            <div className="flex justify-between">
                              <dt className="font-medium">
                                Executive Review Date:
                              </dt>
                              <dd>
                                {format(
                                  selectedApplication.reviewDate,
                                  "MMM dd, yyyy"
                                )}
                              </dd>
                            </div>
                            <div className="flex justify-between">
                              <dt className="font-medium">Reviewed By:</dt>
                              <dd>{selectedApplication.reviewedBy}</dd>
                            </div>
                            <div className="flex justify-between">
                              <dt className="font-medium">Status:</dt>
                              <dd>
                                <StatusBadge
                                  status={selectedApplication.status}
                                />
                              </dd>
                            </div>
                          </dl>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle>Document History</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <DocumentHistory
                            history={selectedApplication.history}
                          />
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle>Admin Actions</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-2">
                          <Button
                            className="w-full bg-green-600 hover:bg-green-700"
                            onClick={() => setOpenDialog("approve")}
                          >
                            Approve
                          </Button>
                          <Button
                            className="w-full bg-red-600 hover:bg-red-700"
                            onClick={() => setOpenDialog("reject")}
                          >
                            Reject
                          </Button>
                          <Button
                            className="w-full bg-amber-600 hover:bg-amber-700"
                            onClick={() => setOpenDialog("reupload")}
                          >
                            Request Reupload
                          </Button>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </div>
              )}
            </TabsContent>

            {/* Pending applications that can be directly processed or assigned */}
            <TabsContent value="pending" className="space-y-4">
              {!selectedApplication ? (
                renderApplicationTable(mockKycApplications)
              ) : (
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <h2 className="text-xl font-bold">
                      {selectedApplication.applicantName} -{" "}
                      {selectedApplication.id}
                    </h2>
                    <Button
                      variant="outline"
                      onClick={() => setSelectedApplication(null)}
                    >
                      Back to List
                    </Button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card className="col-span-2">
                      <CardHeader>
                        <CardTitle>Submitted Documents</CardTitle>
                      </CardHeader>
                      <CardContent>
                        {viewingDocument ? (
                          <DocumentViewer
                            document={viewingDocument}
                            onClose={() => setViewingDocument(null)}
                          />
                        ) : (
                          <div className="space-y-2">
                            {selectedApplication.documents.map((doc) => (
                              <DocumentItem
                                key={doc.id}
                                document={doc}
                                onAction={handleDocumentAction}
                              />
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    <div className="space-y-6">
                      <Card>
                        <CardHeader>
                          <CardTitle>Application Details</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <dl className="grid grid-cols-1 gap-2 text-sm">
                            <div className="flex justify-between">
                              <dt className="font-medium">Application Type:</dt>
                              <dd>{selectedApplication.applicationType}</dd>
                            </div>
                            <div className="flex justify-between">
                              <dt className="font-medium">Submission Date:</dt>
                              <dd>
                                {format(
                                  selectedApplication.submissionDate,
                                  "MMM dd, yyyy"
                                )}
                              </dd>
                            </div>
                            <div className="flex justify-between">
                              <dt className="font-medium">Review Date:</dt>
                              <dd>
                                {format(
                                  selectedApplication.reviewDate,
                                  "MMM dd, yyyy"
                                )}
                              </dd>
                            </div>
                            <div className="flex justify-between">
                              <dt className="font-medium">Status:</dt>
                              <dd>
                                <StatusBadge
                                  status={selectedApplication.status}
                                />
                              </dd>
                            </div>
                          </dl>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle>Document History</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <DocumentHistory
                            history={selectedApplication.history}
                          />
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle>Admin Actions</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-2">
                          <Button
                            className="w-full"
                            onClick={() => setOpenDialog("assign")}
                          >
                            Assign Executive
                          </Button>
                          <Button
                            className="w-full bg-green-600 hover:bg-green-700"
                            onClick={() => setOpenDialog("approve")}
                          >
                            Approve Directly
                          </Button>
                          <Button
                            className="w-full bg-red-600 hover:bg-red-700"
                            onClick={() => setOpenDialog("reject")}
                          >
                            Reject
                          </Button>
                          <Button
                            className="w-full bg-amber-600 hover:bg-amber-700"
                            onClick={() => setOpenDialog("reupload")}
                          >
                            Request Reupload
                          </Button>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </div>
              )}
            </TabsContent>

            {/* Finalized applications for reference */}
            <TabsContent value="finalized" className="space-y-4">
              {!selectedApplication ? (
                renderApplicationTable(mockFinalizedApplications)
              ) : (
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <h2 className="text-xl font-bold">
                      {selectedApplication.applicantName} -{" "}
                      {selectedApplication.id}
                    </h2>
                    <Button
                      variant="outline"
                      onClick={() => setSelectedApplication(null)}
                    >
                      Back to List
                    </Button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card className="col-span-2">
                      <CardHeader>
                        <CardTitle>Submitted Documents</CardTitle>
                      </CardHeader>
                      <CardContent>
                        {viewingDocument ? (
                          <DocumentViewer
                            document={viewingDocument}
                            onClose={() => setViewingDocument(null)}
                          />
                        ) : (
                          <div className="space-y-2">
                            {selectedApplication.documents.map((doc) => (
                              <DocumentItem
                                key={doc.id}
                                document={doc}
                                onAction={handleDocumentAction}
                              />
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    <div className="space-y-6">
                      <Card>
                        <CardHeader>
                          <CardTitle>Application Details</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <dl className="grid grid-cols-1 gap-2 text-sm">
                            <div className="flex justify-between">
                              <dt className="font-medium">Application Type:</dt>
                              <dd>{selectedApplication.applicationType}</dd>
                            </div>
                            <div className="flex justify-between">
                              <dt className="font-medium">Submission Date:</dt>
                              <dd>
                                {format(
                                  selectedApplication.submissionDate,
                                  "MMM dd, yyyy"
                                )}
                              </dd>
                            </div>
                            <div className="flex justify-between">
                              <dt className="font-medium">
                                Final Review Date:
                              </dt>
                              <dd>
                                {selectedApplication.finalReviewDate
                                  ? format(
                                      new Date(
                                        selectedApplication.finalReviewDate
                                      ),
                                      "MMM dd, yyyy"
                                    )
                                  : "Pending"}
                              </dd>
                            </div>
                            <div className="flex justify-between">
                              <dt className="font-medium">Executive Review:</dt>
                              <dd>{selectedApplication.reviewedByExecutive}</dd>
                            </div>
                            <div className="flex justify-between">
                              <dt className="font-medium">Admin Review:</dt>
                              <dd>{selectedApplication.reviewedByAdmin}</dd>
                            </div>
                            <div className="flex justify-between">
                              <dt className="font-medium">Status:</dt>
                              <dd>
                                <StatusBadge
                                  status={selectedApplication.status}
                                />
                              </dd>
                            </div>
                          </dl>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle>Document History</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <DocumentHistory
                            history={selectedApplication.history}
                          />
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Approval Dialog */}
      <Dialog
        open={openDialog === "approve"}
        onOpenChange={(open) => !open && setOpenDialog("")}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Approve Application</DialogTitle>
            <DialogDescription>
              Are you sure you want to approve this application? This will
              finalize the KYC process and start account activation.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpenDialog("")}>
              Cancel
            </Button>
            <Button
              className="bg-green-600 hover:bg-green-700"
              onClick={handleApprove}
            >
              Confirm Approval
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Rejection Dialog */}
      <Dialog
        open={openDialog === "reject"}
        onOpenChange={(open) => !open && setOpenDialog("")}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Application</DialogTitle>
            <DialogDescription>
              Please provide a reason for rejecting this application.
            </DialogDescription>
          </DialogHeader>
          <Form {...rejectForm}>
            <form
              onSubmit={rejectForm.handleSubmit(handleReject)}
              className="space-y-4"
            >
              <FormField
                control={rejectForm.control}
                name="reason"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reason for Rejection</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Enter detailed reason for rejection"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button
                  variant="outline"
                  type="button"
                  onClick={() => setOpenDialog("")}
                >
                  Cancel
                </Button>
                <Button className="bg-red-600 hover:bg-red-700" type="submit">
                  Confirm Rejection
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Request Reupload Dialog */}
      <Dialog
        open={openDialog === "reupload"}
        onOpenChange={(open) => !open && setOpenDialog("")}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Request Document Reupload</DialogTitle>
            <DialogDescription>
              Select the documents you want to request for reupload and provide
              a reason.
            </DialogDescription>
          </DialogHeader>
          <Form {...requestReuploadForm}>
            <form
              onSubmit={requestReuploadForm.handleSubmit(handleRequestReupload)}
              className="space-y-4"
            >
              <FormField
                control={requestReuploadForm.control}
                name="documentIds"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Documents to Reupload</FormLabel>
                    <div className="space-y-2">
                      {selectedApplication?.documents.map((doc) => (
                        <div
                          key={doc.id}
                          className="flex items-center space-x-2"
                        >
                          <Checkbox
                            id={`doc-${doc.id}`}
                            checked={field.value?.includes(doc.id)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                field.onChange([...field.value, doc.id]);
                              } else {
                                field.onChange(
                                  field.value?.filter((id) => id !== doc.id)
                                );
                              }
                            }}
                          />
                          <label htmlFor={`doc-${doc.id}`} className="text-sm">
                            {doc.name}
                          </label>
                        </div>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={requestReuploadForm.control}
                name="reason"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reason for Reupload</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Enter detailed reason for reupload request"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button
                  variant="outline"
                  type="button"
                  onClick={() => setOpenDialog("")}
                >
                  Cancel
                </Button>
                <Button
                  className="bg-amber-600 hover:bg-amber-700"
                  type="submit"
                >
                  Send Request
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Assign Executive Dialog */}
      <Dialog
        open={openDialog === "assign"}
        onOpenChange={(open) => !open && setOpenDialog("")}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assign Executive for Review</DialogTitle>
            <DialogDescription>
              Select an executive to handle this KYC application review.
            </DialogDescription>
          </DialogHeader>
          <Form {...assignExecutiveForm}>
            <form
              onSubmit={assignExecutiveForm.handleSubmit(handleAssignExecutive)}
              className="space-y-4"
            >
              <FormField
                control={assignExecutiveForm.control}
                name="executiveId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Select Executive</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select an executive" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {mockExecutives.map((executive) => (
                          <SelectItem key={executive.id} value={executive.id}>
                            {executive.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={assignExecutiveForm.control}
                name="note"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Assignment Note (optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Add any notes for the executive"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button
                  variant="outline"
                  type="button"
                  onClick={() => setOpenDialog("")}
                >
                  Cancel
                </Button>
                <Button type="submit">Assign Executive</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default KYCAdminReview;
