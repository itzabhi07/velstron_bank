'use client';

import { useState } from 'react';
import { DashboardSidebar } from '@/components/dashboard/dashboard-sidebar';
import { DashboardHeader } from '@/components/dashboard/dashboard-header';

export default function AdminDashboardLayout({ children }) {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  return (
    <div className="flex min-h-screen bg-background">
      <DashboardSidebar
        userRole="admin"
        collapsed={isSidebarCollapsed}
        onCollapseToggle={toggleSidebar}
      />
      <div
        className={`flex flex-col flex-1 transition-all duration-300 ${
          isSidebarCollapsed ? 'ml-16' : 'ml-64'
        }`}
      >
        <DashboardHeader userRole="admin" isSidebarCollapsed={isSidebarCollapsed} />
        <main className="flex-1 p-4 md:p-6">{children}</main>
      </div>
    </div>
  );
}