"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { CreditCard, Search, Download, AlertTriangle } from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
} from "recharts";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { format } from "date-fns";

const primaryColor = "#ffdd00";
const secondaryColor = "#0d62a6";

const transactionTypes = ["Deposits", "Withdrawals", "Swipes"];
const currencies = ["USD", "EUR", "GBP", "BDT"];
const countries = ["USA", "UK", "Bangladesh", "Germany"];

export default function FundFlowsSection() {
  const [fundFlowData, setFundFlowData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState({
    dateRange: null,
    user: "",
    country: "",
    currency: "",
    transactionType: "",
  });
  const [totalTransactions, setTotalTransactions] = useState(0);
  const [showFilter, setShowFilter] = useState(false);

  const fetchFundFlowData = async (filters = {}) => {
    setLoading(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000));

      const { dateRange, user, country, currency, transactionType } = filters;
      const startDate = dateRange?.start
        ? new Date(dateRange.start).getTime()
        : null;
      const endDate = dateRange?.end ? new Date(dateRange.end).getTime() : null;

      const mockTransactions = Array.from({ length: 100 }, (_, i) => {
        const type =
          transactionTypes[Math.floor(Math.random() * transactionTypes.length)];
        const amount =
          (type === "Deposits" ? 1 : -1) * Math.floor(Math.random() * 10000);
        const transactionDate = new Date(
          Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000
        );
        return {
          id: `TXN-${Date.now()}-${i}`,
          date: transactionDate.toISOString().split("T")[0],
          user: `User-${Math.floor(Math.random() * 50)}`,
          country: countries[Math.floor(Math.random() * countries.length)],
          currency: currencies[Math.floor(Math.random() * currencies.length)],
          type,
          amount,
          isSuspicious: Math.random() < 0.05, // 5% chance of being suspicious
        };
      })
        .filter((transaction) => {
          if (startDate && new Date(transaction.date).getTime() < startDate)
            return false;
          if (endDate && new Date(transaction.date).getTime() > endDate)
            return false;
          if (
            user &&
            !transaction.user.toLowerCase().includes(user.toLowerCase())
          )
            return false;
          if (country && transaction.country !== country) return false;
          if (currency && transaction.currency !== currency) return false;
          if (transactionType && transaction.type !== transactionType)
            return false;
          return true;
        })
        .sort((a, b) => new Date(b.date) - new Date(a.date));

      setTotalTransactions(mockTransactions.length);
      setFundFlowData(mockTransactions);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching fund flow data:", error);
      setError("Failed to fetch fund flow data.");
      setLoading(false);
    }
  };

  const exportToExcel = (data) => {
    import("xlsx").then((xlsx) => {
      const worksheet = xlsx.utils.json_to_sheet(data);
      const workbook = xlsx.utils.book_new();
      xlsx.utils.book_append_sheet(workbook, worksheet, "Fund Flows");
      xlsx.writeFile(workbook, "fund_flows.xlsx");
    });
  };

  const exportToPDF = (data) => {
    import("jspdf").then((jsPDFModule) => {
      import("jspdf-autotable").then((autoTableModule) => {
        const doc = new jsPDFModule.default();

        if (autoTableModule && typeof autoTableModule.default === "function") {
          autoTableModule.default(doc, {
            head: [
              [
                "Date",
                "User",
                "Country",
                "Currency",
                "Type",
                "Amount",
                "Suspicious",
              ],
            ],
            body: data.map((flow) => [
              flow.date,
              flow.user,
              flow.country,
              flow.currency,
              flow.type,
              flow.amount,
              flow.isSuspicious ? "Yes" : "No",
            ]),
          });
        } else if (typeof doc.autoTable === "function") {
          doc.autoTable({
            head: [
              [
                "Date",
                "User",
                "Country",
                "Currency",
                "Type",
                "Amount",
                "Suspicious",
              ],
            ],
            body: data.map((flow) => [
              flow.date,
              flow.user,
              flow.country,
              flow.currency,
              flow.type,
              flow.amount,
              flow.isSuspicious ? "Yes" : "No",
            ]),
          });
        } else {
          console.error("jspdf-autotable plugin was not correctly loaded.");
          return;
        }

        doc.save("fund_flows.pdf");
      });
    });
  };

  useEffect(() => {
    fetchFundFlowData();
  }, []);

  const handleFilterChange = (name, value) => {
    setFilters((prevFilters) => ({
      ...prevFilters,
      [name]: value,
    }));
  };

  const handleDateChange = (dates) => {
    const [start, end] = dates;
    handleFilterChange("dateRange", { start, end });
  };

  const applyFilters = () => {
    fetchFundFlowData(filters);
    setShowFilter(false);
  };

  const clearFilters = () => {
    setFilters({
      dateRange: null,
      user: "",
      country: "",
      currency: "",
      transactionType: "",
    });
    fetchFundFlowData();
    setShowFilter(false);
  };

  const formatAmount = (value) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      notation: "compact",
      compactDisplay: "short",
    }).format(value);
  };

  const groupedFundFlowData = fundFlowData.reduce((acc, curr) => {
    const date = curr.date;
    if (!acc[date]) {
      acc[date] = { date };
    }
    acc[date][curr.type.toLowerCase()] =
      (acc[date][curr.type.toLowerCase()] || 0) + curr.amount;
    return acc;
  }, {});

  const chartData = Object.values(groupedFundFlowData).sort(
    (a, b) => new Date(a.date) - new Date(b.date)
  );

  if (loading) {
    return (
      <div className="p-6 rounded-lg border bg-white shadow animate-pulse">
        Loading Fund Flow Data...
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 rounded-lg border bg-white shadow text-red-500">
        Error: {error}
      </div>
    );
  }

  return (
    <div className="rounded-lg border bg-white shadow p-6 animate-fade-in">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-gray-800">Fund Flows</h2>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setShowFilter(!showFilter)}
            className="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
          >
            <Search className="h-4 w-4 mr-1 text-gray-500" />
            <span>Filter</span>
          </button>
          <button
            onClick={() => exportToExcel(fundFlowData)}
            className="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
          >
            <Download className="h-4 w-4 mr-1 text-gray-500" />
            <span>Export Excel</span>
          </button>
          <button
            onClick={() => exportToPDF(fundFlowData)}
            className="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
          >
            <Download className="h-4 w-4 mr-1 text-gray-500" />
            <span>Export PDF</span>
          </button>
        </div>
      </div>

      {showFilter && (
        <div className="mb-4 p-4 rounded-md border bg-gray-50">
          <h3 className="text-lg font-semibold text-gray-700 mb-2">
            Filter Transactions
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label
                htmlFor="dateRange"
                className="block text-sm font-medium text-gray-700"
              >
                Date Range:
              </label>
              <DatePicker
                selectsRange
                startDate={
                  filters.dateRange?.start
                    ? new Date(filters.dateRange.start)
                    : null
                }
                endDate={
                  filters.dateRange?.end
                    ? new Date(filters.dateRange.end)
                    : null
                }
                onChange={handleDateChange}
                className="shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md"
              />
            </div>
            <div>
              <label
                htmlFor="user"
                className="block text-sm font-medium text-gray-700"
              >
                User:
              </label>
              <input
                type="text"
                id="user"
                className="shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md"
                value={filters.user}
                onChange={(e) => handleFilterChange("user", e.target.value)}
              />
            </div>
            <div>
              <label
                htmlFor="country"
                className="block text-sm font-medium text-gray-700"
              >
                Country:
              </label>
              <select
                id="country"
                className="shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md"
                value={filters.country}
                onChange={(e) => handleFilterChange("country", e.target.value)}
              >
                <option value="">All Countries</option>
                {countries.map((country) => (
                  <option key={country} value={country}>
                    {country}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label
                htmlFor="currency"
                className="block text-sm font-medium text-gray-700"
              >
                Currency:
              </label>
              <select
                id="currency"
                className="shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md"
                value={filters.currency}
                onChange={(e) => handleFilterChange("currency", e.target.value)}
              >
                <option value="">All Currencies</option>
                {currencies.map((currency) => (
                  <option key={currency} value={currency}>
                    {currency}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label
                htmlFor="transactionType"
                className="block text-sm font-medium text-gray-700"
              >
                Transaction Type:
              </label>
              <select
                id="transactionType"
                className="shadow-sm focus:ring-primary focus:border-primary block w-full sm:text-sm border-gray-300 rounded-md"
                value={filters.transactionType}
                onChange={(e) =>
                  handleFilterChange("transactionType", e.target.value)
                }
              >
                <option value="">All Types</option>
                {transactionTypes.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex justify-end col-span-full">
              <button
                onClick={applyFilters}
                className="inline-flex items-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-indigo-600"
              >
                Apply Filters
              </button>
              <button
                onClick={clearFilters}
                className="ml-2 inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
              >
                Clear Filters
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="mb-4">
        <h3 className="text-lg font-semibold text-gray-700">
          Transaction Overview
        </h3>
        <p className="text-sm text-gray-500">
          Total Transactions: {totalTransactions}
        </p>
      </div>

      <div className="h-[400px]">
        {chartData.length > 0 ? (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={chartData}
              margin={{ top: 10, right: 30, left: 20, bottom: 50 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" tick={{ fontSize: 12 }} />
              <YAxis tickFormatter={formatAmount} tick={{ fontSize: 12 }} />
              <Tooltip formatter={(value) => [formatAmount(value), "Amount"]} />
              <Legend wrapperStyle={{ bottom: 0 }} />
              <Line
                type="monotone"
                dataKey="deposits"
                name="Deposits"
                stroke={primaryColor}
                strokeWidth={2}
                dot={false}
              />
              <Line
                type="monotone"
                dataKey="withdrawals"
                name="Withdrawals"
                stroke={secondaryColor}
                strokeWidth={2}
                dot={false}
              />
              <Line
                type="monotone"
                dataKey="swipes"
                name="Swipes"
                stroke="#00aaff"
                strokeWidth={2}
                dot={false}
              />
              <CartesianGrid stroke="#ccc" strokeDasharray="5 5" />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <p className="text-gray-600">
            No fund flow data available for the current filters.
          </p>
        )}
      </div>

      <div className="mt-6">
        <h3 className="text-lg font-semibold text-gray-700">
          All Transactions
        </h3>
        <div className="overflow-x-auto">
          <table className="min-w-full leading-normal shadow-md rounded-lg bg-white">
            <thead>
              <tr>
                <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                  Date
                </th>
                <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                  User
                </th>
                <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                  Country
                </th>
                <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                  Currency
                </th>
                <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-right text-xs font-semibold text-gray-700 uppercase tracking-wider">
                  Amount
                </th>
                <th className="px-5 py-3 border-b-2 border-gray-200 bg-gray-100 text-center text-xs font-semibold text-gray-700 uppercase tracking-wider">
                  Suspicious
                </th>
              </tr>
            </thead>
            <tbody>
              {fundFlowData.map((flow) => (
                <tr
                  key={flow.id}
                  className="hover:bg-gray-50 transition-colors"
                >
                  <td className="px-5 py-3 border-b border-gray-200 text-sm">
                    {flow.date}
                  </td>
                  <td className="px-5 py-3 border-b border-gray-200 text-sm">
                    {flow.user}
                  </td>
                  <td className="px-5 py-3 border-b border-gray-200 text-sm">
                    {flow.country}
                  </td>
                  <td className="px-5 py-3 border-b border-gray-200 text-sm">
                    {flow.currency}
                  </td>
                  <td className="px-5 py-3 border-b border-gray-200 text-sm">
                    {flow.type}
                  </td>
                  <td className="px-5 py-3 border-b border-gray-200 text-sm text-right font-medium">
                    {formatAmount(flow.amount)}
                  </td>
                  <td className="px-5 py-3 border-b border-gray-200 text-sm text-center">
                    {flow.isSuspicious && (
                      <AlertTriangle
                        className="h-4 w-4 text-red-500 inline-block"
                        title="Suspicious Transaction"
                      />
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
