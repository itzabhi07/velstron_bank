"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import {
  Users,
  FileCheck,
  Clock,
  ArrowUpRight,
  ChevronRight,
  CreditCard,
  Search,
  AlertTriangle,
  User,
  Download,
  BarChart3,
  Database,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
} from "recharts";

const primaryColor = "#ffdd00";
const secondaryColor = "#0d62a6";

export default function AdminDashboard() {
  const [searchValue, setSearchValue] = useState("");
  const [dashboardData, setDashboardData] = useState({
    totalUsers: "",
    newUsersThisMonth: "",
    totalExecutives: "",
    newExecutivesThisMonth: "",
    pendingApprovalsCount: "",
    newApprovalsToday: "",
    totalFunds: "",
    fundFlowData: [],
    userGrowthData: [],
    pendingApprovalsData: [],
    systemAlertsData: [],
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const formatCurrency = (value) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      notation: "compact",
      compactDisplay: "short",
    }).format(value);
  };

  useEffect(() => {
    // Simulate fetching data (We have to replace it with the actual API call)
    const initialData = {
      totalUsers: "",
      newUsersThisMonth: "",
      totalExecutives: "",
      newExecutivesThisMonth: "",
      pendingApprovalsCount: "",
      newApprovalsToday: "",
      totalFunds: "",
      fundFlowData: [],
      userGrowthData: [],
      pendingApprovalsData: [],
      systemAlertsData: [],
    };

    setDashboardData(initialData);
    setLoading(false); // No actual loading since there's no API call
  }, []);

  if (loading) {
    return <div>Loading dashboard data...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  const filteredApprovals = dashboardData.pendingApprovalsData.filter(
    (approval) =>
      approval?.name?.toLowerCase().includes(searchValue.toLowerCase()) ||
      approval?.id?.toLowerCase().includes(searchValue.toLowerCase()) ||
      approval?.type?.toLowerCase().includes(searchValue.toLowerCase())
  );

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-semibold mb-6 text-gray-800">
        Admin Dashboard
      </h1>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-lg border bg-white shadow animate-fade-in">
          <div className="p-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-700">
                Total Users
              </h3>
              <div
                className="flex h-8 w-8 items-center justify-center rounded-full"
                style={{ backgroundColor: `${primaryColor}1a` }}
              >
                <Users className="h-4 w-4" style={{ color: primaryColor }} />
              </div>
            </div>
            <div className="mt-4">
              <p className="text-3xl font-bold text-gray-800">
                {dashboardData.totalUsers}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                <span className="text-green-500 font-medium">
                  ↑ {dashboardData.newUsersThisMonth}
                </span>{" "}
                this month
              </p>
            </div>
            <div className="mt-4">
              <Link
                href="/dashboard/admin/users"
                className="inline-flex items-center text-sm font-medium"
                style={{ color: primaryColor }}
              >
                View Users <ChevronRight className="h-3 w-3 ml-1" />
              </Link>
            </div>
          </div>
        </div>

        <div
          className="rounded-lg border bg-white shadow animate-fade-in"
          style={{ animationDelay: "0.1s" }}
        >
          <div className="p-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-700">
                Executives
              </h3>
              <div
                className="flex h-8 w-8 items-center justify-center rounded-full"
                style={{ backgroundColor: `${primaryColor}1a` }}
              >
                <User className="h-4 w-4" style={{ color: primaryColor }} />
              </div>
            </div>
            <div className="mt-4">
              <p className="text-3xl font-bold text-gray-800">
                {dashboardData.totalExecutives}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                <span className="text-green-500 font-medium">
                  ↑ {dashboardData.newExecutivesThisMonth}
                </span>{" "}
                this month
              </p>
            </div>
            <div className="mt-4">
              <Link
                href="/dashboard/admin/executives"
                className="inline-flex items-center text-sm font-medium"
                style={{ color: primaryColor }}
              >
                View Executives <ChevronRight className="h-3 w-3 ml-1" />
              </Link>
            </div>
          </div>
        </div>

        <div
          className="rounded-lg border bg-white shadow animate-fade-in"
          style={{ animationDelay: "0.2s" }}
        >
          <div className="p-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-700">
                Pending Approvals
              </h3>
              <div
                className="flex h-8 w-8 items-center justify-center rounded-full"
                style={{ backgroundColor: "#ffcc001a" }}
              >
                <Clock className="h-4 w-4" style={{ color: "#ffcc00" }} />
              </div>
            </div>
            <div className="mt-4">
              <p className="text-3xl font-bold text-gray-800">
                {dashboardData.pendingApprovalsCount}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                <span className="text-red-500 font-medium">
                  ↑ {dashboardData.newApprovalsToday}
                </span>{" "}
                today
              </p>
            </div>
            <div className="mt-4">
              <Link
                href="/dashboard/admin/approvals"
                className="inline-flex items-center text-sm font-medium"
                style={{ color: primaryColor }}
              >
                View Approvals <ChevronRight className="h-3 w-3 ml-1" />
              </Link>
            </div>
          </div>
        </div>

        <div
          className="rounded-lg border bg-white shadow animate-fade-in"
          style={{ animationDelay: "0.3s" }}
        >
          <div className="p-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-700">
                Total Funds
              </h3>
              <div
                className="flex h-8 w-8 items-center justify-center rounded-full"
                style={{ backgroundColor: "#00aa001a" }}
              >
                <Database className="h-4 w-4" style={{ color: "#00aa00" }} />
              </div>
            </div>
            <div className="mt-4">
              <p className="text-3xl font-bold text-gray-800">
                {dashboardData.totalFunds}
              </p>
              {/* we need API endpoint for fund change percentage */}
              {/* <p className="text-xs text-gray-500 mt-1">
                <span className="text-green-500 font-medium">↑ 5%</span> from last month
              </p> */}
            </div>
            <div className="mt-4">
              <Link
                href="/dashboard/admin/funds"
                className="inline-flex items-center text-sm font-medium"
                style={{ color: primaryColor }}
              >
                View Fund Details <ChevronRight className="h-3 w-3 ml-1" />
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 mt-6">
        <div
          className="rounded-lg border bg-white shadow animate-fade-in"
          style={{ animationDelay: "0.4s" }}
        >
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-700">Fund Flow</h3>
              <div className="flex items-center space-x-2">
                <button className="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary">
                  <Download className="h-3 w-3 mr-1 text-gray-500" />
                  <span>Export</span>
                </button>
              </div>
            </div>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={dashboardData.fundFlowData}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" stroke="#6b7280" />
                  <YAxis
                    tickFormatter={(value) => formatCurrency(value)}
                    stroke="#6b7280"
                  />
                  <Tooltip formatter={(value) => [formatCurrency(value), ""]} />
                  <Legend wrapperStyle={{ top: -10 }} />
                  <Bar dataKey="deposits" name="Deposits" fill={primaryColor} />
                  <Bar
                    dataKey="withdrawals"
                    name="Withdrawals"
                    fill={secondaryColor}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div
          className="rounded-lg border bg-white shadow animate-fade-in"
          style={{ animationDelay: "0.5s" }}
        >
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-700">
                User Growth
              </h3>
              <div className="flex items-center space-x-2">
                <button className="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary">
                  <Download className="h-3 w-3 mr-1 text-gray-500" />
                  <span>Export</span>
                </button>
              </div>
            </div>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={dashboardData.userGrowthData}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" stroke="#6b7280" />
                  <YAxis stroke="#6b7280" />
                  <Tooltip />
                  <Legend wrapperStyle={{ top: -10 }} />
                  <Line
                    type="monotone"
                    dataKey="users"
                    name="Clients"
                    stroke={primaryColor}
                    activeDot={{ r: 8 }}
                    strokeWidth={2}
                  />
                  <Line
                    type="monotone"
                    dataKey="executives"
                    name="Executives"
                    stroke={secondaryColor}
                    strokeWidth={2}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3 mt-6">
        <div
          className="md:col-span-2 rounded-lg border bg-white shadow animate-fade-in"
          style={{ animationDelay: "0.6s" }}
        >
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-700">
                Pending Admin Approvals
              </h3>
              <div className="relative">
                <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
                <input
                  type="search"
                  placeholder="Search..."
                  className="rounded-md border border-gray-300 bg-white pl-8 pr-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-primary w-full"
                  value={searchValue}
                  onChange={(e) => setSearchValue(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              {dashboardData.pendingApprovalsData.map((item) => (
                <div
                  key={item?.id}
                  className="flex items-center justify-between p-4 rounded-md border hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center space-x-4">
                    <div
                      className="flex h-10 w-10 items-center justify-center rounded-full"
                      style={{
                        backgroundColor: `${primaryColor}1a`,
                        color: primaryColor,
                        fontWeight: "bold",
                      }}
                    >
                      {item?.name?.charAt(0)?.toUpperCase()}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-800">
                        {item?.name}
                      </p>
                      <p className="text-xs text-gray-500">
                        {item?.id} • {item?.type}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-8">
                    <div className="text-right hidden md:block">
                      <p className="text-xs text-gray-500">
                        Executive Approved
                      </p>
                      <p className="text-sm text-gray-700">
                        {item?.executiveApproved}
                      </p>
                    </div>
                    <div className="text-right hidden md:block">
                      <p className="text-xs text-gray-500">Date</p>
                      <p className="text-sm text-gray-700">
                        {item?.dateApproved}
                      </p>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Link
                        href={`/dashboard/admin/approvals/${item?.id}`}
                        className="inline-flex items-center rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-indigo-600"
                      >
                        Review
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 text-center">
              <Link
                href="/dashboard/admin/approvals"
                className="inline-flex items-center text-sm font-medium"
                style={{ color: primaryColor }}
              >
                View All Pending Approvals{" "}
                <ChevronRight className="h-4 w-4 ml-1" />
              </Link>
            </div>
          </div>
        </div>

        <div
          className="rounded-lg border bg-white shadow animate-fade-in"
          style={{ animationDelay: "0.7s" }}
        >
          <div className="p-6">
            <h3 className="text-lg font-semibold mb-4 text-gray-700">
              System Alerts
            </h3>

            <div className="space-y-2">
              {dashboardData.systemAlertsData.map((alert) => (
                <div
                  key={alert?.id}
                  className={`p-3 rounded-md border ${
                    alert?.severity === "high"
                      ? "bg-red-100 border-red-200"
                      : alert?.severity === "medium"
                      ? "bg-yellow-100 border-yellow-200"
                      : "bg-blue-100 border-blue-200"
                  }`}
                >
                  <div className="flex items-start space-x-2">
                    <AlertTriangle
                      className={`h-5 w-5 flex-shrink-0 ${
                        alert?.severity === "high"
                          ? "text-red-500"
                          : alert?.severity === "medium"
                          ? "text-yellow-500"
                          : "text-blue-500"
                      }`}
                    />
                    <div>
                      <h4 className="text-sm font-medium text-gray-800">
                        {alert?.type}
                      </h4>
                      <p className="text-xs text-gray-500 mt-1">
                        {alert?.description}
                      </p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs text-gray-700">
                          {alert?.user}
                        </span>
                        <span className="text-xs text-gray-500">
                          {alert?.date}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 text-center">
              <Link
                href="/dashboard/admin/alerts"
                className="inline-flex items-center text-sm font-medium"
                style={{ color: primaryColor }}
              >
                View All Alerts <ChevronRight className="h-4 w-4 ml-1" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
