'use client';

import React, { useEffect, useState } from 'react';

export default function AdminDashboard() {
  // States for different API data
  const [users, setUsers] = useState([]);
  const [limits, setLimits] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch multiple API data
  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true);

        // Fetch users
        const usersRes = await fetch('/api/admin/users');
        if (!usersRes.ok) throw new Error('Failed to fetch users');
        const usersData = await usersRes.json();
        setUsers(usersData);

        // Fetch limits
        const limitsRes = await fetch('/api/admin/limits');
        if (!limitsRes.ok) throw new Error('Failed to fetch limits');
        const limitsData = await limitsRes.json();
        setLimits(limitsData);

        // Fetch alerts
        const alertsRes = await fetch('/api/admin/alerts');
        if (!alertsRes.ok) throw new Error('Failed to fetch alerts');
        const alertsData = await alertsRes.json();
        setAlerts(alertsData);

        setError(null);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, []);

  if (loading) return <p>Loading admin dashboard...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div className="p-4">
      <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-2">Users ({users.length})</h2>
        <ul className="list-disc list-inside max-h-48 overflow-auto border p-2 rounded">
          {users.map(user => (
            <li key={user._id}>
              {user.name} - {user.email}
            </li>
          ))}
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-2">Limits</h2>
        <ul className="list-disc list-inside max-h-32 overflow-auto border p-2 rounded">
          {limits.map(limit => (
            <li key={limit._id}>
              {limit.name}: {limit.value}
            </li>
          ))}
        </ul>
      </section>

      <section>
        <h2 className="text-xl font-semibold mb-2">Alerts ({alerts.length})</h2>
        <ul className="list-disc list-inside max-h-32 overflow-auto border p-2 rounded">
          {alerts.map(alert => (
            <li key={alert._id}>
              {alert.message} - Status: {alert.status}
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}