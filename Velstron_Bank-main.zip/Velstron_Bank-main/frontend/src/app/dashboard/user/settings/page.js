"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { toast } from "react-hot-toast";
import { LogOut } from "lucide-react";

export default function UserSettings() {
  const router = useRouter();
  const [isTwoFAEnabled, setIsTwoFAEnabled] = useState(false); // Replace with actual state management
  const [notificationPreferences, setNotificationPreferences] = useState({
    email: true,
    sms: false,
  });
  const [loading, setLoading] = useState(false);

  const handlePasswordReset = () => {
    setLoading(true);
    // In a real application, you would trigger a password reset email here
    setTimeout(() => {
      toast.success("Password reset link sent to your email (simulated)");
      setLoading(false);
    }, 1500);
  };

  const handleTwoFAToggle = (checked) => {
    setIsTwoFAEnabled(checked);
    // In a real application, you would update the user's 2FA setting in your backend
    toast.success(`2FA ${checked ? 'enabled' : 'disabled'} (simulated)`);
  };

  const handleNotificationPreferenceChange = (type, checked) => {
    setNotificationPreferences((prev) => ({ ...prev, [type]: checked }));
    toast.success(`Notification preference updated for ${type} (simulated)`);
    // In a real application, you would update these preferences in your backend
  };

  const handleLogout = () => {
    // In a real application, you would handle user logout (e.g., clearing session, cookies)
    toast.success("Logged out successfully (simulated)");
    router.push("/login"); // Redirect to the login page
  };

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-semibold mb-6 text-gray-800">User Settings</h1>

      <div className="mb-8 rounded-lg border bg-white shadow p-6 animate-fade-in">
        <h2 className="text-xl font-semibold mb-4 text-gray-700">Account Security</h2>
        <div className="mb-4 flex items-center justify-between">
          <Label htmlFor="twoFA">Two-Factor Authentication (2FA)</Label>
          <Switch id="twoFA" checked={isTwoFAEnabled} onCheckedChange={handleTwoFAToggle} />
        </div>
        <div>
          <Button onClick={handlePasswordReset} disabled={loading}>
            {loading ? "Sending Reset Link..." : "Reset Password"}
          </Button>
        </div>
      </div>

      <div className="mb-8 rounded-lg border bg-white shadow p-6 animate-fade-in">
        <h2 className="text-xl font-semibold mb-4 text-gray-700">Notification Preferences</h2>
        <div className="mb-2 flex items-center justify-between">
          <Label htmlFor="emailNotifications">Email Notifications</Label>
          <Switch
            id="emailNotifications"
            checked={notificationPreferences.email}
            onCheckedChange={(checked) => handleNotificationPreferenceChange("email", checked)}
          />
        </div>
        <div className="flex items-center justify-between">
          <Label htmlFor="smsNotifications">SMS Notifications</Label>
          <Switch
            id="smsNotifications"
            checked={notificationPreferences.sms}
            onCheckedChange={(checked) => handleNotificationPreferenceChange("sms", checked)}
          />
        </div>
        {/* Add more notification preferences here if needed */}
      </div>

      <div className="rounded-lg border bg-white shadow p-6 animate-fade-in">
        <h2 className="text-xl font-semibold mb-4 text-gray-700">Account Actions</h2>
        <Button variant="destructive" onClick={handleLogout} className="flex items-center">
          <LogOut className="mr-2 h-4 w-4" /> Logout
        </Button>
      </div>
    </div>
  );
}