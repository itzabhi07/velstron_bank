"use client";

import { useState, useEffect } from 'react';
import { ArrowUpRight } from 'lucide-react';
import { useRouter } from 'next/navigation';
import toast from 'react-hot-toast';

const API_CALL_DELAY = 1000;

const initialUser = {
    velstronId: 'VLS_U12345',
    name: 'Moon Sahu',
    accounts: {
        hot: { balance: 1250.75, number: 'XXXX-XXXX-XXXX-1234' },
        cold: { balance: 5890.20, number: 'XXXX-XXXX-XXXX-5678' },
    },
};

export default function DepositFundsPage() {
    const router = useRouter();
    const [depositAmount, setDepositAmount] = useState('');
    const [depositAccount, setDepositAccount] = useState('hot');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [submissionError, setSubmissionError] = useState(null);
    const [availableBalance, setAvailableBalance] = useState(initialUser.accounts.hot.balance); 

    useEffect(() => {
        setAvailableBalance(depositAccount === 'hot' ? initialUser.accounts.hot.balance : initialUser.accounts.cold.balance);
    }, [depositAccount]);

    const formatCurrency = (amount) => {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
        }).format(amount);
    };

    const showNotification = (message, type = 'success') => {
        if (type === 'success' && typeof toast.success === 'function') {
            toast.success(message);
        } else if (type === 'error' && typeof toast.error === 'function') {
            toast.error(message);
        } else {
            toast(message);
        }
    };

    const handleDepositRequest = async () => {
        const amount = parseFloat(depositAmount);

        if (isNaN(amount) || amount <= 0) {
            showNotification('Please enter a valid positive amount to deposit.', 'error');
            return;
        }

        setIsSubmitting(true);
        setSubmissionError(null);

        await new Promise(resolve => setTimeout(resolve, API_CALL_DELAY));

        try {
            const response = { ok: true, message: `Successfully requested deposit of ${formatCurrency(amount)} to ${depositAccount} account.` };

            if (response.ok) {
                showNotification(response.message, 'success');
                setDepositAmount(''); 
                router.push('/dashboard/user');
            } else {
                setSubmissionError(response.message || 'Failed to submit deposit request.');
                showNotification(submissionError, 'error');
            }
        } catch (error) {
            console.error('Deposit request failed:', error);
            setSubmissionError('An unexpected error occurred while submitting your request.');
            showNotification(submissionError, 'error');
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="container mx-auto p-6">
            <h1 className="text-2xl font-semibold text-gray-800 mb-6">Deposit Funds</h1>

            <div className="bg-white rounded-lg shadow-md p-6">
                <div className="mb-4">
                    <label htmlFor="depositAmount" className="block text-sm font-medium text-gray-700">
                        Amount to Deposit:
                    </label>
                    <div className="relative mt-1 rounded-md shadow-sm">
                        <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <span className="text-gray-500 sm:text-sm">$</span>
                        </div>
                        <input
                            type="number"
                            id="depositAmount"
                            className="block w-full rounded-md border-gray-300 pr-12 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm pl-7"
                            placeholder="0.00"
                            value={depositAmount}
                            onChange={(e) => setDepositAmount(e.target.value)}
                            aria-describedby="depositAmount-helper"
                        />
                        <div className="absolute inset-y-0 right-0 flex items-center">
                            <span className="text-gray-500 sm:text-sm pr-3">USD</span>
                        </div>
                    </div>
                    <p className="mt-1 text-sm text-gray-500" id="depositAmount-helper">
                        Enter the amount you wish to deposit.
                    </p>
                </div>

                <div className="mb-4">
                    <label htmlFor="depositAccount" className="block text-sm font-medium text-gray-700">
                        Deposit To Account:
                    </label>
                    <select
                        id="depositAccount"
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                        value={depositAccount}
                        onChange={(e) => setDepositAccount(e.target.value)}
                        aria-describedby="depositAccount-helper"
                    >
                        <option value="hot">Hot Account ({initialUser.accounts.hot.number})</option>
                        <option value="cold">Cold Account ({initialUser.accounts.cold.number})</option>
                    </select>
                    <p className="mt-1 text-sm text-gray-500" id="depositAccount-helper">
                        Select the account you want to deposit funds into.
                    </p>
                </div>

                <button
                    onClick={handleDepositRequest}
                    className="inline-flex items-center rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                    disabled={isSubmitting}
                >
                    <ArrowUpRight className="mr-2 h-4 w-4" /> {isSubmitting ? 'Submitting...' : 'Request Deposit'}
                </button>

                {submissionError && (
                    <div className="mt-4 text-red-500">
                        {submissionError}
                    </div>
                )}

                <div className="mt-4 text-sm text-gray-500">
                    <p>Please note that all deposit requests are subject to approval and processing times may vary.</p>
                </div>
            </div>
        </div>
    );
}