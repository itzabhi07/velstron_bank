"use client";

import { useState, useEffect } from 'react';
import { ArrowUpRight, ArrowDownLeft, ArrowLeftRight } from 'lucide-react';
import { useRouter } from 'next/navigation';
import toast from 'react-hot-toast';

const initialUser = {
    velstronId: 'VLS_U12345',
    name: 'Moon Sahu',
    accounts: {
        hot: { balance: 1250.75, number: 'XXXX-XXXX-XXXX-1234' },
        cold: { balance: 5890.20, number: 'XXXX-XXXX-XXXX-5678' },
    },
    fundAllocation: {
        hotPercentage: 15,
    },
    transactions: [
        { date: '2025-05-27', type: 'Swipe', amount: 100, direction: 'Cold to Hot', status: 'Completed' },
        { date: '2025-05-26', type: 'Deposit', amount: 500, direction: 'In', status: 'Approved' },
        { date: '2025-05-25', type: 'Withdrawal', amount: 200, direction: 'Out', status: 'Pending' },
    ],
};

export default function UserDashboard() {
    const router = useRouter();
    const [user, setUser] = useState(initialUser);
    const [transferAmount, setTransferAmount] = useState('');
    const [transferDirection, setTransferDirection] = useState('coldToHot');
    const [holdingPercentage, setHoldingPercentage] = useState(initialUser?.fundAllocation?.hotPercentage || 10);
    const [isSettingHoldingPercentage, setIsSettingHoldingPercentage] = useState(false);
    const [lastTransaction, setLastTransaction] = useState(null);

    useEffect(() => {
        if (user.transactions.length > 0) {
            setLastTransaction(user.transactions[0]);
        }
    }, [user]);

    const formatCurrency = (amount) => {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
        }).format(amount);
    };

    const showNotification = (message, type = 'success') => {
        if (type === 'success' && typeof toast.success === 'function') {
            toast.success(message);
        } else if (type === 'error' && typeof toast.error === 'function') {
            toast.error(message);
        } else if (type === 'warning' && typeof toast.warning === 'function') {
            toast.warning(message);
        } else if (typeof toast === 'function') {
            toast(message);
        } else {
            console.error('react-hot-toast methods (success, error, warning) are not available.');
        }
    };

    const handleFundTransfer = () => {
        const amount = parseFloat(transferAmount);
        if (isNaN(amount) || amount <= 0) {
            showNotification('Please enter a valid positive amount', 'error');
            return;
        }

        if (transferDirection === 'coldToHot') {
            const maxTransfer = user?.accounts?.cold?.balance * 0.20;
            const minTransfer = user?.accounts?.cold?.balance * 0.05;

            if (amount > maxTransfer || amount < minTransfer) {
                showNotification(`Transfer amount must be between ${formatCurrency(minTransfer)} and ${formatCurrency(maxTransfer)}`, 'warning');
                return;
            }
            setUser(prevUser => ({
                ...prevUser,
                accounts: {
                    hot: { ...prevUser.accounts.hot, balance: prevUser.accounts.hot.balance + amount },
                    cold: { ...prevUser.accounts.cold, balance: prevUser.accounts.cold.balance - amount },
                },
                transactions: [{ date: new Date().toISOString().slice(0, 10), type: 'Swipe', amount, direction: 'Cold to Hot', status: 'Completed' }, ...prevUser.transactions],
            }));
            showNotification(`Transferred ${formatCurrency(amount)} from Cold to Hot`, 'success');
        } else if (transferDirection === 'hotToCold') {
            if (amount > user?.accounts?.hot?.balance) {
                showNotification('Insufficient balance in Hot Account', 'error');
                return;
            }
            setUser(prevUser => ({
                ...prevUser,
                accounts: {
                    hot: { ...prevUser.accounts.hot, balance: prevUser.accounts.hot.balance - amount },
                    cold: { ...prevUser.accounts.cold, balance: prevUser.accounts.cold.balance + amount },
                },
                transactions: [{ date: new Date().toISOString().slice(0, 10), type: 'Swipe', amount, direction: 'Hot to Cold', status: 'Completed' }, ...prevUser.transactions],
            }));
            showNotification(`Transferred ${formatCurrency(amount)} from Hot to Cold`, 'success');
        }
        setTransferAmount('');
    };

    const handleSetHoldingPercentage = () => {
        const percentage = parseInt(holdingPercentage, 10);
        if (isNaN(percentage) || percentage < 5 || percentage > 20) {
            showNotification('Holding percentage must be between 5% and 20%', 'error');
            return;
        }

        setIsSettingHoldingPercentage(true);
        setUser(prevUser => ({
            ...prevUser,
            fundAllocation: { ...prevUser.fundAllocation, hotPercentage: percentage },
        }));
        showNotification(`Hot account holding percentage set to ${percentage}%`, 'success');
        setIsSettingHoldingPercentage(false);
    };

    const handleDepositClick = () => {
        router.push('/dashboard/user/deposit');
    };

    const handleWithdrawalClick = () => {
        router.push('/dashboard/user/withdraw');
    };

    return (
        <div className="container mx-auto p-6">
            <div className="mb-6">
                <h1 className="text-3xl font-semibold text-gray-800">Welcome, {user?.name}!</h1>
                <p className="text-gray-500">Velstron ID: {user?.velstronId}</p>
            </div>

            <div className="mb-8 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-yellow-500">
                    <h2 className="text-lg font-semibold text-gray-700 mb-2">Hot Account</h2>
                    <p className="text-xl font-bold text-gray-800">{formatCurrency(user?.accounts?.hot?.balance)}</p>
                    <p className="text-sm text-gray-500">Account: {user?.accounts?.hot?.number}</p>
                </div>
                <div className="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-500">
                    <h2 className="text-lg font-semibold text-gray-700 mb-2">Cold Account</h2>
                    <p className="text-xl font-bold text-gray-800">{formatCurrency(user?.accounts?.cold?.balance)}</p>
                    <p className="text-sm text-gray-500">Account: {user?.accounts?.cold?.number}</p>
                </div>
            </div>

            <div className="mb-8 bg-white rounded-lg shadow-md p-6 border-l-4 border-purple-500">
                <h2 className="text-xl font-semibold text-gray-700 mb-4">Quick Stats</h2>
                <div className="grid grid-cols-1 md:grid-cols-1 gap-4">
                    <div>
                        <h3 className="text-md font-semibold text-gray-600 mb-1">Last Transaction</h3>
                        {lastTransaction ? (
                            <p className="text-gray-800">
                                {lastTransaction.type} ({lastTransaction.direction}): {formatCurrency(lastTransaction.amount)} on {lastTransaction.date}
                            </p>
                        ) : (
                            <p className="text-gray-500">No recent transactions</p>
                        )}
                    </div>
                </div>
            </div>

            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
                <h2 className="text-xl font-semibold text-gray-700 mb-4">Fund Swipe</h2>
                <div className="flex items-center space-x-4">
                    <div className="flex-1">
                        <label htmlFor="transferAmount" className="block text-sm font-medium text-gray-700">Amount:</label>
                        <input
                            type="number"
                            id="transferAmount"
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                            value={transferAmount}
                            onChange={(e) => setTransferAmount(e.target.value)}
                        />
                    </div>
                    <div className="flex-1">
                        <label htmlFor="transferDirection" className="block text-sm font-medium text-gray-700">Direction:</label>
                        <select
                            id="transferDirection"
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                            value={transferDirection}
                            onChange={(e) => setTransferDirection(e.target.value)}
                        >
                            <option value="coldToHot">Cold to Hot (5%-20%)</option>
                            <option value="hotToCold">Hot to Cold</option>
                        </select>
                    </div>
                    <button
                        onClick={handleFundTransfer}
                        className="inline-flex items-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                    >
                        Transfer <ArrowLeftRight className="ml-2 h-4 w-4" />
                    </button>
                </div>
            </div>

            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
                <h2 className="text-xl font-semibold text-gray-700 mb-4">Fund Holding Control</h2>
                <div className="flex items-center space-x-4">
                    <div className="flex-1">
                        <label htmlFor="holdingPercentage" className="block text-sm font-medium text-gray-700">
                            Hot Account Holding (%): (5% - 20%)
                        </label>
                        <input
                            type="number"
                            id="holdingPercentage"
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                            value={holdingPercentage}
                            onChange={(e) => setHoldingPercentage(parseInt(e.target.value))}
                            min="5"
                            max="20"
                        />
                    </div>
                    <button
                        onClick={handleSetHoldingPercentage}
                        className="inline-flex items-center rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
                    >
                        Set Holding %
                    </button>
                </div>
                {isSettingHoldingPercentage && (
                    <p className="mt-2 text-sm text-gray-500">Setting holding percentage...</p>
                )}
            </div>

            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
                <h2 className="text-xl font-semibold text-gray-700 mb-4">Transaction Requests</h2>
                <div className="flex space-x-4">
                    <button
                        onClick={handleDepositClick}
                        className="inline-flex items-center rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                    >
                        <ArrowUpRight className="mr-2 h-4 w-4" /> Deposit Funds
                    </button>
                    <button
                        onClick={handleWithdrawalClick}
                        className="inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                    >
                        <ArrowDownLeft className="mr-2 h-4 w-4" /> Withdrawal Request
                    </button>
                </div>
            </div>

            <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold text-gray-700 mb-4">Account Details</h2>
                <p className="text-gray-600 mb-2">
                    <span className="font-semibold">VELSTRON ID:</span> {user?.velstronId}
                </p>
                <p className="text-gray-600 mb-2">
                    <span className="font-semibold">Hot Account Number:</span> {user?.accounts?.hot?.number}
                </p>
                <p className="text-gray-600">
                    <span className="font-semibold">Cold Account Number:</span> {user?.accounts?.cold?.number}
                </p>
            </div>
        </div>
    );
}