"use client";
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import {
  ArrowRightLeft,
  DollarSign,
  Snowflake,
  Flame,
  Settings,
  TrendingUp,
  TrendingDown,
  Lock,
  Unlock,
} from "lucide-react";
import { toast } from "sonner";

const FundManagement = () => {
  const [activeTab, setActiveTab] = useState("swipe");

  // Account balances
  const [hotAccountBalance] = useState(45750.5);
  const [coldAccountBalance] = useState(454249.5);
  const totalBalance = hotAccountBalance + coldAccountBalance;

  // Fund swipe state
  const [swipeAmount, setSwipeAmount] = useState("");
  const [swipeDirection, setSwipeDirection] = useState("");

  // Fund holding state
  const [currentHoldingPercentage] = useState(8.5);
  const [newHoldingPercentage, setNewHoldingPercentage] = useState([8.5]);
  const [isHoldingLocked] = useState(false);

  // Transaction history for swipes
  const [swipeHistory] = useState([
    {
      id: "SWP001",
      date: "2024-01-20",
      time: "10:30 AM",
      direction: "Cold to Hot",
      amount: 5000,
      percentage: 1.0,
      status: "Completed",
      description: "Regular liquidity transfer",
    },
    {
      id: "SWP002",
      date: "2024-01-19",
      time: "02:15 PM",
      direction: "Hot to Cold",
      amount: 10000,
      percentage: 2.0,
      status: "Completed",
      description: "Excess funds transfer",
    },
    {
      id: "SWP003",
      date: "2024-01-18",
      time: "11:45 AM",
      direction: "Cold to Hot",
      amount: 7500,
      percentage: 1.5,
      status: "Completed",
      description: "Working capital adjustment",
    },
    {
      id: "SWP004",
      date: "2024-01-17",
      time: "09:20 AM",
      direction: "Hot to Cold",
      amount: 15000,
      percentage: 3.0,
      status: "Completed",
      description: "Security transfer",
    },
  ]);

  const calculateSwipePercentage = (amount) => {
    return (((parseFloat(amount) || 0) / totalBalance) * 100).toFixed(2);
  };

  const calculateMaxSwipeAmount = (direction) => {
    if (direction === "coldToHot") {
      // Can transfer from cold to hot up to 20% of total
      const maxPercentage = 20;
      const currentHotPercentage = (hotAccountBalance / totalBalance) * 100;
      const availablePercentage = Math.max(
        0,
        maxPercentage - currentHotPercentage
      );
      return (availablePercentage / 100) * totalBalance;
    } else if (direction === "hotToCold") {
      // Can transfer from hot to cold down to 5% of total
      const minPercentage = 5;
      const currentHotPercentage = (hotAccountBalance / totalBalance) * 100;
      const availablePercentage = Math.max(
        0,
        currentHotPercentage - minPercentage
      );
      return (availablePercentage / 100) * totalBalance;
    }
    return 0;
  };

  const handleSwipeSubmit = () => {
    if (!swipeAmount || !swipeDirection) {
      toast.error("Please enter amount and select direction");
      return;
    }

    const amount = parseFloat(swipeAmount);
    if (amount <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }

    const maxAmount = calculateMaxSwipeAmount(swipeDirection);
    if (amount > maxAmount) {
      toast.error(
        `Maximum transfer amount is $${maxAmount.toLocaleString()} for this direction`
      );
      return;
    }

    const percentage = calculateSwipePercentage(amount);
    const direction =
      swipeDirection === "coldToHot" ? "Cold to Hot" : "Hot to Cold";

    // Simulate swipe execution
    toast.success(
      `Fund swipe initiated: ${direction} - $${amount.toLocaleString()} (${percentage}%)`
    );

    // Reset form
    setSwipeAmount("");
    setSwipeDirection("");
  };

  const handleSetHolding = () => {
    const percentage = newHoldingPercentage[0];
    if (percentage < 5 || percentage > 20) {
      toast.error("Holding percentage must be between 5% and 20%");
      return;
    }

    toast.success(`Hot Account holding percentage set to ${percentage}%`);
  };

  const getDirectionIcon = (direction) => {
    if (direction === "Cold to Hot") {
      return (
        <div className="flex items-center">
          <Snowflake className="w-4 h-4 text-blue-500 mr-1" />
          <ArrowRightLeft className="w-4 h-4 mr-1" />
          <Flame className="w-4 h-4 text-red-500" />
        </div>
      );
    } else {
      return (
        <div className="flex items-center">
          <Flame className="w-4 h-4 text-red-500 mr-1" />
          <ArrowRightLeft className="w-4 h-4 mr-1" />
          <Snowflake className="w-4 h-4 text-blue-500" />
        </div>
      );
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "Completed":
        return (
          <Badge
            variant="outline"
            className="bg-green-50 text-green-700 border-green-200"
          >
            Completed
          </Badge>
        );
      case "Processing":
        return (
          <Badge
            variant="outline"
            className="bg-yellow-50 text-yellow-700 border-yellow-200"
          >
            Processing
          </Badge>
        );
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Fund Management</h1>
          <p className="text-gray-600">
            Manage fund transfers between Hot and Cold accounts
          </p>
        </div>

        {/* Account Balance Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">
                    Hot Account
                  </p>
                  <p className="text-2xl font-bold text-red-600">
                    $
                    {hotAccountBalance.toLocaleString("en-US", {
                      minimumFractionDigits: 2,
                    })}
                  </p>
                  <p className="text-sm text-gray-500">
                    {((hotAccountBalance / totalBalance) * 100).toFixed(1)}% of
                    total
                  </p>
                </div>
                <Flame className="h-12 w-12 text-red-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">
                    Cold Account
                  </p>
                  <p className="text-2xl font-bold text-blue-600">
                    $
                    {coldAccountBalance.toLocaleString("en-US", {
                      minimumFractionDigits: 2,
                    })}
                  </p>
                  <p className="text-sm text-gray-500">
                    {((coldAccountBalance / totalBalance) * 100).toFixed(1)}% of
                    total
                  </p>
                </div>
                <Snowflake className="h-12 w-12 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">
                    Total Balance
                  </p>
                  <p className="text-2xl font-bold text-green-600">
                    $
                    {totalBalance.toLocaleString("en-US", {
                      minimumFractionDigits: 2,
                    })}
                  </p>
                  <p className="text-sm text-gray-500">Combined accounts</p>
                </div>
                <DollarSign className="h-12 w-12 text-green-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs
          value={activeTab}
          onValueChange={setActiveTab}
          className="space-y-6"
        >
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="swipe">Fund Swipe</TabsTrigger>
            <TabsTrigger value="holding">Holding Control</TabsTrigger>
            <TabsTrigger value="history">Swipe History</TabsTrigger>
          </TabsList>

          {/* Fund Swipe Tab */}
          <TabsContent value="swipe">
            <Card>
              <CardHeader>
                <CardTitle>Fund Swipe</CardTitle>
                <CardDescription>
                  Transfer funds between Hot and Cold accounts
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="swipe-amount">Amount (USD) *</Label>
                      <Input
                        id="swipe-amount"
                        type="number"
                        placeholder="Enter amount to transfer"
                        value={swipeAmount}
                        onChange={(e) => setSwipeAmount(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                      {swipeAmount && (
                        <p className="text-sm text-gray-500 mt-1">
                          This represents{" "}
                          {calculateSwipePercentage(swipeAmount)}% of total
                          balance
                        </p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="swipe-direction">
                        Transfer Direction *
                      </Label>
                      <Select
                        value={swipeDirection}
                        onValueChange={setSwipeDirection}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select transfer direction" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="coldToHot">
                            <div className="flex items-center">
                              <Snowflake className="w-4 h-4 text-blue-500 mr-2" />
                              Cold to Hot (Increase liquidity)
                            </div>
                          </SelectItem>
                          <SelectItem value="hotToCold">
                            <div className="flex items-center">
                              <Flame className="w-4 h-4 text-red-500 mr-2" />
                              Hot to Cold (Secure funds)
                            </div>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <h4 className="font-medium text-blue-900 mb-2">
                        Transfer Limits
                      </h4>
                      <div className="space-y-2 text-sm text-blue-700">
                        <p>• Hot Account: 5% - 20% of total balance</p>
                        <p>• Cold Account: 80% - 95% of total balance</p>
                        {swipeDirection && (
                          <p className="font-medium">
                            Max transfer: $
                            {calculateMaxSwipeAmount(
                              swipeDirection
                            ).toLocaleString()}
                          </p>
                        )}
                      </div>
                    </div>

                    {swipeDirection && (
                      <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
                        <h4 className="font-medium text-gray-900 mb-2">
                          After Transfer Preview
                        </h4>
                        <div className="space-y-1 text-sm text-gray-600">
                          {swipeDirection === "coldToHot" ? (
                            <>
                              <p>
                                Hot Account: $
                                {(
                                  hotAccountBalance +
                                  (parseFloat(swipeAmount) || 0)
                                ).toLocaleString()}
                              </p>
                              <p>
                                Cold Account: $
                                {(
                                  coldAccountBalance -
                                  (parseFloat(swipeAmount) || 0)
                                ).toLocaleString()}
                              </p>
                            </>
                          ) : (
                            <>
                              <p>
                                Hot Account: $
                                {(
                                  hotAccountBalance -
                                  (parseFloat(swipeAmount) || 0)
                                ).toLocaleString()}
                              </p>
                              <p>
                                Cold Account: $
                                {(
                                  coldAccountBalance +
                                  (parseFloat(swipeAmount) || 0)
                                ).toLocaleString()}
                              </p>
                            </>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div className="pt-4">
                  <Button
                    onClick={handleSwipeSubmit}
                    className="w-full md:w-auto"
                  >
                    <ArrowRightLeft className="w-4 h-4 mr-2" />
                    Execute Transfer
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Fund Holding Control Tab */}
          <TabsContent value="holding">
            <Card>
              <CardHeader>
                <CardTitle>Fund Holding Control</CardTitle>
                <CardDescription>
                  Set the target percentage for Hot Account holdings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label>Current Hot Account Holding</Label>
                      <div className="flex items-center justify-between p-4 bg-gray-50 border border-gray-200 rounded-lg">
                        <span className="text-2xl font-bold text-gray-900">
                          {currentHoldingPercentage}%
                        </span>
                        {isHoldingLocked ? (
                          <Badge
                            variant="outline"
                            className="bg-red-50 text-red-700 border-red-200"
                          >
                            <Lock className="w-3 h-3 mr-1" />
                            Locked by Admin
                          </Badge>
                        ) : (
                          <Badge
                            variant="outline"
                            className="bg-green-50 text-green-700 border-green-200"
                          >
                            <Unlock className="w-3 h-3 mr-1" />
                            Adjustable
                          </Badge>
                        )}
                      </div>
                    </div>

                    <div>
                      <Label>
                        Set New Holding Percentage ({newHoldingPercentage[0]}%)
                      </Label>
                      <div className="px-3 py-6">
                        <Slider
                          value={newHoldingPercentage}
                          onValueChange={setNewHoldingPercentage}
                          max={20}
                          min={5}
                          step={0.5}
                          className="w-full"
                          disabled={isHoldingLocked}
                        />
                        <div className="flex justify-between text-sm text-gray-500 mt-2">
                          <span>5%</span>
                          <span>12.5%</span>
                          <span>20%</span>
                        </div>
                      </div>
                    </div>

                    <div className="pt-4">
                      <Button
                        onClick={handleSetHolding}
                        disabled={isHoldingLocked}
                        className="w-full md:w-auto"
                      >
                        <Settings className="w-4 h-4 mr-2" />
                        Set Holding %
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <h4 className="font-medium text-blue-900 mb-2">
                        Holding Guidelines
                      </h4>
                      <div className="space-y-2 text-sm text-blue-700">
                        <p>
                          • <strong>5-8%:</strong> Conservative - Lower
                          liquidity, higher security
                        </p>
                        <p>
                          • <strong>8-12%:</strong> Balanced - Optimal for most
                          operations
                        </p>
                        <p>
                          • <strong>12-20%:</strong> Aggressive - Higher
                          liquidity, active trading
                        </p>
                      </div>
                    </div>

                    <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <h4 className="font-medium text-yellow-900 mb-2">
                        Impact Calculation
                      </h4>
                      <div className="space-y-1 text-sm text-yellow-700">
                        <p>
                          Target Hot Amount: $
                          {(
                            (newHoldingPercentage[0] / 100) *
                            totalBalance
                          ).toLocaleString()}
                        </p>
                        <p>
                          Target Cold Amount: $
                          {(
                            ((100 - newHoldingPercentage[0]) / 100) *
                            totalBalance
                          ).toLocaleString()}
                        </p>
                        <p className="font-medium mt-2">
                          {newHoldingPercentage[0] > currentHoldingPercentage
                            ? "Requires Cold to Hot transfer"
                            : newHoldingPercentage[0] < currentHoldingPercentage
                            ? "Requires Hot to Cold transfer"
                            : "No transfer needed"}
                        </p>
                      </div>
                    </div>

                    {isHoldingLocked && (
                      <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                        <h4 className="font-medium text-red-900 mb-2">
                          Admin Lock
                        </h4>
                        <p className="text-sm text-red-700">
                          The holding percentage has been locked by an
                          administrator. Contact your admin to make changes.
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Swipe History Tab */}
          <TabsContent value="history">
            <Card>
              <CardHeader>
                <CardTitle>Fund Swipe History</CardTitle>
                <CardDescription>
                  All fund transfers between Hot and Cold accounts
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Swipe ID</TableHead>
                        <TableHead>Date & Time</TableHead>
                        <TableHead>Direction</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Percentage</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Description</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {swipeHistory.map((swipe) => (
                        <TableRow key={swipe.id}>
                          <TableCell className="font-medium">
                            {swipe.id}
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              <div>{swipe.date}</div>
                              <div className="text-gray-500">{swipe.time}</div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              {getDirectionIcon(swipe.direction)}
                              <span className="ml-2">{swipe.direction}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              {swipe.direction === "Cold to Hot" ? (
                                <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
                              ) : (
                                <TrendingDown className="w-4 h-4 text-red-600 mr-1" />
                              )}
                              <span className="font-medium">
                                ${swipe.amount.toLocaleString()}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>{swipe.percentage}%</TableCell>
                          <TableCell>{getStatusBadge(swipe.status)}</TableCell>
                          <TableCell className="max-w-xs truncate">
                            {swipe.description}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>

                  {swipeHistory.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      No fund swipes found.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default FundManagement;
