"use client";

import { useState } from 'react';

const initialUser = {
    velstronId: 'VLS_U12345',
    accounts: {
        hot: { number: 'HACC-7890-1234', balance: 1250.75 },
        cold: { number: 'CACC-5678-9012', balance: 5890.20 },
    },
    currency: 'USD',
    activationDate: '2023-08-15',
};

function formatCurrency(amount, currency) {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(amount);
}

export default function AccountDetails() {
    const [user] = useState(initialUser);
    const activationDate = new Date(user.activationDate).toLocaleDateString('en-US'); 
    const totalBalance = user.accounts.hot.balance + user.accounts.cold.balance;
    const hotRatio = totalBalance > 0 ? parseFloat(((user.accounts.hot.balance / totalBalance) * 100).toFixed(2)) : 0;
    const coldRatio = totalBalance > 0 ? parseFloat(((user.accounts.cold.balance / totalBalance) * 100).toFixed(2)) : 0;

    return (
        <div className="bg-white rounded-lg shadow-md p-6 mb-4">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Account Overview</h2>
            <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="velstronId" className="block text-sm font-medium text-gray-600">
                            Velstron ID:
                        </label>
                        <p id="velstronId" className="mt-1 text-gray-900 font-medium">
                            {user.velstronId}
                        </p>
                    </div>
                    <div>
                        <label htmlFor="activationDate" className="block text-sm font-medium text-gray-600">
                            Activation Date:
                        </label>
                        <p id="activationDate" className="mt-1 text-gray-900 font-medium">
                            {activationDate}
                        </p>
                    </div>
                </div>

                <div className="border-t border-gray-200 pt-4">
                    <h3 className="text-lg font-semibold text-gray-700 mb-2">Account Balances</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="hotAccount" className="block text-sm font-medium text-gray-600">
                                Hot Account:
                            </label>
                            <p id="hotAccount" className="mt-1 text-indigo-600 font-semibold">
                                {user.accounts.hot.number} - {formatCurrency(user.accounts.hot.balance, user.currency)}
                            </p>
                        </div>
                        <div>
                            <label htmlFor="coldAccount" className="block text-sm font-medium text-gray-600">
                                Cold Account:
                            </label>
                            <p id="coldAccount" className="mt-1 text-blue-600 font-semibold">
                                {user.accounts.cold.number} - {formatCurrency(user.accounts.cold.balance, user.currency)}
                            </p>
                        </div>
                        <div>
                            <label htmlFor="currencyType" className="block text-sm font-medium text-gray-600">
                                Currency:
                            </label>
                            <p id="currencyType" className="mt-1 text-gray-900 font-medium">
                                {user.currency}
                            </p>
                        </div>
                    </div>
                </div>

                <div className="border-t border-gray-200 pt-4">
                    <h3 className="text-lg font-semibold text-gray-700 mb-2">Fund Allocation</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-600">
                                Hot Account Ratio:
                            </label>
                            <p className="mt-1 text-indigo-600 font-semibold">
                                {hotRatio}%
                            </p>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-600">
                                Cold Account Ratio:
                            </label>
                            <p className="mt-1 text-blue-600 font-semibold">
                                {coldRatio}%
                            </p>
                        </div>
                        <div className="md:col-span-2">
                            <div className="bg-gray-100 rounded-md overflow-hidden">
                                <div className="flex items-center h-6">
                                    <div
                                        className="bg-indigo-500 h-full text-white text-xs text-center font-semibold"
                                        style={{ width: `${hotRatio}%` }}
                                    >
                                        {hotRatio > 5 ? `${hotRatio}% Hot` : ''}
                                    </div>
                                    <div
                                        className="bg-blue-500 h-full text-white text-xs text-center font-semibold"
                                        style={{ width: `${coldRatio}%` }}
                                    >
                                        {coldRatio > 5 ? `${coldRatio}% Cold` : ''}
                                    </div>
                                </div>
                            </div>
                            <p className="mt-1 text-sm text-gray-500">Visual representation of your current fund allocation.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}