"use client";

import { useState, useEffect } from 'react';
import { ArrowDownLeft } from 'lucide-react';
import { useRouter } from 'next/navigation';
import toast from 'react-hot-toast';

const API_CALL_DELAY = 750;

const initialUser = {
    velstronId: 'VLS_U12345',
    name: 'Moon Sahu',
    accounts: {
        hot: { balance: 1250.75, number: 'XXXX-XXXX-XXXX-1234' },
        cold: { balance: 5890.20, number: 'XXXX-XXXX-XXXX-5678' },
    },
};

const initialWithdrawalForm = {
    amount: '',
    account: 'hot',
};

export default function WithdrawalRequestPage() {
    const router = useRouter();
    const [withdrawalData, setWithdrawalData] = useState(initialWithdrawalForm);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [submissionError, setSubmissionError] = useState(null);
    const [userAccounts, setUserAccounts] = useState(null);
    const [isLoadingAccounts, setIsLoadingAccounts] = useState(true);

    useEffect(() => {
        const fetchUserAccounts = async () => {
            setIsLoadingAccounts(true);
            await new Promise(resolve => setTimeout(resolve, API_CALL_DELAY));
            setUserAccounts(initialUser.accounts);
            setIsLoadingAccounts(false);
        };

        fetchUserAccounts();
    }, []);

    const formatCurrency = (amount) => {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
        }).format(amount);
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setWithdrawalData(prev => ({ ...prev, [name]: value }));
    };

    const handleWithdrawalRequest = async () => {
        const { amount, account } = withdrawalData;
        const withdrawalAmount = parseFloat(amount);

        if (isNaN(withdrawalAmount) || withdrawalAmount <= 0) {
            toast.error('Please enter a valid positive amount to withdraw.');
            return;
        }

        const selectedAccountBalance = userAccounts?.[account]?.balance;
        if (selectedAccountBalance === undefined || withdrawalAmount > selectedAccountBalance) {
            toast.error('Insufficient balance in the selected account.');
            return;
        }

        setIsSubmitting(true);
        setSubmissionError(null);

        await new Promise(resolve => setTimeout(resolve, API_CALL_DELAY));

        toast.success(`Withdrawal request of ${formatCurrency(withdrawalAmount)} from your ${account} account submitted successfully.`);
        setWithdrawalData(initialWithdrawalForm);
        router.push('/dashboard/user'); 

        setIsSubmitting(false);
    };

    if (isLoadingAccounts) {
        return <div className="container mx-auto p-6">Loading accounts...</div>; 
    }

    if (!userAccounts) {
        return <div className="container mx-auto p-6">Failed to load accounts. Please try again.</div>;
    }

    return (
        <div className="container mx-auto p-6">
            <h1 className="text-2xl font-semibold text-gray-800 mb-6">Withdrawal Request</h1>

            <div className="bg-white rounded-lg shadow-md p-6">
                <div className="mb-4">
                    <label htmlFor="amount" className="block text-sm font-medium text-gray-700">
                        Amount to Withdraw:
                    </label>
                    <div className="relative mt-1 rounded-md shadow-sm">
                        <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                            <span className="text-gray-500 sm:text-sm">$</span>
                        </div>
                        <input
                            type="number"
                            id="amount"
                            name="amount"
                            className="block w-full rounded-md border-gray-300 pr-12 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm pl-7"
                            placeholder="0.00"
                            value={withdrawalData.amount}
                            onChange={handleInputChange}
                            aria-describedby="amount-helper"
                        />
                        <div className="absolute inset-y-0 right-0 flex items-center">
                            <span className="text-gray-500 sm:text-sm pr-3">USD</span>
                        </div>
                    </div>
                    <p className="mt-1 text-sm text-gray-500" id="amount-helper">
                        Enter the amount you wish to withdraw.
                    </p>
                </div>

                <div className="mb-4">
                    <label htmlFor="account" className="block text-sm font-medium text-gray-700">
                        Withdraw From Account:
                    </label>
                    <select
                        id="account"
                        name="account"
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                        value={withdrawalData.account}
                        onChange={handleInputChange}
                        aria-describedby="account-helper"
                        disabled={isLoadingAccounts || !userAccounts}
                    >
                        {userAccounts && Object.keys(userAccounts).map((key) => (
                            <option key={key} value={key}>
                                {`${key.charAt(0).toUpperCase()}${key.slice(1)} Account (${userAccounts[key].number})`}
                            </option>
                        ))}
                        {!userAccounts && <option disabled>Loading accounts...</option>}
                    </select>
                    <p className="mt-1 text-sm text-gray-500" id="account-helper">
                        Select the account you want to withdraw funds from.
                    </p>
                </div>

                <button
                    onClick={handleWithdrawalRequest}
                    className="inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:bg-gray-200 disabled:text-gray-500 disabled:cursor-not-allowed"
                    disabled={isSubmitting || isLoadingAccounts || !userAccounts}
                >
                    <ArrowDownLeft className="mr-2 h-4 w-4" /> {isSubmitting ? 'Processing...' : 'Request Withdrawal'}
                </button>

                {submissionError && (
                    <div className="mt-4 text-red-500">
                        {submissionError}
                    </div>
                )}

                <div className="mt-4 text-sm text-gray-500">
                    <p>Please note that all withdrawal requests are subject to approval and processing times may vary.</p>
                </div>
            </div>
        </div>
    );
}