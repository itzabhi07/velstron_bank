"use client";
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Upload,
  Download,
  Filter,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  DollarSign,
  TrendingDown,
  TrendingUp,
} from "lucide-react";
import { toast } from "sonner";

const Transactions = () => {
  const [activeTab, setActiveTab] = useState("deposit");

  // Deposit form state
  const [depositAmount, setDepositAmount] = useState("");
  const [selectedCurrency, setSelectedCurrency] = useState("USD");
  const [paymentProof, setPaymentProof] = useState(null);

  // Withdrawal form state
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [withdrawReason, setWithdrawReason] = useState("");
  const [beneficiaryName, setBeneficiaryName] = useState("");
  const [beneficiaryAccount, setBeneficiaryAccount] = useState("");
  const [beneficiaryBank, setBeneficiaryBank] = useState("");
  const [beneficiarySwift, setBeneficiarySwift] = useState("");

  // Transaction history state
  const [filterType, setFilterType] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  // Mock user account balance
  const [hotAccountBalance] = useState(45750.5);

  // Mock transaction data
  const [transactions] = useState([
    {
      id: "TXN001",
      date: "2024-01-20",
      time: "10:30 AM",
      type: "Deposit",
      amount: 5000,
      currency: "USD",
      direction: "In",
      status: "Approved",
      description: "Bank transfer deposit",
    },
    {
      id: "TXN002",
      date: "2024-01-19",
      time: "02:15 PM",
      type: "Withdrawal",
      amount: 2500,
      currency: "USD",
      direction: "Out",
      status: "Pending",
      description: "Personal withdrawal",
    },
    {
      id: "TXN003",
      date: "2024-01-18",
      time: "11:45 AM",
      type: "Swipe",
      amount: 150,
      currency: "USD",
      direction: "Out",
      status: "Approved",
      description: "Card payment",
    },
    {
      id: "TXN004",
      date: "2024-01-17",
      time: "09:20 AM",
      type: "Deposit",
      amount: 10000,
      currency: "EUR",
      direction: "In",
      status: "Approved",
      description: "Wire transfer",
    },
    {
      id: "TXN005",
      date: "2024-01-16",
      time: "04:30 PM",
      type: "Withdrawal",
      amount: 1000,
      currency: "USD",
      direction: "Out",
      status: "Rejected",
      description: "Insufficient documentation",
    },
    {
      id: "TXN006",
      date: "2024-01-15",
      time: "01:15 PM",
      type: "Swipe",
      amount: 75,
      currency: "USD",
      direction: "Out",
      status: "Approved",
      description: "Online purchase",
    },
  ]);

  const currencies = [
    { value: "USD", label: "USD - US Dollar" },
    { value: "EUR", label: "EUR - Euro" },
    { value: "GBP", label: "GBP - British Pound" },
    { value: "JPY", label: "JPY - Japanese Yen" },
    { value: "CAD", label: "CAD - Canadian Dollar" },
  ];

  const handleDepositSubmit = () => {
    if (!depositAmount || !paymentProof) {
      toast.error(
        "Please fill in all required fields and upload payment proof"
      );
      return;
    }

    if (parseFloat(depositAmount) <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }

    // Simulate submission
    toast.success(
      "Deposit request submitted successfully! Awaiting admin approval."
    );

    // Reset form
    setDepositAmount("");
    setPaymentProof(null);
    document.getElementById("payment-proof").value = "";
  };

  const handleWithdrawalSubmit = () => {
    if (
      !withdrawAmount ||
      !withdrawReason ||
      !beneficiaryName ||
      !beneficiaryAccount ||
      !beneficiaryBank
    ) {
      toast.error("Please fill in all required fields");
      return;
    }

    const amount = parseFloat(withdrawAmount);
    if (amount <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }

    if (amount > hotAccountBalance) {
      toast.error("Insufficient balance in Hot Account");
      return;
    }

    // Simulate submission
    toast.success(
      "Withdrawal request submitted successfully! Awaiting admin approval."
    );

    // Reset form
    setWithdrawAmount("");
    setWithdrawReason("");
    setBeneficiaryName("");
    setBeneficiaryAccount("");
    setBeneficiaryBank("");
    setBeneficiarySwift("");
  };

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        // 5MB limit
        toast.error("File size must be less than 5MB");
        return;
      }
      setPaymentProof(file);
      toast.success("Payment proof uploaded successfully");
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "Pending":
        return (
          <Badge
            variant="outline"
            className="bg-yellow-50 text-yellow-700 border-yellow-200"
          >
            <Clock className="w-3 h-3 mr-1" />
            Pending
          </Badge>
        );
      case "Approved":
        return (
          <Badge
            variant="outline"
            className="bg-green-50 text-green-700 border-green-200"
          >
            <CheckCircle className="w-3 h-3 mr-1" />
            Approved
          </Badge>
        );
      case "Rejected":
        return (
          <Badge
            variant="outline"
            className="bg-red-50 text-red-700 border-red-200"
          >
            <XCircle className="w-3 h-3 mr-1" />
            Rejected
          </Badge>
        );
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getDirectionIcon = (direction, type) => {
    if (direction === "In") {
      return <TrendingUp className="w-4 h-4 text-green-600" />;
    } else {
      return <TrendingDown className="w-4 h-4 text-red-600" />;
    }
  };

  const filteredTransactions = transactions.filter((transaction) => {
    const matchesType =
      filterType === "all" ||
      transaction.type.toLowerCase() === filterType.toLowerCase();
    const matchesSearch =
      transaction.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesType && matchesSearch;
  });

  const exportToPDF = () => {
    toast.info("PDF export functionality would be implemented here");
  };

  const exportToExcel = () => {
    toast.info("Excel export functionality would be implemented here");
  };

  const pendingTransactions = transactions.filter(
    (t) => t.status === "Pending"
  ).length;
  const approvedTransactions = transactions.filter(
    (t) => t.status === "Approved"
  ).length;
  const totalDeposits = transactions
    .filter((t) => t.type === "Deposit" && t.status === "Approved")
    .reduce((sum, t) => sum + t.amount, 0);
  const totalWithdrawals = transactions
    .filter((t) => t.type === "Withdrawal" && t.status === "Approved")
    .reduce((sum, t) => sum + t.amount, 0);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Transactions</h1>
          <p className="text-gray-600">
            Manage your deposits, withdrawals, and view transaction history
          </p>
        </div>

        {/* Account Balance Card */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">
                  Hot Account Balance
                </p>
                <p className="text-3xl font-bold text-blue-600">
                  $
                  {hotAccountBalance.toLocaleString("en-US", {
                    minimumFractionDigits: 2,
                  })}
                </p>
              </div>
              <DollarSign className="h-12 w-12 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">
                    Pending Transactions
                  </p>
                  <p className="text-2xl font-bold text-yellow-600">
                    {pendingTransactions}
                  </p>
                </div>
                <Clock className="h-8 w-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">
                    Approved Transactions
                  </p>
                  <p className="text-2xl font-bold text-green-600">
                    {approvedTransactions}
                  </p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">
                    Total Deposits
                  </p>
                  <p className="text-2xl font-bold text-blue-600">
                    ${totalDeposits.toLocaleString()}
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">
                    Total Withdrawals
                  </p>
                  <p className="text-2xl font-bold text-purple-600">
                    ${totalWithdrawals.toLocaleString()}
                  </p>
                </div>
                <TrendingDown className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs
          value={activeTab}
          onValueChange={setActiveTab}
          className="space-y-6"
        >
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="deposit">Deposit Funds</TabsTrigger>
            <TabsTrigger value="withdrawal">Withdrawal Request</TabsTrigger>
            <TabsTrigger value="history">Transaction History</TabsTrigger>
          </TabsList>

          {/* Deposit Funds Tab */}
          <TabsContent value="deposit">
            <Card>
              <CardHeader>
                <CardTitle>Deposit Funds</CardTitle>
                <CardDescription>
                  Submit a deposit request with payment proof for admin approval
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="deposit-amount">Amount *</Label>
                      <Input
                        id="deposit-amount"
                        type="number"
                        placeholder="Enter deposit amount"
                        value={depositAmount}
                        onChange={(e) => setDepositAmount(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>

                    <div>
                      <Label htmlFor="currency">Currency *</Label>
                      <Select
                        value={selectedCurrency}
                        onValueChange={setSelectedCurrency}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select currency" />
                        </SelectTrigger>
                        <SelectContent>
                          {currencies.map((currency) => (
                            <SelectItem
                              key={currency.value}
                              value={currency.value}
                            >
                              {currency.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="payment-proof">
                        Upload Payment Proof *
                      </Label>
                      <div className="mt-2">
                        <Input
                          id="payment-proof"
                          type="file"
                          accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                          onChange={handleFileUpload}
                          className="cursor-pointer"
                        />
                        <p className="text-sm text-gray-500 mt-1">
                          Accepted formats: PDF, JPG, PNG, DOC, DOCX (Max 5MB)
                        </p>
                      </div>
                      {paymentProof && (
                        <div className="mt-2 p-2 bg-green-50 border border-green-200 rounded-md">
                          <p className="text-sm text-green-700">
                            ✓ File uploaded: {paymentProof.name}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="pt-4">
                  <Button
                    onClick={handleDepositSubmit}
                    className="w-full md:w-auto"
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Submit for Approval
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Withdrawal Request Tab */}
          <TabsContent value="withdrawal">
            <Card>
              <CardHeader>
                <CardTitle>Withdrawal Request</CardTitle>
                <CardDescription>
                  Request withdrawal from your Hot Account (Available: $
                  {hotAccountBalance.toLocaleString()})
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="withdraw-amount">
                        Withdrawal Amount *
                      </Label>
                      <Input
                        id="withdraw-amount"
                        type="number"
                        placeholder="Enter withdrawal amount"
                        value={withdrawAmount}
                        onChange={(e) => setWithdrawAmount(e.target.value)}
                        min="0"
                        max={hotAccountBalance}
                        step="0.01"
                      />
                    </div>

                    <div>
                      <Label htmlFor="withdraw-reason">
                        Reason for Withdrawal *
                      </Label>
                      <Textarea
                        id="withdraw-reason"
                        placeholder="Enter reason for withdrawal"
                        value={withdrawReason}
                        onChange={(e) => setWithdrawReason(e.target.value)}
                        rows={3}
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="beneficiary-name">
                        Beneficiary Name *
                      </Label>
                      <Input
                        id="beneficiary-name"
                        placeholder="Enter beneficiary full name"
                        value={beneficiaryName}
                        onChange={(e) => setBeneficiaryName(e.target.value)}
                      />
                    </div>

                    <div>
                      <Label htmlFor="beneficiary-account">
                        Beneficiary Account Number *
                      </Label>
                      <Input
                        id="beneficiary-account"
                        placeholder="Enter account number"
                        value={beneficiaryAccount}
                        onChange={(e) => setBeneficiaryAccount(e.target.value)}
                      />
                    </div>

                    <div>
                      <Label htmlFor="beneficiary-bank">Bank Name *</Label>
                      <Input
                        id="beneficiary-bank"
                        placeholder="Enter bank name"
                        value={beneficiaryBank}
                        onChange={(e) => setBeneficiaryBank(e.target.value)}
                      />
                    </div>

                    <div>
                      <Label htmlFor="beneficiary-swift">
                        SWIFT/Routing Code
                      </Label>
                      <Input
                        id="beneficiary-swift"
                        placeholder="Enter SWIFT or routing code"
                        value={beneficiarySwift}
                        onChange={(e) => setBeneficiarySwift(e.target.value)}
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-4">
                  <Button
                    onClick={handleWithdrawalSubmit}
                    className="w-full md:w-auto"
                  >
                    <TrendingDown className="w-4 h-4 mr-2" />
                    Submit Withdrawal Request
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Transaction History Tab */}
          <TabsContent value="history">
            <Card>
              <CardHeader>
                <CardTitle>Transaction History</CardTitle>
                <CardDescription>
                  View all your transactions and export reports
                </CardDescription>
              </CardHeader>
              <CardContent>
                {/* Filters and Search */}
                <div className="flex flex-col md:flex-row gap-4 mb-6">
                  <div className="flex-1">
                    <Input
                      placeholder="Search by transaction ID or description..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  <div className="flex gap-4">
                    <Select value={filterType} onValueChange={setFilterType}>
                      <SelectTrigger className="w-48">
                        <SelectValue placeholder="Filter by type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Transactions</SelectItem>
                        <SelectItem value="deposit">Deposits</SelectItem>
                        <SelectItem value="withdrawal">Withdrawals</SelectItem>
                        <SelectItem value="swipe">Swipes</SelectItem>
                      </SelectContent>
                    </Select>

                    <Button variant="outline" onClick={exportToPDF}>
                      <Download className="w-4 h-4 mr-2" />
                      PDF
                    </Button>

                    <Button variant="outline" onClick={exportToExcel}>
                      <Download className="w-4 h-4 mr-2" />
                      Excel
                    </Button>
                  </div>
                </div>

                {/* Transactions Table */}
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Transaction ID</TableHead>
                        <TableHead>Date & Time</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Direction</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Description</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredTransactions.map((transaction) => (
                        <TableRow key={transaction.id}>
                          <TableCell className="font-medium">
                            {transaction.id}
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              <div>{transaction.date}</div>
                              <div className="text-gray-500">
                                {transaction.time}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{transaction.type}</Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              {getDirectionIcon(
                                transaction.direction,
                                transaction.type
                              )}
                              <span className="ml-2 font-medium">
                                {transaction.currency}{" "}
                                {transaction.amount.toLocaleString()}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                transaction.direction === "In"
                                  ? "secondary"
                                  : "outline"
                              }
                            >
                              {transaction.direction}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {getStatusBadge(transaction.status)}
                          </TableCell>
                          <TableCell className="max-w-xs truncate">
                            {transaction.description}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>

                  {filteredTransactions.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      No transactions found matching your criteria.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Transactions;
