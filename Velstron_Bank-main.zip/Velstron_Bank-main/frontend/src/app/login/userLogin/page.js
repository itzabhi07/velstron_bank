"use client";
import { useState } from "react";
import {
  User,
  Lock,
  ArrowLeft,
  Send,
  Shield,
  Mail,
  Delete,
  Space,
  ArrowUp,
  EyeOff,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { toast } from "sonner";

const UserLogin = () => {
  const [velstronId, setVelstronId] = useState("");
  const [password, setPassword] = useState("");
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [resetVelstronId, setResetVelstronId] = useState("");
  const [resetEmail, setResetEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const [showVirtualKeyboard, setShowVirtualKeyboard] = useState(false);
  const [activeField, setActiveField] = useState(null);
  const [isUpperCase, setIsUpperCase] = useState(false);
  const [showNumbers, setShowNumbers] = useState(false);

  const letters = [
    ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"],
    ["a", "s", "d", "f", "g", "h", "j", "k", "l"],
    ["z", "x", "c", "v", "b", "n", "m"],
  ];

  const numbers = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"];
  const symbols = ["!", "@", "#", "$", "%", "^", "&", "*", "(", ")"];

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    await new Promise((resolve) => setTimeout(resolve, 1500));

    const isIdRegistered = Math.random() > 0.5;

    if (!isIdRegistered) {
      toast.error("ID Not Found", {
        description:
          "Velstron ID not registered. Please sign up to create an account.",
      });
    } else {
      toast.success("Login Successful", {
        description: "Welcome back! You've been successfully logged in.",
      });
    }

    setIsLoading(false);
  };

  const handleForgotPassword = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    await new Promise((resolve) => setTimeout(resolve, 2000));
    toast.success("Password Reset Instructions Sent", {
      description: `We've sent password reset instructions for Velstron ID: ${resetVelstronId}`,
    });

    setIsLoading(false);
    setShowForgotPassword(false);
    setResetVelstronId("");
    setResetEmail("");
  };

  const resetToLogin = () => {
    setShowForgotPassword(false);
    setResetVelstronId("");
    setResetEmail("");
  };

  const handleFieldFocus = (fieldName) => {
    setActiveField(fieldName);
  };

  const handleVirtualKeyPress = (key) => {
    if (!activeField) return;

    const finalKey = isUpperCase && !showNumbers ? key.toUpperCase() : key;

    switch (activeField) {
      case "velstronId":
        setVelstronId((prev) => prev + finalKey);
        break;
      case "password":
        setPassword((prev) => prev + finalKey);
        break;
      case "resetVelstronId":
        setResetVelstronId((prev) => prev + finalKey);
        break;
      case "resetEmail":
        setResetEmail((prev) => prev + finalKey);
        break;
    }
  };

  const handleVirtualBackspace = () => {
    if (!activeField) return;

    switch (activeField) {
      case "velstronId":
        setVelstronId((prev) => prev.slice(0, -1));
        break;
      case "password":
        setPassword((prev) => prev.slice(0, -1));
        break;
      case "resetVelstronId":
        setResetVelstronId((prev) => prev.slice(0, -1));
        break;
      case "resetEmail":
        setResetEmail((prev) => prev.slice(0, -1));
        break;
    }
  };

  const handleVirtualClear = () => {
    if (!activeField) return;

    switch (activeField) {
      case "velstronId":
        setVelstronId("");
        break;
      case "password":
        setPassword("");
        break;
      case "resetVelstronId":
        setResetVelstronId("");
        break;
      case "resetEmail":
        setResetEmail("");
        break;
    }
  };

  const toggleVirtualKeyboard = () => {
    setShowVirtualKeyboard(!showVirtualKeyboard);
    if (!showVirtualKeyboard && !activeField) {
      if (!showForgotPassword) {
        setActiveField("velstronId");
      } else {
        setActiveField("resetVelstronId");
      }
    } else if (showVirtualKeyboard) {
      setActiveField(null);
    }
  };

  const toggleCase = () => {
    setIsUpperCase(!isUpperCase);
  };

  const toggleKeyboardType = () => {
    setShowNumbers(!showNumbers);
  };

  const VirtualKeyboard = () => {
    if (!showVirtualKeyboard) return null;

    return (
      <Card className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t-2 border-gray-200 rounded-t-xl shadow-2xl animate-in slide-in-from-bottom duration-300">
        <div className="p-4 space-y-3">
          <div className="flex justify-between items-center mb-2">
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={toggleKeyboardType}
                className="text-xs"
              >
                {showNumbers ? "ABC" : "123"}
              </Button>
              {!showNumbers && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={toggleCase}
                  className={`text-xs ${isUpperCase ? "bg-blue-100" : ""}`}
                >
                  <ArrowUp className="w-3 h-3" />
                </Button>
              )}
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleVirtualKeyboard}
              className="text-gray-500"
            >
              <EyeOff className="w-4 h-4" />
            </Button>
          </div>

          {showNumbers ? (
            <div className="space-y-2">
              <div className="grid grid-cols-10 gap-1">
                {numbers.map((num) => (
                  <Button
                    key={num}
                    variant="outline"
                    size="sm"
                    onClick={() => handleVirtualKeyPress(num)}
                    className="h-10 text-sm font-medium hover:bg-blue-50 active:scale-95 transition-all"
                  >
                    {num}
                  </Button>
                ))}
              </div>
              <div className="grid grid-cols-10 gap-1">
                {symbols.map((symbol) => (
                  <Button
                    key={symbol}
                    variant="outline"
                    size="sm"
                    onClick={() => handleVirtualKeyPress(symbol)}
                    className="h-10 text-sm font-medium hover:bg-blue-50 active:scale-95 transition-all"
                  >
                    {symbol}
                  </Button>
                ))}
              </div>
              <div className="grid grid-cols-5 gap-1 justify-center">
                {["-", "_", "=", "+", "/"].map((symbol) => (
                  <Button
                    key={symbol}
                    variant="outline"
                    size="sm"
                    onClick={() => handleVirtualKeyPress(symbol)}
                    className="h-10 text-sm font-medium hover:bg-blue-50 active:scale-95 transition-all"
                  >
                    {symbol}
                  </Button>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              {letters.map((row, rowIndex) => (
                <div
                  key={rowIndex}
                  className={`grid gap-1 ${
                    rowIndex === 0
                      ? "grid-cols-10"
                      : rowIndex === 1
                      ? "grid-cols-9"
                      : "grid-cols-7"
                  }`}
                >
                  {row.map((letter) => (
                    <Button
                      key={letter}
                      variant="outline"
                      size="sm"
                      onClick={() => handleVirtualKeyPress(letter)}
                      className="h-10 text-sm font-medium hover:bg-blue-50 active:scale-95 transition-all"
                    >
                      {isUpperCase ? letter.toUpperCase() : letter}
                    </Button>
                  ))}
                </div>
              ))}
            </div>
          )}

          <div className="grid grid-cols-4 gap-2">
            <Button
              variant="outline"
              onClick={handleVirtualClear}
              className="h-10 text-xs font-medium hover:bg-red-50 hover:border-red-200"
            >
              Clear
            </Button>
            <Button
              variant="outline"
              onClick={() => handleVirtualKeyPress(" ")}
              className="col-span-2 h-10 text-xs font-medium hover:bg-blue-50"
            >
              <Space className="w-4 h-4 mr-1" />
              Space
            </Button>
            <Button
              variant="outline"
              onClick={handleVirtualBackspace}
              className="h-10 text-xs font-medium hover:bg-orange-50 hover:border-orange-200"
            >
              <Delete className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </Card>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute top-0 right-0 h-full w-1/2 bg-blue-100 opacity-30 -skew-x-12 transform origin-top-right"></div>
      <div className="absolute bottom-0 left-0 h-1/3 w-1/3 bg-blue-200 opacity-20 skew-x-12 transform origin-bottom-left"></div>

      <div className="absolute top-0 left-0 right-0 bg-blue-900 text-white py-2 text-sm">
        <div className="container mx-auto px-6 flex justify-between items-center">
          <div className="flex items-center">
            <Shield className="w-4 h-4 mr-2" />
            <span className="font-semibold tracking-tight">Velstron Bank</span>
          </div>
          <div className="flex space-x-4">
            <a href="/help" className="hover:underline cursor-pointer">
              Help
            </a>
            <a href="/contactus" className="hover:underline cursor-pointer">
              Contact Us
            </a>
          </div>
        </div>
      </div>

      <a
        href="/"
        className="absolute top-20 left-6 flex items-center text-blue-700 hover:text-blue-900 transition-colors z-20"
      >
        <ArrowLeft className="w-4 h-4 mr-1" />
        Back to Home
      </a>

      <Card
        className={`w-full max-w-md shadow-lg border-0 bg-white relative z-10 mt-16 transition-all duration-300 ${
          showVirtualKeyboard ? "mb-80" : ""
        }`}
      >
        <CardHeader className="space-y-1 text-center pb-8">
          <div className="mx-auto w-16 h-16 bg-blue-900 rounded-full flex items-center justify-center mb-4 shadow-md">
            <User className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl font-extrabold text-blue-900 tracking-tight">
            {showForgotPassword ? "Reset Password" : "User Login"}
          </CardTitle>
          <CardDescription className="text-gray-700 leading-relaxed">
            {showForgotPassword
              ? "Enter your Velstron ID and email to receive password reset instructions"
              : "Access your account with your Velstron ID and password"}
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {!showForgotPassword ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label
                  htmlFor="velstronId"
                  className="text-sm font-semibold text-gray-700"
                >
                  Velstron ID
                </Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <Input
                    id="velstronId"
                    type="text"
                    placeholder="Enter your Velstron ID"
                    value={velstronId}
                    onChange={(e) => setVelstronId(e.target.value)}
                    onFocus={() => handleFieldFocus("velstronId")}
                    className={`pl-10 h-12 border-gray-300 focus:border-blue-900 focus:ring-blue-900 rounded-md ${
                      activeField === "velstronId" ? "ring-2 ring-blue-500" : ""
                    }`}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label
                  htmlFor="password"
                  className="text-sm font-semibold text-gray-700"
                >
                  Password
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    onFocus={() => handleFieldFocus("password")}
                    className={`pl-10 h-12 border-gray-300 focus:border-blue-900 focus:ring-blue-900 rounded-md ${
                      activeField === "password" ? "ring-2 ring-blue-500" : ""
                    }`}
                    required
                  />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={toggleVirtualKeyboard}
                  className="text-xs text-blue-700 hover:text-blue-900 hover:bg-blue-50"
                >
                  Virtual Keyboard
                </Button>
                <button
                  type="button"
                  onClick={() => setShowForgotPassword(true)}
                  className="text-sm text-blue-700 hover:text-blue-900 transition-colors font-medium hover:underline"
                >
                  Forgot your password?
                </button>
              </div>

              <Button
                type="submit"
                disabled={isLoading}
                className="w-full h-12 bg-blue-900 hover:bg-blue-800 text-white font-semibold rounded-full transition-all duration-300 transform hover:scale-[1.02] shadow-lg"
              >
                {isLoading ? (
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Signing in...</span>
                  </div>
                ) : (
                  "Secure Login"
                )}
              </Button>
            </form>
          ) : (
            <form onSubmit={handleForgotPassword} className="space-y-4">
              <div className="space-y-2">
                <Label
                  htmlFor="resetVelstronId"
                  className="text-sm font-semibold text-gray-700"
                >
                  Velstron ID
                </Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <Input
                    id="resetVelstronId"
                    type="text"
                    placeholder="Enter your Velstron ID"
                    value={resetVelstronId}
                    onChange={(e) => setResetVelstronId(e.target.value)}
                    onFocus={() => handleFieldFocus("resetVelstronId")}
                    className={`pl-10 h-12 border-gray-300 focus:border-blue-900 focus:ring-blue-900 rounded-md ${
                      activeField === "resetVelstronId"
                        ? "ring-2 ring-blue-500"
                        : ""
                    }`}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label
                  htmlFor="resetEmail"
                  className="text-sm font-semibold text-gray-700"
                >
                  Email Address
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <Input
                    id="resetEmail"
                    type="email"
                    placeholder="Enter your email address"
                    value={resetEmail}
                    onChange={(e) => setResetEmail(e.target.value)}
                    onFocus={() => handleFieldFocus("resetEmail")}
                    className={`pl-10 h-12 border-gray-300 focus:border-blue-900 focus:ring-blue-900 rounded-md ${
                      activeField === "resetEmail" ? "ring-2 ring-blue-500" : ""
                    }`}
                    required
                  />
                </div>
              </div>

              <div className="flex items-center justify-between mb-4">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={toggleVirtualKeyboard}
                  className="text-xs text-blue-700 hover:text-blue-900 hover:bg-blue-50"
                >
                  Virtual Keyboard
                </Button>
              </div>

              <div className="space-y-3">
                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full h-12 bg-blue-900 hover:bg-blue-800 text-white font-semibold rounded-full transition-all duration-300 transform hover:scale-[1.02] shadow-lg"
                >
                  {isLoading ? (
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Sending...</span>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2">
                      <Send className="w-4 h-4" />
                      <span>Send Reset Instructions</span>
                    </div>
                  )}
                </Button>

                <Button
                  type="button"
                  variant="outline"
                  onClick={resetToLogin}
                  className="w-full h-12 border-gray-300 hover:bg-gray-50 transition-colors rounded-full font-medium"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Login
                </Button>
              </div>
            </form>
          )}

          <div className="text-center text-xs text-gray-500 bg-gray-50 p-3 rounded-md">
            <Shield className="w-3 h-3 inline mr-1" />
            Your data is protected with bank-level security
          </div>
        </CardContent>
      </Card>

      <VirtualKeyboard />
    </div>
  );
};

export default UserLogin;
