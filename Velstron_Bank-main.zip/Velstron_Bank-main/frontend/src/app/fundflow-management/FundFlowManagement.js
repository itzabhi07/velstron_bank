import React, { useEffect, useState } from 'react';
import { getFundFlows } from '../services/FundService';

const FundFlowManagement = () => {
  const [fundFlows, setFundFlows] = useState([]);

  // Fetch fund flows on component mount
  useEffect(() => {
    const fetchFundFlows = async () => {
      try {
        const data = await getFundFlows();
        setFundFlows(data);
      } catch (error) {
        console.error('Failed to fetch fund flows', error);
      }
    };
    fetchFundFlows();
  }, []);

  return (
    <div>
      <h1>Fund Flow Management</h1>
      <h2>Fund Flows</h2>
      <ul>
        {fundFlows.map((flow, index) => (
          <li key={index}>{flow.name} - {flow.amount}</li>  {/* Adjust as per the response data structure */}
        ))}
      </ul>
    </div>
  );
};

export default FundFlowManagement;