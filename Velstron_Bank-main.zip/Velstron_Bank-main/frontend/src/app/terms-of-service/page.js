"use client";

import React from 'react';

const TermsOfServicePage = () => {
  return (
    <div className="container mx-auto py-10 px-6">
      <h1 className="text-3xl font-bold text-blue-900 mb-6">Terms of Service</h1>
      <p className="mb-4">
        **Last Updated:** May 31, 2025
      </p>
      <p className="mb-4">
        Welcome to Velstron Bank! These Terms of Service ("Terms") govern your access to and use of our website, services, and applications (collectively, the "Services"). By accessing or using our Services, you agree to be bound by these Terms.
      </p>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">1. Acceptance of Terms</h2>
      <p className="mb-4">
        By accessing or using our Services, you acknowledge that you have read, understood, and agree to be bound by these Terms and our Privacy Policy. If you do not agree to these Terms, you may not access or use our Services.
      </p>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">2. User Accounts</h2>
      <p className="mb-4">
        If you register for an account with us, you are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account. You agree to provide accurate and complete information when creating your account and to update your information as necessary. You must notify us immediately of any unauthorized access to or use of your account.
      </p>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">3. Use of Services</h2>
      <p className="mb-2">You agree to use our Services only for lawful purposes and in accordance with these Terms. You are prohibited from:</p>
      <ul className="list-disc list-inside mb-4">
        <li>Violating any applicable laws or regulations.</li>
        <li>Engaging in any fraudulent, abusive, or illegal activities.</li>
        <li>Attempting to interfere with the proper functioning of our Services.</li>
        <li>Transmitting any viruses, malware, or other harmful code.</li>
        <li>Collecting or harvesting any personally identifiable information from other users without their consent.</li>
        <li>Impersonating any person or entity or misrepresenting your affiliation with any person or entity.</li>
      </ul>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">4. Financial Transactions</h2>
      <p className="mb-4">
        When using our Services for financial transactions, you agree to provide accurate and complete payment information. You are responsible for ensuring that you have sufficient funds for any transactions you initiate. We reserve the right to refuse or cancel any transaction at our discretion.
      </p>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">5. Intellectual Property</h2>
      <p className="mb-4">
        The content, trademarks, logos, and other intellectual property displayed on our Services are owned by Velstron Bank or our licensors. You are granted a limited, non-exclusive, non-transferable license to access and use our Services for your personal or internal business purposes only. You may not reproduce, modify, distribute, or otherwise use our intellectual property without our prior written consent.
      </p>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">6. Disclaimer of Warranties</h2>
      <p className="mb-4">
        Our Services are provided on an "as is" and "as available" basis without any warranties of any kind, express or implied, including but not limited to warranties of merchantability, fitness for a particular purpose, and non-infringement. We do not warrant that our Services will be uninterrupted, error-free, or secure.
      </p>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">7. Limitation of Liability</h2>
      <p className="mb-4">
        To the maximum extent permitted by applicable law, Velstron Bank shall not be liable for any indirect, incidental, special, consequential, or punitive damages arising out of or relating to your use of or inability to use our Services, even if we have been advised of the possibility of such damages. Our total liability to you for any claim arising out of or relating to these Terms or our Services shall not exceed the amount you paid to us (if any) in the twelve (12) months preceding the event giving rise to the liability.
      </p>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">8. Indemnification</h2>
      <p className="mb-4">
        You agree to indemnify and hold harmless Velstron Bank, its affiliates, officers, directors, employees, and agents from and against any and all claims, liabilities, damages, losses, costs, and expenses (including reasonable attorneys' fees) arising out of or relating to your breach of these Terms or your use of our Services.
      </p>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">9. Governing Law</h2>
      <p className="mb-4">
        These Terms shall be governed by and construed in accordance with the laws of Bangladesh, without regard to its conflict of law principles. Any legal action or proceeding arising out of or relating to these Terms shall be brought exclusively in the courts of Bangladesh.
      </p>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">10. Changes to These Terms</h2>
      <p className="mb-4">
        We may update these Terms from time to time. We will notify you of any material changes by posting the updated Terms on our website or through other appropriate communication channels. Your continued use of our Services after the effective date of the revised Terms constitutes your acceptance of the changes.
      </p>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">11. Termination</h2>
      <p className="mb-4">
        We reserve the right to suspend or terminate your access to our Services at any time, with or without cause and without prior notice.
      </p>

      <h2 className="text-xl font-semibold text-blue-800 mb-3">12. Contact Us</h2>
      <p className="mb-2">If you have any questions or concerns about these Terms or our Services, please contact us at:</p>
      <p className="mb-2">Velstron Bank</p>
      <p className="mb-2">Head Office: First Floor Central Point, Club Road Jamnagar, Gujarat -361008</p>
      <p className="mb-2">Email: contact@velstron.com</p>
    </div>
  );
};

export default TermsOfServicePage;