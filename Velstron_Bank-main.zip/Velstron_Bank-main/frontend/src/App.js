import React from "react";
import Login from "./components/Login";
import Dashboard from "./components/Dashboard";
import ExecutiveManagement from "./app/executive-management/ExecutiveManagement";
import FundFlowManagement from "./app/fundflow-management/FundFlowManagement";

function App() {
  return (
    <div className="App">
      <Login />
      <Dashboard />
      <ExecutiveManagement />
      <FundFlowManagement />
    </div>
  );
}

export default App;