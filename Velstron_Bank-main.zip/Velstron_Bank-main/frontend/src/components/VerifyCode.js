import React, { useState } from 'react';
import { verifyCode } from '../api/auth';  // Importing verifyCode API call

const VerifyCode = () => {
  const [code, setCode] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const verificationData = { code };

    const response = await verifyCode(verificationData);  // Call verifyCode API

    if (response) {
      alert('Code verified successfully!');
      // Redirect to dashboard or home page
    }
  };

  return (
    <div>
      <h2>Verify Code</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Enter verification code"
          value={code}
          onChange={(e) => setCode(e.target.value)}
          required
        />
        <br />
        <button type="submit">Verify</button>
      </form>
    </div>
  );
};

export default VerifyCode;