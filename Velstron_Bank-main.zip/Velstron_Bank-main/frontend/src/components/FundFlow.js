import React, { useEffect, useState } from 'react';
import { getFundFlows } from '../api/funds';  // Importing getFundFlows API call

const FundFlow = () => {
  const [fundFlows, setFundFlows] = useState([]);

  useEffect(() => {
    const fetchFundFlows = async () => {
      const data = await getFundFlows();  // Fetch fund flow data from backend
      setFundFlows(data);  // Set state with fetched data
    };
    fetchFundFlows();
  }, []);

  return (
    <div>
      <h2>Fund Flow Data</h2>
      {fundFlows.length > 0 ? (
        <ul>
          {fundFlows.map((flow) => (
            <li key={flow.id}>
              <p>{flow.name} - {flow.amount}</p>
              {/* Display more fields as per the response */}
            </li>
          ))}
        </ul>
      ) : (
        <p>Loading...</p>  // Display loading message while data is being fetched
      )}
    </div>
  );
};

export default FundFlow;