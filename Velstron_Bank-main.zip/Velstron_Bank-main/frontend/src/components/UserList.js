import React, { useEffect, useState } from 'react';
import { fetchUsers } from '../api/users';

const UserList = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const loadUsers = async () => {
      const data = await fetchUsers();
      setUsers(data);
    };
    loadUsers();
  }, []);

  return (
    <div>
      <h2>User List</h2>
      <ul>
        {users.map((user, idx) => (
          <li key={idx}>{user.name} - {user.email}</li>
        ))}
      </ul>
    </div>
  );
};

export default UserList;