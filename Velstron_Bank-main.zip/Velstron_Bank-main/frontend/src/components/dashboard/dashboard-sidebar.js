"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import Image from "next/image";
import {
  LayoutDashboard,
  Users,
  FileText,
  CreditCard,
  Settings,
  ChevronLeft,
  ChevronRight,
  LogOut,
  FileCheck,
  Briefcase,
  PieChart,
  Users2,
  BarChart3,
  ShieldCheck,
} from "lucide-react";

export function DashboardSidebar({
  userRole = "user",
  collapsed: initialCollapsed = false,
  onCollapseToggle,
}) {
  const [collapsed, setCollapsed] = useState(initialCollapsed);
  const pathname = usePathname();

  const userNavItems = [
    { name: "Dashboard", href: "/dashboard/user", icon: LayoutDashboard },
    { name: "Fund Management", href: "/dashboard/user/fundManagement", icon: CreditCard },
    { name: "Transactions", href: "/dashboard/user/transactions", icon: FileText },
    { name: "Account Details", href: "/dashboard/user/account", icon: Briefcase },
    { name: "Settings", href: "/dashboard/user/settings", icon: Settings },
  ];

  const executiveNavItems = [
    { name: "Dashboard", href: "/dashboard/executive", icon: LayoutDashboard },
    { name: "KYC Verification", href: "/dashboard/executive/kycApprovals", icon: FileCheck },
    { name: "Customer Accounts", href: "/dashboard/executive/customerAccounts", icon: Users },
    { name: "Transaction Approvals", href: "/dashboard/executive/transactionApproval", icon: FileText },
    { name: "Settings", href: "/dashboard/executive/settings", icon: Settings },
  ];

  const adminNavItems = [
    { name: "Dashboard", href: "/dashboard/admin", icon: LayoutDashboard },
    { name: "User Management", href: "/dashboard/admin/userManagement", icon: Users2 },
    { name: "Executive Management", href: "/dashboard/admin/executiveManagement", icon: Users },
    { name: "KYC Approvals", href: "/dashboard/admin/kycApprovals", icon: FileCheck },
    { name: "Fund Flows", href: "/dashboard/admin/funds", icon: BarChart3 },
    { name: "Security Settings", href: "/dashboard/admin/securitySettings", icon: ShieldCheck },
    { name: "Analytics", href: "/dashboard/admin/analytics", icon: PieChart },
    { name: "System Settings", href: "/dashboard/admin/settings", icon: Settings },
  ];

  const navItems =
    userRole === "admin"
      ? adminNavItems
      : userRole === "executive"
      ? executiveNavItems
      : userNavItems;

  const logoutHref =
    userRole === "admin"
      ? "/login/adminLogin"
      : userRole === "executive"
      ? "/login/executiveLogin"
      : "/login/userLogin";

  const toggleCollapse = () => {
    setCollapsed(!collapsed);
    onCollapseToggle(!collapsed);
  };

  return (
    <div
      className={`flex flex-col border-r bg-[#0d62a6] text-white h-screen ${
        collapsed ? "w-16" : "w-64"
      } transition-all duration-300 fixed left-0 top-0`}
    >
      <div
        className={`flex items-center ${
          collapsed ? "justify-center" : "justify-between"
        } h-16 px-4 border-b border-[#174e82]`}
      >
        {!collapsed && (
          <Image
            src="/images/logo_crop.jpg"
            alt="Bank Logo"
            width={180}
            height={30}
            priority
          />
        )}

        {collapsed && (
          <div className="flex items-center justify-center w-8 h-8 rounded-md bg-[#ffdd00]">
            <CreditCard className="h-5 w-5 text-[#0d62a6]" />
          </div>
        )}
        <button
          className="p-1 rounded-md hover:bg-[#174e82]"
          onClick={toggleCollapse}
        >
          {collapsed ? (
            <ChevronRight className="h-5 w-5" />
          ) : (
            <ChevronLeft className="h-5 w-5" />
          )}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto py-4">
        <nav className="space-y-1 px-2">
          {navItems.map((item) => {
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.name}
                href={item.href}
                className={`${
                  isActive
                    ? "bg-[#ffdd00] text-[#0d62a6] font-semibold"
                    : "text-white hover:bg-[#174e82] hover:text-white"
                } ${
                  collapsed ? "justify-center" : "justify-start"
                } group flex items-center px-2 py-2 text-sm rounded-md transition-colors`}
              >
                <item.icon
                  className={`h-5 w-5 ${
                    isActive ? "text-[#0d62a6]" : "text-white"
                  } ${!collapsed && "mr-3"}`}
                />
                {!collapsed && <span>{item.name}</span>}
              </Link>
            );
          })}
        </nav>
      </div>

      <div className="p-4 border-t border-[#174e82]">
        <Link
          href={logoutHref}
          className={`flex items-center px-2 py-2 text-sm font-medium rounded-md text-white hover:bg-[#174e82] ${
            collapsed ? "justify-center" : "justify-start"
          }`}
        >
          <LogOut className="h-5 w-5" />
          {!collapsed && <span className="ml-3">Log out</span>}
        </Link>
      </div>
    </div>
  );
}