"use client";

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation'; 
import {
    Bell,
    Search,
    Menu,
    X,
} from 'lucide-react';

export function DashboardHeader({ userRole = 'user', isSidebarCollapsed }) {
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
    const [notificationsOpen, setNotificationsOpen] = useState(false);
    const [notificationItems, setNotificationItems] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const router = useRouter();

    const headerPadding = isSidebarCollapsed ? 'pl-4' : 'pl-64';

    const roleLabel =
        userRole === 'admin'
            ? 'Administrator'
            : userRole === 'executive'
                ? 'Executive'
                : 'Client';

    const velstronId =
        userRole === 'admin'
            ? 'VLS_A1234'
            : userRole === 'executive'
                ? 'VLS_E5678'
                : 'VLS_U9012';

    useEffect(() => {
        const interval = setInterval(() => {
            const newNotification = {
                id: Date.now(),
                title: 'New Alert',
                description: 'This is a simulated real-time notification!',
                time: new Date().toLocaleTimeString(),
                unread: true,
            };
            setNotificationItems(prev => [newNotification, ...prev]);
        }, 10000);

        return () => clearInterval(interval);
    }, []);

    const handleRemoveNotification = (id) => {
        setNotificationItems(prev => prev.filter(item => item.id !== id));
    };

    const markAsRead = (id) => {
        setNotificationItems(prev =>
            prev.map(item =>
                item.id === id ? { ...item, unread: false } : item
            )
        );
    };

    return (
        <header
            className={`sticky top-0 z-30 flex h-16 items-center border-b bg-[#0d62a6] px-4 md:px-6 text-white ${headerPadding} transition-all duration-300`}
        >
            <div className="lg:hidden mr-2">
                <button className="p-2 hover:text-[#ffdd00]" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                    {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
                </button>
            </div>

            <div className="flex flex-1 items-center justify-between">
                <div className="flex items-center">
                    <div className="relative hidden md:flex items-center">
                        <Search className="absolute left-2.5 h-4 w-4 text-white/60" />
                        <input
                            type="search"
                            placeholder="Search..."
                            className="rounded-md border border-white/20 bg-[#174e82] text-white pl-8 pr-3 py-2 text-sm w-64 placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-[#ffdd00]"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter' && searchQuery.trim()) {
                                    router.push(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
                                }
                            }}
                        />
                    </div>
                </div>

                <div className="flex items-center gap-4">
                    <div className="relative">
                        <button
                            className="p-2 hover:text-[#ffdd00] relative"
                            onClick={() => setNotificationsOpen(!notificationsOpen)}
                        >
                            <Bell className="h-5 w-5" />
                            {notificationItems.some(n => n.unread) && (
                                <span className="absolute top-1 right-1 w-2 h-2 bg-[#ffdd00] rounded-full" />
                            )}
                        </button>

                        {notificationsOpen && (
                            <div className="absolute right-0 mt-2 w-80 rounded-md bg-white text-black shadow-lg border z-50">
                                <div className="px-4 py-3 border-b">
                                    <h3 className="text-sm font-medium">Notifications</h3>
                                </div>
                                <div className="max-h-96 overflow-y-auto">
                                    {notificationItems.length === 0 ? (
                                        <p className="px-4 py-3 text-sm text-gray-500">No notifications yet.</p>
                                    ) : (
                                        notificationItems.map((item) => (
                                            <div
                                                key={item.id}
                                                className={`px-4 py-3 border-b hover:bg-gray-100 cursor-pointer flex items-center justify-between ${item.unread ? 'bg-yellow-50' : ''}`}
                                                onClick={() => markAsRead(item.id)}
                                            >
                                                <div className="flex-1 mr-2">
                                                    <div className="flex items-start justify-between">
                                                        <p className="text-sm font-medium">{item.title}</p>
                                                        {item.unread && <span className="h-2 w-2 rounded-full bg-[#0d62a6]" />}
                                                    </div>
                                                    <p className="text-xs text-gray-600 mt-1">{item.description}</p>
                                                    <p className="text-xs text-gray-500 mt-1">{item.time}</p>
                                                </div>
                                                <button
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        handleRemoveNotification(item.id);
                                                    }}
                                                    className="p-1 text-gray-400 hover:text-gray-700"
                                                >
                                                    <X className="h-4 w-4" />
                                                </button>
                                            </div>
                                        ))
                                    )}
                                </div>
                                <div className="px-4 py-2 text-center">
                                    <Link
                                        href={`/dashboard/${userRole}/notifications`}
                                        className="text-xs text-[#0d62a6] font-medium hover:underline"
                                    >
                                        View all notifications
                                    </Link>
                                </div>
                            </div>
                        )}
                    </div>

                    <div className="flex items-center text-sm">
                        <div className="hidden md:flex md:flex-col md:items-end md:mr-3 text-white">
                            <span className="font-medium">{roleLabel}</span>
                            <span className="text-xs text-white/70">{velstronId}</span>
                        </div>
                        <div className="h-8 w-8 rounded-full bg-[#ffdd00] flex items-center justify-center text-[#0d62a6] font-bold">
                            {userRole === 'admin' ? 'A' : userRole === 'executive' ? 'E' : 'U'}
                        </div>
                    </div>
                </div>
            </div>
        </header>
    );
}