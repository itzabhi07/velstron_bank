import React, { useEffect, useState } from 'react';
import { getFundSummary } from '../api/dashboard';  // Importing API call

const FundSummary = () => {
  const [fundSummary, setFundSummary] = useState(null);

  useEffect(() => {
    const fetchSummary = async () => {
      const data = await getFundSummary();  // Fetch fund summary from backend
      setFundSummary(data);  // Set state with fetched data
    };
    fetchSummary();
  }, []);

  return (
    <div>
      <h2>Fund Summary</h2>
      {fundSummary ? (
        <div>
          <p>Total Balance: {fundSummary.totalBalance}</p>
          <p>Available Funds: {fundSummary.availableFunds}</p>
          {/* Add more fields based on the response */}
        </div>
      ) : (
        <p>Loading...</p>  // Display loading message until data is fetched
      )}
    </div>
  );
};

export default FundSummary;