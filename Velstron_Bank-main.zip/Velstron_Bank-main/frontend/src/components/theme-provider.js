'use client';

import { createContext, useContext, useEffect, useState } from 'react';

const ThemeContext = createContext({ 
  theme: 'light', 
  setTheme: () => null 
});

export const ThemeProvider = ({ 
  children, 
  defaultTheme = 'light',
  attribute = 'class',
  enableSystem = false,
}) => {
  const [theme, setTheme] = useState(defaultTheme);

  useEffect(() => {
    const root = window.document.documentElement;
    
    // Remove old theme class
    root.classList.remove('light', 'dark');
    
    // Add new theme class
    if (attribute === 'class') {
      root.classList.add(theme);
    } else {
      root.setAttribute(attribute, theme);
    }
  }, [theme, attribute]);

  const value = {
    theme,
    setTheme: (newTheme) => {
      setTheme(newTheme);
      // Save to local storage or cookies if needed
      try {
        localStorage.setItem('vbTheme', newTheme);
      } catch (e) {
        // Handle localStorage errors
      }
    },
  };

  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};