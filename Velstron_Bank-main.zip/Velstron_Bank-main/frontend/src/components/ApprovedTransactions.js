import React, { useEffect, useState } from 'react';
import { getApprovedTransactions } from '../api/transactions';  // Importing getApprovedTransactions API call

const ApprovedTransactions = () => {
  const [approvedTransactions, setApprovedTransactions] = useState([]);

  useEffect(() => {
    const fetchApproved = async () => {
      const data = await getApprovedTransactions();  // Fetch approved transactions from backend
      setApprovedTransactions(data);  // Set the fetched data to state
    };
    fetchApproved();
  }, []);

  return (
    <div>
      <h2>Approved Transactions</h2>
      <ul>
        {approvedTransactions.map((transaction) => (
          <li key={transaction._id}>
            <p>{transaction.description}</p>
            <span>Status: Approved</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ApprovedTransactions;