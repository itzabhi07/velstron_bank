import React, { useEffect, useState } from 'react';
import { getExecutives, deleteExecutive } from '../api/executiveManagement';  // Importing API calls

const ExecutiveList = () => {
  const [executives, setExecutives] = useState([]);

  useEffect(() => {
    const fetchExecutives = async () => {
      const data = await getExecutives();  // Fetch executives data from backend
      setExecutives(data);
    };
    fetchExecutives();
  }, []);

  const handleDelete = async (id) => {
    const response = await deleteExecutive(id);  // Call delete API
    if (response) {
      setExecutives((prev) => prev.filter((exec) => exec._id !== id));  // Remove deleted executive from the list
    }
  };

  return (
    <div>
      <h2>Executive List</h2>
      <ul>
        {executives.map((executive) => (
          <li key={executive._id}>
            <p>{executive.name} - {executive.email}</p>
            <button onClick={() => handleDelete(executive._id)}>Delete</button>
            {/* Add link to edit executive */}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ExecutiveList;