import React, { useState } from 'react';
import { addExecutive } from '../api/executiveManagement';  // Importing addExecutive API call

const AddExecutive = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const executiveData = { name, email };

    const response = await addExecutive(executiveData);  // Call add executive API

    if (response) {
      alert('Executive added successfully!');
    }
  };

  return (
    <div>
      <h2>Add Executive</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <br />
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <br />
        <button type="submit">Add Executive</button>
      </form>
    </div>
  );
};

export default AddExecutive;