import React, { useState } from 'react';
import { createUser } from '../api/users';

const CreateUser = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const result = await createUser({ name, email });
    if (result) {
      alert('User Created Successfully!');
      setName('');
      setEmail('');
    }
  };

  return (
    <div>
      <h2>Create User</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Name" required />
        <br />
        <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" required />
        <br />
        <button type="submit">Create</button>
      </form>
    </div>
  );
};

export default CreateUser;