import React, { useEffect, useState } from 'react';
import { fetchAnalyticsData } from '../api/analytics'; // Importing fetchAnalyticsData API call

const AnalyticsData = () => {
  const [analyticsData, setAnalyticsData] = useState(null);

  useEffect(() => {
    const getAnalytics = async () => {
      const data = await fetchAnalyticsData();  // Fetch data from backend
      setAnalyticsData(data);  // Store the fetched data in the state
    };
    getAnalytics();
  }, []);  // Empty array ensures the effect runs only once when the component mounts

  return (
    <div>
      <h2>Analytics Data</h2>
      {analyticsData ? (
        <div>
          <p>Total Users: {analyticsData.totalUsers}</p>
          <p>Total Sales: {analyticsData.totalSales}</p>
          {/* Add more fields as required based on the data returned */}
        </div>
      ) : (
        <p>Loading...</p>  // Loading state while data is being fetched
      )}
    </div>
  );
};

export default AnalyticsData;