import React, { useEffect, useState } from 'react';
import { fetchAlerts, markReviewed } from '../api/admin';  // Import API functions

const Alerts = () => {
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    const getAlerts = async () => {
      const fetchedAlerts = await fetchAlerts();
      setAlerts(fetchedAlerts);
    };
    getAlerts();
  }, []);

  const handleMarkReviewed = async (alertId) => {
    const updatedAlert = await markReviewed(alertId);
    setAlerts((prev) => prev.map((alert) => (alert._id === alertId ? updatedAlert : alert)));
  };

  return (
    <div>
      <h2>Alerts</h2>
      <ul>
        {alerts.map((alert) => (
          <li key={alert._id}>
            <p>{alert.message}</p>
            <button onClick={() => handleMarkReviewed(alert._id)}>Mark as Reviewed</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Alerts;