import React, { useEffect, useState } from 'react';
import { fetchSecuritySettings, updateSecuritySettings } from '../api/admin';

const SecuritySettings = () => {
  const [settings, setSettings] = useState({});

  useEffect(() => {
    const getSettings = async () => {
      const fetchedSettings = await fetchSecuritySettings();
      setSettings(fetchedSettings);
    };
    getSettings();
  }, []);

  const handleUpdateSettings = async () => {
    const updatedSettings = await updateSecuritySettings(settings);
    setSettings(updatedSettings);
  };

  return (
    <div>
      <h2>Security Settings</h2>
      <button onClick={handleUpdateSettings}>Update Settings</button>
    </div>
  );
};

export default SecuritySettings;