// frontend/src/components/TransactionApprovalButton.jsx

import React, { useState } from 'react';
import axios from 'axios';

const TransactionApprovalButton = ({ transactionId }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);
    const [successMessage, setSuccessMessage] = useState(null);

    const handleApprove = async () => {
        setIsLoading(true);
        setError(null);
        setSuccessMessage(null);

        try {
            const response = await axios.post('/api/transactions/approve', { transactionId });
            setSuccessMessage(response.data.message);
        } catch (err) {
            setError('Transaction approval failed');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div>
            <button onClick={handleApprove} disabled={isLoading}>
                {isLoading ? 'Approving...' : 'Approve Transaction'}
            </button>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            {successMessage && <p style={{ color: 'green' }}>{successMessage}</p>}
        </div>
    );
};

export default TransactionApprovalButton;