import React, { useEffect, useState } from 'react';
import { getPendingTransactions, approveTransaction, rejectTransaction } from '../api/transactions';  // Importing API calls

const PendingTransactions = () => {
  const [pendingTransactions, setPendingTransactions] = useState([]);

  useEffect(() => {
    const fetchPending = async () => {
      const data = await getPendingTransactions();  // Fetch pending transactions from backend
      setPendingTransactions(data);  // Set the fetched data to state
    };
    fetchPending();
  }, []);

  const handleApprove = async (id) => {
    const updatedTransaction = await approveTransaction(id);  // Call approveTransaction API
    setPendingTransactions((prev) => prev.filter((txn) => txn._id !== updatedTransaction._id));  // Remove approved transaction from the list
  };

  const handleReject = async (id) => {
    const updatedTransaction = await rejectTransaction(id);  // Call rejectTransaction API
    setPendingTransactions((prev) => prev.filter((txn) => txn._id !== updatedTransaction._id));  // Remove rejected transaction from the list
  };

  return (
    <div>
      <h2>Pending Transactions</h2>
      <ul>
        {pendingTransactions.map((transaction) => (
          <li key={transaction._id}>
            <p>{transaction.description}</p>
            <button onClick={() => handleApprove(transaction._id)}>Approve</button>
            <button onClick={() => handleReject(transaction._id)}>Reject</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default PendingTransactions;