import React, { useState } from 'react';
import { fundTransfer } from '../api/dashboard';  // Importing fundTransfer API call

const FundTransfer = () => {
  const [amount, setAmount] = useState('');
  const [recipientAccount, setRecipientAccount] = useState('');

  const handleTransfer = async (e) => {
    e.preventDefault();
    const transferData = { amount, recipientAccount };
    const response = await fundTransfer(transferData);  // Call fund transfer API

    if (response) {
      alert('Transfer Successful');
    }
  };

  return (
    <div>
      <h2>Fund Transfer</h2>
      <form onSubmit={handleTransfer}>
        <input
          type="number"
          placeholder="Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          required
        />
        <br />
        <input
          type="text"
          placeholder="Recipient Account"
          value={recipientAccount}
          onChange={(e) => setRecipientAccount(e.target.value)}
          required
        />
        <br />
        <button type="submit">Transfer</button>
      </form>
    </div>
  );
};

export default FundTransfer;