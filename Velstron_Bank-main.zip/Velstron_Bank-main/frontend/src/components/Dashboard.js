// frontend/src/components/Dashboard.js

import React, { useEffect, useState } from "react";
import {
  getFundSummary,
  getAccountDetails,
} from "../services/DashboardService";

export default function Dashboard() {
  const [fundSummary, setFundSummary] = useState(null);
  const [accountDetails, setAccountDetails] = useState(null);
  const [loading, setLoading] = useState(true);

  // Suppose you have user token saved after login
  const token = localStorage.getItem("authToken");

  useEffect(() => {
    async function fetchData() {
      try {
        const summary = await getFundSummary(token);
        const details = await getAccountDetails(token);

        setFundSummary(summary);
        setAccountDetails(details);
      } catch (error) {
        console.error("Error fetching dashboard data:", error);
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, [token]);

  if (loading) return <p>Loading...</p>;

  return (
    <div>
      <h2>Fund Summary</h2>
      <pre>{JSON.stringify(fundSummary, null, 2)}</pre>

      <h2>Account Details</h2>
      <pre>{JSON.stringify(accountDetails, null, 2)}</pre>
    </div>
  );
}