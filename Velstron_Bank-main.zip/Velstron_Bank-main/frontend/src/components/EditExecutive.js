import React, { useState, useEffect } from 'react';
import { updateExecutive } from '../api/executiveManagement';  // Importing updateExecutive API call

const EditExecutive = ({ match }) => {
  const [executive, setExecutive] = useState({ name: '', email: '' });

  useEffect(() => {
    const fetchExecutive = async () => {
      // Fetch executive details based on ID (from URL params or state)
      // For example, you could fetch it from an API using the match.params.id
    };
    fetchExecutive();
  }, [match.params.id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const response = await updateExecutive(match.params.id, executive);  // Call update API

    if (response) {
      alert('Executive updated successfully!');
    }
  };

  return (
    <div>
      <h2>Edit Executive</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Name"
          value={executive.name}
          onChange={(e) => setExecutive({ ...executive, name: e.target.value })}
          required
        />
        <br />
        <input
          type="email"
          placeholder="Email"
          value={executive.email}
          onChange={(e) => setExecutive({ ...executive, email: e.target.value })}
          required
        />
        <br />
        <button type="submit">Update Executive</button>
      </form>
    </div>
  );
};

export default EditExecutive;