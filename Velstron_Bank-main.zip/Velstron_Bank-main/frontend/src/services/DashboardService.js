// frontend/src/services/DashboardService.js

const API_BASE_URL = "http://localhost:5000"; // Change if backend URL is different

// Add Authorization header if your backend requires token auth (example below)
const getAuthHeaders = (token) => ({
  "Content-Type": "application/json",
  Authorization: Bearer ${token},
});

export const getFundSummary = async (token) => {
  const response = await fetch(${API_BASE_URL}/fund-summary, {
    method: "GET",
    headers: getAuthHeaders(token),
  });
  return response.json();
};

export const fundTransfer = async (transferData, token) => {
  const response = await fetch(${API_BASE_URL}/fund-transfer, {
    method: "POST",
    headers: getAuthHeaders(token),
    body: JSON.stringify(transferData),
  });
  return response.json();
};

export const setHotAccountHolding = async (holdingData, token) => {
  const response = await fetch(${API_BASE_URL}/set-hot-holding, {
    method: "POST",
    headers: getAuthHeaders(token),
    body: JSON.stringify(holdingData),
  });
  return response.json();
};

export const createTransactionRequest = async (transactionData, token) => {
  const response = await fetch(${API_BASE_URL}/transaction-request, {
    method: "POST",
    headers: getAuthHeaders(token),
    body: JSON.stringify(transactionData),
  });
  return response.json();
};

export const getAccountDetails = async (token) => {
  const response = await fetch(${API_BASE_URL}/account-details, {
    method: "GET",
    headers: getAuthHeaders(token),
  });
  return response.json();
};