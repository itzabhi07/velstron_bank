import axios from 'axios';

// Base URL for the API (update this to your server URL if needed)
const API_URL = 'http://localhost:5000/executives';  // Adjust the URL if necessary

// Get all executives
export const getExecutives = async () => {
  try {
    const response = await axios.get(API_URL);
    return response.data;
  } catch (error) {
    console.error('Error fetching executives:', error);
    throw error;
  }
};

// Add a new executive
export const addExecutive = async (executiveData) => {
  try {
    const response = await axios.post(API_URL, executiveData);
    return response.data;
  } catch (error) {
    console.error('Error adding executive:', error);
    throw error;
  }
};

// Update an executive by ID
export const updateExecutive = async (id, executiveData) => {
  try {
    const response = await axios.put(${API_URL}/${id}, executiveData);
    return response.data;
  } catch (error) {
    console.error('Error updating executive:', error);
    throw error;
  }
};

// Delete an executive by ID
export const deleteExecutive = async (id) => {
  try {
    const response = await axios.delete(${API_URL}/${id});
    return response.data;
  } catch (error) {
    console.error('Error deleting executive:', error);
    throw error;
  }
};