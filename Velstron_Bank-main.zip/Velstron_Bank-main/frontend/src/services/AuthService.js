// frontend/src/services/AuthService.js

const API_BASE_URL = "http://localhost:5000"; // Change karo agar backend ka URL alag hai

export const signup = async (userData) => {
  try {
    const response = await fetch(${API_BASE_URL}/signup, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(userData),
    });
    return await response.json();
  } catch (error) {
    console.error("Signup error:", error);
    throw error;
  }
};

export const initiateLogin = async (loginData) => {
  try {
    const response = await fetch(${API_BASE_URL}/login, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(loginData),
    });
    return await response.json();
  } catch (error) {
    console.error("Login error:", error);
    throw error;
  }
};

export const verifyCode = async (codeData) => {
  try {
    const response = await fetch(${API_BASE_URL}/verify-code, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(codeData),
    });
    return await response.json();
  } catch (error) {
    console.error("Verify code error:", error);
    throw error;
  }
};